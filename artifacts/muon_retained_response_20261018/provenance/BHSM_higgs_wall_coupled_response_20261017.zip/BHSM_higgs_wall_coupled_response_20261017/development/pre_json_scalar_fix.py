from __future__ import annotations
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
from pathlib import Path
import sys,json,argparse
import numpy as np
from build_higgs_response import *


def run(output):
 out=Path(output);out.mkdir(parents=True,exist_ok=False);inputs=ROOT/'inputs';records=[];groups={}
 rng=np.random.default_rng(7219)
 for side in ('incoming','outgoing'):
  d=prepare(side,inputs);s=solve_response(d);ind=direct_original(d)
  saved=dict(np.load(inputs/(side+'_maxwell_causal_maps.npz')));both=combine_saved(saved,s)
  nuder=nu2_sensitivity(d,s)
  coeffs={};local=[];sym=0.;quad=0.;gau=0.;aligned=0.;normalization=0.
  for lab in ['lo','q000','q001','q002','q003','hi']:
   r=d['records'][lab];data=dict(np.load(inputs/f'{side}_{lab}.npz'));raw=data['raw'];bb=r['original'];bc=higgs_blocks(raw,rule=rule24)
   qerr=max(maxabs(bb[k]-bc[k]) for k in ('M','B','K'));quad=max(quad,qerr)
   gg=original_gauge_checks(raw,bb);al=aligned_checks(raw,bb,data['Wg']);gau=max(gau,gg['off_shell_gauge_identity']);aligned=max(aligned,al['complete_aligned_Higgs_cross'])
   for k in ('M','B','K'):coeffs[lab+'_'+k]=r[k]
   coeffs[lab+'_original_cross_H_A']=bb['K'][:16,16:];coeffs[lab+'_moving_axis_gradient_contact']=al.pop('contact_array');coeffs[lab+'_fixed_axis_cross_array']=al.pop('fixed_axis_cross_array')
   local.append(dict(sample=lab,quadratic_rule_discrepancy=qerr,kinetic_weight=float(bb['M'][0,0]),H_norm2=float(raw[260:264]@raw[260:264]),**gg,**al))
   sym=max(sym,bb['symmetry'])
  literals=[]
  for lab in ('lo','hi'):
   raw=np.load(inputs/f'{side}_{lab}.npz')['raw'];bb=higgs_blocks(raw)
   for j in range(3):
    q=rng.normal(size=80)*.1;qd=rng.normal(size=80)*.1
    value=qd@bb['M']@qd+2*q@bb['B']@qd+q@bb['K']@q
    L=lambda e:literal_action(raw,e*q,e*qd)
    for h in (.5,.25):
     direct=(-L(2*h)+16*L(h)-30*L(0)+16*L(-h)-L(-2*h))/(12*h*h)
     literals.append(dict(sample=lab,direction=j,step=h,original_scalar_second=float(direct),matrix_second=float(value),absolute_error=abs(direct-value)))
  lerr=max(x['absolute_error'] for x in literals)
  fds=[]
  for step in (.2,.1,.05):
   up=solve_response(prepare(side,inputs,nu2=NU2+step));dn=solve_response(prepare(side,inputs,nu2=NU2-step))
   for name in ('final','wall'):
    df=(up[name]-dn[name])/(2*step);ref=nuder[name];fds.append(dict(step=step,output=name,max_absolute=maxabs(df-ref),derivative_max=maxabs(ref)))
  measures=dict(scalar_stage_residual=s['stage_residual'],independent_original_equation_residual=ind['residual'],
       independent_stage_difference=maxabs(s['stages']-ind['stages']),independent_final_difference=maxabs(s['final']-ind['final']),
       scalar_Green_identity=s['green'],scalar_symplectic=s['symplectic'],combined_wall_temporal_Green_identity=both['green'],
       independent_original_action_max=lerr,independent_angular_rule_max=quad,
       original_Higgs_gauge_identity_max=gau,complete_moving_neutral_axis_cross_max=aligned,
       scalar_momentum_residual=max(maxabs(v['mom'][:16]- (s['initial'] if k=='lo' else s['final'] if k=='hi' else s['stages'][int(k[1:])])[16:]) for k,v in s['recs'].items()),
       nu2_derivative_equation_residual=nuder['implicit_equation_residual'],nu2_fd_max=max(x['max_absolute'] for x in fds),
       free_wall_Higgs_response_max=maxabs(s['wall'][:,32:]),Higgs_initial_to_wall_max=maxabs(s['wall'][:,:32]),
       fixed_original_trace_magnetic_Higgs_response_max=maxabs(s['wall'][:,-6:]),
       Higgs_wall_rate_momentum_max=maxabs(s['wall_endpoint']))
  categories=dict(original_action_hessian=lerr<2e-10,angular_exact_degree_comparison=quad<2e-10,
   original_gauge_identity=gau<2e-10,aligned_axis_cancellation=aligned<2e-10,
   independent_original_propagation=measures['independent_stage_difference']<2e-10 and measures['independent_final_difference']<2e-10,
   scalar_momentum=measures['scalar_momentum_residual']<2e-10,
   scalar_Green=s['green']<2e-10,scalar_symplectic=s['symplectic']<2e-10,
   combined_Green=both['green']<2e-10,parameter_derivative_partial=measures['nu2_fd_max']<2e-10)
  if not all(categories.values()):raise AssertionError((side,measures,categories))
  save_npz(out/f'{side}_higgs_coefficients.npz',coeffs)
  save_npz(out/f'{side}_higgs_response.npz',dict(stages=s['stages'],final=s['final'],weak_wall=s['wall'],wall_euler=s['wall_euler'],wall_endpoint=s['wall_endpoint'],coordinate_frame=d['J'],nu2_final_first=nuder['final'],nu2_weak_wall_first=nuder['wall'],nu2_stage_first=nuder['stages']))
  save_npz(out/f'{side}_combined_response.npz',{k:v for k,v in both.items() if isinstance(v,np.ndarray)})
  record=dict(side=side,measures=measures,scoped_checks=categories,coefficient_samples=local,independent_original_action_checks=literals,nu2_derivative_checks=fds)
  records.append(record)
  (out/'progress.json').write_text(json.dumps(records,indent=2,sort_keys=True,allow_nan=False)+'\n')
  print(side,json.dumps(measures,sort_keys=True),flush=True)
 result=dict(classification='DYNAMIC_INTRINSIC_HIGGS_PLUS_SAVED_MAXWELL_WALL_RESPONSE_ON_PROVISIONAL_HISTORIES',
    measured_calibration_preserved=dict(GF_GeV_minus2=1.1663774240217167e-5,m_h_GeV=125.11,lambda_H=LAM,nu_squared_action=NU2),
    intrinsic_to_common_action_factor=C_ORBIT,source_revision='70e82fd4dbe5f53ff27ae17f6aaac7a4727c1fde',
    shape=dict(wall_inputs=64,wall_time_profile_columns=134,Maxwell_initial_coordinates=408,Higgs_initial_coordinates=32,combined_final_map=[440,574],combined_wall_map=[134,574]),
    records=records,physical_collider_solved=False,physical_wall_equation_closed=False,actual_arms_joined=False,
    inherited_reference_selected=False,native_quantum_response_evaluated=False,complete_outgoing_derivative_admitted=False,
    complete_matched_magnetic_derivative=False,coupled_background_corrections=0,a_mu=None,g_mu=None,total_uncertainty=None,git_writes=False,
    previous_stricter_Maxwell_gauge_reconstruction_not_repaired=True,
    scope='Finite n1 classical scalar+Maxwell components, fixed supplied geometry/background, four-stage time rule and existing radial arrays. No radial/temporal/physical-state error enclosure.',
    next_operand='Action-defined common wall equation coupling this returned classical response to matter-current, geometry/interface and exterior/native/inherited-state terms; no wall trace or reaction is set zero by this combination.')
 (out/'result.json').write_text(json.dumps(result,indent=2,sort_keys=True,allow_nan=False)+'\n')
 return result
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',required=True,type=Path);args=p.parse_args();run(args.output)
