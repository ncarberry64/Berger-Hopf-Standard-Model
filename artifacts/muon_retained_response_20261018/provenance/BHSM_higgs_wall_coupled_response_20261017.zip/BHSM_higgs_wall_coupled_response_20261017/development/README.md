The first finalization attempt encountered a JSON serialization error for a
NumPy boolean, after computing incoming arrays and passing its checks. The
pre-fix source and partial output are preserved here. All authoritative output
comes from the final replay_A and replay_B executions. Numerical/action formulas
were unchanged in that repair. A separate exploratory reconstruction check tried
to add an exactly-real complex stored mechanical profile into a float array and
was rerun with a complex array; no output from that exploratory type error was
used in the final result. The exploratory successful check confirms total
connection = independent radial expansion + M*(lambda-1), not M*lambda.
