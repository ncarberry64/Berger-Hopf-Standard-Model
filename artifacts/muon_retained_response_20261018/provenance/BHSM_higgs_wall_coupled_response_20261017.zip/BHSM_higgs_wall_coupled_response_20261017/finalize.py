from pathlib import Path
import json,hashlib,zipfile,sys
import numpy as np,scipy
p=Path(__file__).resolve().parent
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
a=p/'replay_A';b=p/'replay_B';files=sorted(f.relative_to(a) for f in a.rglob('*') if f.is_file());rows=[]
for name in files:
 if (a/name).read_bytes()!=(b/name).read_bytes():raise AssertionError(str(name))
 rows.append(dict(path=str(name),sha256=sha(a/name),byte_identical=True))
result=json.loads((a/'result.json').read_text());meta=json.loads((p/'inputs/metadata.json').read_text())
checks=[r['scoped_checks'] for r in result['records']]
verification=dict(classification=result['classification'],input_source_revision=result['source_revision'],input_manifests=meta['sources'],
 environment=dict(python=sys.version,numpy=np.__version__,scipy=scipy.__version__),scoped_categories_per_arm=len(checks[0]),
 all_new_scoped_checks_pass=all(all(c.values()) for c in checks),replay_comparisons=rows,replay_byte_identical=True,
 measured_calibration_preserved=result['measured_calibration_preserved'],records=[dict(side=r['side'],measures=r['measures']) for r in result['records']],
 previous_stricter_Maxwell_gauge_reconstruction_pass=False,complete_physical_outgoing_derivative_admitted=False,
 physical_wall_equation_closed=False,physical_collider_solved=False,native_quantum_response_evaluated=False,
 initial_fields_or_quantum_state_selected=False,coupled_background_corrections=0,a_mu=None,g_mu=None,total_uncertainty=None,git_writes=False)
(p/'VERIFICATION.json').write_text(json.dumps(verification,indent=2,sort_keys=True,allow_nan=False)+'\n')
checkpoint={k:v for k,v in result.items() if k!='records'};checkpoint['NEXT_OPERAND']=checkpoint.pop('next_operand')
(p/'CHECKPOINT.json').write_text(json.dumps(checkpoint,indent=2,sort_keys=True,allow_nan=False)+'\n')
# Keep only regular scientific and development files; never package interpreter caches.
files=[f for f in sorted(p.rglob('*')) if f.is_file() and '__pycache__' not in f.parts and f.name!='SHA256SUMS.json']
hashes={f.relative_to(p).as_posix():sha(f) for f in files}
(p/'SHA256SUMS.json').write_text(json.dumps(hashes,indent=2,sort_keys=True)+'\n')
zpath=p.with_suffix('.zip')
with zipfile.ZipFile(zpath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f in files+[p/'SHA256SUMS.json']:
  zi=zipfile.ZipInfo(p.name+'/'+f.relative_to(p).as_posix(),(2026,10,17,0,0,0));zi.compress_type=zipfile.ZIP_DEFLATED;z.writestr(zi,f.read_bytes())
with zipfile.ZipFile(zpath) as z:assert z.testzip() is None
print(json.dumps(dict(package=str(zpath),bytes=zpath.stat().st_size,recorded_hashes=len(hashes),replay_files=len(rows),new_categories_per_arm=len(checks[0]))))
