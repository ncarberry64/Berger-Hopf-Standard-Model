# BHSM dynamic Higgs / Maxwell wall-response continuation

Run `python run_higgs_response.py --output replay_new` with NumPy and SciPy.
Use `OPENBLAS_NUM_THREADS=1` for the supplied deterministic replay configuration.
`inputs/` contains the needed prior numerical extracts. No network, credentials,
Git mutation, or Windows-worktree access is used by the calculation.

Read DERIVATION.md before interpreting the arrays. These are fixed-provisional-
background classical n1 response maps with arbitrary wall and initial inputs,
NOT the admitted physical collider or native muon response.

Input coordinates of combined maps: Maxwell canonical initial408, Higgs canonical
initial32, existing wall-drive134. Output: Maxwell final408 plus Higgs final32.
The wall response has134 weak test rows in exactly the preceding input-profile
convention. Canonical and time scaling are explicit in the derivation/code.
Do not set unknown external wall equations to zero to make the port system close.

The existing matched scalar lambda is preserved with its empirical ancestry;
nu_squared_action=4 is the value in both uploaded original phase receipts.
No muon anomaly or new fit is used. The complete source, geometry, native and
inherited-state derivatives are not supplied by the fixed nu2 partial.
