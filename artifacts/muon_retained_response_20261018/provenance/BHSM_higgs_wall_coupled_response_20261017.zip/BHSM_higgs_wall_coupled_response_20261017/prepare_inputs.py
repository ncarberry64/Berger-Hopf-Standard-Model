from pathlib import Path
import json,sys,numpy as np,hashlib,shutil
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT))
from build_higgs_response import save_npz,digest

def run(work):
 work=Path(work);orig=work/'BHSM_RETAINED_HISTORY_INPUTS_20261017';prev=work/'BHSM_port_preserving_retarded_response_20261017'
 out=ROOT/'inputs';out.mkdir(exist_ok=True);sources={}
 for folder in (orig,prev):
  sums=json.loads((folder/'SHA256SUMS.json').read_text());print(folder.name,type(sums),len(sums))
  if isinstance(sums,dict) and 'files' in sums: sums=sums['files']
  for path,expected in sums.items():
   if not isinstance(expected,str): raise TypeError((path,expected))
   actual=digest(folder/path)
   if actual!=expected: raise ValueError(f'hash mismatch {folder}/{path}')
  sources[folder.name]=dict(manifest_sha256=digest(folder/'SHA256SUMS.json'),verified_count=len(sums))
 meta=json.loads((prev/'inputs/metadata.json').read_text());meta['sources']=sources
 ids=np.arange(320).reshape(4,5,4,4);gids=ids[3,[0,2,3,4]].ravel()
 for side in ('incoming','outgoing'):
  receipt=json.loads((orig/side/'original_phase_receipt.json').read_text());assert receipt['action_parameters']['nu_squared_action']==4.
  for lab in ['lo','q000','q001','q002','q003','hi']:
   a=np.load(orig/side/(lab+'.npz'));b=np.load(prev/'inputs'/(side+'_'+lab+'.npz'))
   raw=a['raw_fields']; assert np.max(abs(a['coefficient_intrinsic_H_realified']-raw[260:264]))==0
   assert np.max(abs(a['coefficient_intrinsic_H_realified_first'][0]-raw[264:268]))<1e-13
   save_npz(out/(side+'_'+lab+'.npz'),dict(raw=raw,rawdot=a['raw_coordinate_time_derivative'],Wg=b['W'][gids],Wgdot=b['Wdot'][gids]))
   meta['sides'][side]['samples'][lab]['original_export_sha256']=digest(orig/side/(lab+'.npz'))
   meta['sides'][side]['samples'][lab]['port_input_sha256']=digest(prev/'inputs'/(side+'_'+lab+'.npz'))
  shutil.copy2(prev/'replay_A'/(side+'_causal_maps.npz'),out/(side+'_maxwell_causal_maps.npz'))
 (out/'metadata.json').write_text(json.dumps(meta,indent=2,sort_keys=True)+'\n')
if __name__=='__main__':run(sys.argv[1])
