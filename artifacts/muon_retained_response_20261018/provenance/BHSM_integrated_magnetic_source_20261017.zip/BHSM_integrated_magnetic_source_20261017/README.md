# BHSM integrated Maxwell magnetic-source application

This package consumes the uploaded twelve-sample retained-history export and
provides radially and temporally integrated finite Maxwell source blocks, their
magnetic third variations, finite forced Gauss reductions, and independent
original-action checks. Read DERIVATION.md for the scientific boundaries.

**No physical collider solution, retarded exterior, magnetic moment, or Git
update is claimed.** The input histories are provisional. Magnetic source arrays
are per unit canonical electric charge and no measuring-field ramp is chosen.

The package includes one copy of each evaluated output. A second execution of
all four stages was performed; `VERIFICATION.json` records hashes and exact
file comparisons for all 33 result files. It also preserves all error scopes.

## Reproduce

Use Python with NumPy and SciPy, extracting the included input ZIP next to this
folder. Or supply the path of your original extracted input folder. Use new
output directories; the programs refuse to overwrite previous evidence.

```powershell
$Python = 'C:\Python314\python.exe'
$Here = 'C:\Users\carbe\Downloads\BHSM_integrated_magnetic_source_20261017'
$Inputs = 'C:\Users\carbe\Downloads\BHSM_RETAINED_HISTORY_INPUTS_20261017'
$env:OPENBLAS_NUM_THREADS = '1'
$env:OMP_NUM_THREADS = '1'
& $Python "$Here\integrated_source.py" --inputs $Inputs --output "$Here\local_replay"
& $Python "$Here\integrated_magnetic_hessian.py" --inputs $Inputs --output "$Here\local_magnetic"
& $Python "$Here\check_integrated_source.py" --inputs $Inputs --run "$Here\local_replay" --output "$Here\local_checks"
& $Python "$Here\check_magnetic_hessian.py" --inputs $Inputs --magnetic "$Here\local_magnetic" --output "$Here\local_magnetic_checks"
```

These commands operate only in their output directories and make no repository
or Git changes. They do not require re-exporting your existing histories.

### Output locations

* replay_A/: M/B/K, all magnetic amplitude/rate force and momentum columns,
  finite Gauss maps, source shifts, spectra, and provenance at all twelve samples.
* magnetic_A/: full radial magnetic Maxwell third-variation blocks between the
  stated n1 output and n0 input, with independent rate placements.
* check_A/: time-integrated source functionals and actual source endpoint conormals;
  original scalar-action and gauge checks.
* magnetic_checks_A/: time-integrated magnetic weak operators and independent
  cubic-action checks.
* existing_odd_coordinate_map.npz: exact signed sparse row inclusion into the
  existing radial4 x full400 odd coordinate convention.

No output contains physical muon spinors or a replacement quantum state. The
finite maps must be integrated with their actual source/interface/native domain.
