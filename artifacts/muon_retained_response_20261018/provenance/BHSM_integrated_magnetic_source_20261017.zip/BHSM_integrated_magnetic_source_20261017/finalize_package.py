"""Record executed comparisons and make the compact reproducible deliverable."""
from pathlib import Path
import hashlib,json,zipfile,sys,platform,shutil
import numpy as np, scipy
P=Path(__file__).resolve().parent
I=P.parent/'BHSM_RETAINED_HISTORY_INPUTS_20261017.zip'
R=P.parent/'BHSM_RETAINED_HISTORY_INPUTS_20261017'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
with zipfile.ZipFile(I) as z:
    bad=z.testzip()
    if bad is not None:raise ValueError('input CRC failed: '+bad)
    zipcount=len(z.infolist())
manifest=json.loads((R/'SHA256SUMS.json').read_text())
assert all(sha(R/n)==h for n,h in manifest.items())
# Exact compatible signed inclusion: new field/internal/h order into old full400.
hsign=np.array([1,-1,1,-1],np.int64)
idx=[];sign=[]
for radial,field,internal,h in np.ndindex(4,5,4,4):
    idx.append(radial*400+(field*4+internal)*20+h);sign.append(hsign[h])
idx=np.array(idx,np.int64);sign=np.array(sign,np.int64)
assert len(set(idx))==320 and np.array_equal(sign**2,np.ones(320,np.int64))
# Compare the existing supplied angular isometry, whose new-column order was
# harmonic-major, against the present field/internal-major representation.
prior=P.parent/'BHSM_forced_canonical_source_20261017/inputs/odd_isometry400x80.npy'
u=np.load(prior);column_order=np.arange(80).reshape(4,20).T.ravel()
expected=np.zeros((400,80));expected[idx[:80],np.arange(80)]=sign[:80]
assert np.array_equal(u[:,column_order],expected)
from integrated_source import save_npz
save_npz(P/'existing_odd_coordinate_map.npz',{'old_full1600_row_indices':idx,'signs':sign})
r=json.loads((P/'replay_A/result.json').read_text())
c=json.loads((P/'check_A/checks.json').read_text())
m=json.loads((P/'magnetic_checks_A/checks.json').read_text())
pairs=[]
for a,b in [('replay_A','replay_B'),('magnetic_A','magnetic_B'),('check_A','check_B'),('magnetic_checks_A','magnetic_checks_B')]:
    for f in sorted((P/a).iterdir()):
        if not f.is_file():continue
        g=P/b/f.name
        assert f.read_bytes()==g.read_bytes(),(f,g)
        pairs.append({'retained_file':f.relative_to(P).as_posix(),'repeat_file':g.relative_to(P).as_posix(),'sha256':sha(f),'byte_identical':True})
assert len(pairs)==33
assert all(c['check_groups'].values()) and all(m['check_groups'].values())
assert max(x['gauss_solve_absolute_residual'] for x in r['records'])<2e-10
verification={
 'classification':'ACTUAL_RETAINED_RADIAL_TIME_MAXWELL_SOURCE_APPLICATION_NOT_PHYSICAL_MUON',
 'input_zip_sha256':sha(I),'input_zip_members':zipcount,'input_zip_CRC_pass':True,
 'recorded_input_hashes_verified':len(manifest),'source_snapshot_text_count':8,
 'original_repository_large_archives_independently_rehashed':False,
 'export_revision':r['validation']['export_revision'],'evaluated_samples':12,
 'radial_points_each':192,'interior_time_points_each_arm':4,
 'n1_field_quadratic_matrix_shape':[320,320],'algebraic_At_dimension':64,
 'remaining_finite_kinetic_dimension':256,'explicit_central_gauge_null_directions':8,
 'magnetic_mixed_block_shape':[3,320,80],
 'independent_scoped_check_groups':{**c['check_groups'],**m['check_groups']},
 'independent_scoped_group_count':len(c['check_groups'])+len(m['check_groups']),
 'gauss_solve_max_absolute':max(x['gauss_solve_absolute_residual'] for x in r['records']),
 'gauss_solve_max_scaled_backward_error':max(x['gauss_solve_scaled_backward_error'] for x in r['records']),
 'independent_original_quadratic_action_max':max(v['absolute'] for x in c['independent_matrix_scalar_action'] for v in x['original_scalar_mixed_checks']),
 'independent_source_b_max':max(v['amplitude_error'] for x in c['independent_matrix_scalar_action'] for v in x['source_checks']),
 'independent_source_bdot_max':max(v['amplitude_rate_error'] for x in c['independent_matrix_scalar_action'] for v in x['source_checks']),
 'independent_magnetic_third_max':max(v['b_error'] for x in m['independent_original_third_derivative'] for v in x['comparisons']),
 'independent_magnetic_rate_third_max':max(v['bdot_error'] for x in m['independent_original_third_derivative'] for v in x['comparisons']),
 'eigenvector_nullspace_comparison_max_not_a_physical_certificate':max(x['kinetic_nullspace_remainder'] for x in c['explicit_gauge_nulls']),
 'exact_existing_odd_map_matches_supplied_isometry':True,
 'time_integrated_source_summary':c['time_integrated_sources'],
 'replayed_result_files':len(pairs),'replay_comparisons':pairs,
 'reference_state_selected':False,'physical_collider_state_constructed':False,
 'complete_physical_outgoing_derivative_admitted':False,'retarded_evolution_executed':False,
 'coupled_corrections':0,'fresh_physical_Maxwell_all226_admitted':False,
 'a_mu':None,'g_mu':None,'total_uncertainty':None,'git_writes':False,
 'error_scope':'fixed finite radial space and supplied quadrature; independent algebra/directional/action checks; no full physical radial, temporal, exterior, state or quantum error enclosure',
 'environment':{'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__},
}
(P/'VERIFICATION.json').write_text(json.dumps(verification,indent=2,sort_keys=True)+'\n')
checkpoint={'stage':'INTEGRATED_RETAINED_MAXWELL_MAGNETIC_SOURCE_AND_HESSIAN_EVALUATED',
 'source_revision':r['validation']['export_revision'],'input_export_sha256':sha(I),
 'completed':['47 exported input hashes and ZIP CRC','12 full radial Maxwell M/B/K assemblies','source-dependent Gauss force and momentum','8 explicit central gauge nulls','n0-to-n1 full Maxwell magnetic third variations','time integrals and original endpoint source conormals','independent original scalar-action checks','33 byte-identical replay files'],
 'NEXT_OPERAND':'Compose the evaluated finite blocks with the actual matter/interface/native and inherited-state source projection; bind the physical spatial and temporal ports and solve the constrained retarded problem. No further export of these retained coefficient inputs is requested.',
 'guard':2e-10,'coupled_corrections':0,'physical_outgoing_derivative':None,'physical_muon_magnetic_moment':None,
 'no_new_physical_ramp_or_boundary_state_selected':True,'Git_updated':False}
(P/'CHECKPOINT.json').write_text(json.dumps(checkpoint,indent=2,sort_keys=True)+'\n')
(P/'development/HISTORY.json').write_text(json.dumps({
 'initial_broadcast_failure':'The direction map was not broadcast to all radial nodes. Raised before any output; explicit broadcast supplied.',
 'harmonic_slice_layout':'Expanded curvature slices include harmonic factors; corrected before first successful assembly.',
 'process_interruptions':'Two check invocations were terminated by tool time limits; partial outputs were not consumed. Complete checks were rerun independently.',
 'raw_eigenvector_alignment':'Reported without tightening; exact central-gauge identities used instead of eigenvalue deletion.',
 'existing_BHSM_source_defect_claimed':False},indent=2,sort_keys=True)+'\n')
(P/'inputs').mkdir(exist_ok=True)
shutil.copyfile(I,P/'inputs'/I.name)
# Package one copy of results; the repeat hashes remain in VERIFICATION and
# the exact reproduction commands are supplied. Do not include Python caches.
allowed_roots={'dependencies','inputs','replay_A','magnetic_A','check_A','magnetic_checks_A'}
files=[]
for f in sorted(P.rglob('*')):
 if not f.is_file() or '__pycache__' in f.parts:continue
 rel=f.relative_to(P)
 if len(rel.parts)==1:
  if f.suffix in ('.md','.py','.json','.npz') and f.name!='SHA256SUMS.json':files.append(f)
 elif rel.parts[0] in allowed_roots: files.append(f)
 elif rel.parts[0]=='development' and len(rel.parts)==2: files.append(f)
(P/'SHA256SUMS.json').write_text(json.dumps({f.relative_to(P).as_posix():sha(f) for f in files},indent=2,sort_keys=True)+'\n')
files.append(P/'SHA256SUMS.json')
archive=P.with_suffix('.zip')
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f in sorted(files):z.write(f,P.name+'/'+f.relative_to(P).as_posix())
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(json.dumps({'zip':str(archive),'size_bytes':archive.stat().st_size,'file_count':len(files),'scoped_groups':verification['independent_scoped_group_count'],'replayed_result_files':len(pairs),'Gauss_residual':verification['gauss_solve_max_absolute']},indent=2))
