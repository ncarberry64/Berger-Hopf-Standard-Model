"""Independent scalar-action, gauge-null and temporal-source checks.

The finite integrals use the uploaded provisional histories, not random field
backgrounds. Random coefficient directions are only numerical derivative tests.
No physical outgoing solution or continuum error certificate is inferred.
"""
from __future__ import annotations
from pathlib import Path
import sys,json,hashlib,ast
import numpy as np
from scipy.special import gammaln
from scipy.linalg import eigh,solve
from integrated_source import (verify_input,save_npz,probe_coefficients,
    FieldJet,FRAME,epsilon,integrate_form,gauss_eliminate,source_columns)

PAULI=np.array([[[0,1],[1,0]],[[0,-1j],[1j,0]],[[1,0],[0,-1]],np.eye(2)],complex)
GENERATORS=-1j*PAULI/np.sqrt(8.)

def rule(which):
    if which==8:return np.r_[np.eye(4),-np.eye(4)],np.full(8,1/8)
    if which==24:
        import itertools
        return np.array(list(itertools.product([-.5,.5],repeat=4))+list(np.eye(4))+list(-np.eye(4))),np.full(24,1/24)
    if which==50:
        # Independent Haar product rule exact for the degree-four scalar action.
        v,w=np.polynomial.legendre.leggauss(2);v=(v+1)/2;w=w/2
        pts=[];ww=[]
        for x,wi in zip(v,w):
            for a in np.arange(5)*2*np.pi/5:
                for b in np.arange(5)*2*np.pi/5:
                    pts.append([np.sqrt(x)*np.cos(a),np.sqrt(x)*np.sin(a),np.sqrt(1-x)*np.cos(b),np.sqrt(1-x)*np.sin(b)])
                    ww.append(wi/25)
        return np.array(pts),np.array(ww)
    raise ValueError(which)

def field_coefficients(sample,q,qd,points):
    q=np.asarray(q).reshape(4,5,4,4);qd=np.asarray(qd).reshape(q.shape)
    b,br=sample['radial_basis'],sample['radial_derivative_basis']
    Y=2*points;EY=2*np.einsum('aij,pj->pai',FRAME,points)
    vals=np.einsum('rb,bfch,ph->rpfc',b,q,Y,optimize=True)
    dt=np.einsum('rb,bfch,ph->rpfc',b,qd,Y,optimize=True)
    dr=np.einsum('rb,bfch,ph->rpfc',br,q,Y,optimize=True)
    ang=np.einsum('rb,bfch,pah->rpafc',b,q,EY,optimize=True)
    return vals,dt,dr,ang

def field_matrices(data):
    return tuple(np.einsum('...c,cij->...ij',x,GENERATORS) for x in data)

def matrix_curvatures(m):
    A,At,Ar,E=m
    comm=lambda a,b:a@b-b@a
    X=At[...,1,:,:]-Ar[...,0,:,:]+comm(A[...,0,:,:],A[...,1,:,:])
    T=At[...,2:,:,:]-E[...,:,0,:,:]+comm(A[...,0,None,:,:],A[...,2:,:,:])
    Z=Ar[...,2:,:,:]-E[...,:,1,:,:]+comm(A[...,1,None,:,:],A[...,2:,:,:])
    B=2*A[...,2:,:,:].copy()
    for i,j,k in ((0,1,2),(1,2,0),(2,0,1)):
        B[...,i,:,:]+=E[...,j,k+2,:,:]-E[...,k,j+2,:,:]+comm(A[...,j+2,:,:],A[...,k+2,:,:])
    return X,T,Z,B

def matrix_action(sample,q,qd,normalization,angular_rule=24):
    points,aw=rule(angular_rule)
    delta=field_coefficients(sample,q,qd,points)
    fields=[sample[k][:,None]+v for k,v in zip(
        ('connection_value','connection_coordinate_time','connection_radial','connection_angular'),delta)]
    X,T,Z,B=matrix_curvatures(field_matrices(fields))
    e,r,da,k,sh=np.moveaxis(sample['metric_densities'],-1,0)
    # Bilinear trace, not conjugating analytic source parameters.
    inner=lambda x: -4*np.trace(x@x,axis1=-2,axis2=-1)
    y=T-sh[:,None,None,None,None]*Z
    value=.5*(k[:,None]*inner(X)+e[:,None]*np.sum(inner(y),axis=-1)
        -r[:,None]*np.sum(inner(Z),axis=-1)-da[:,None]*np.sum(inner(B),axis=-1))
    return np.einsum('r,p,rp->',normalization*sample['radial_quadrature'],aw,value,optimize=True)

def mixed_scalar_derivative(sample,u,ut,v,vt,h,normalization,angular_rule=24):
    def central(step):
        values=[]
        for a,b in ((1,1),(1,-1),(-1,1),(-1,-1)):
            values.append(matrix_action(sample,step*(a*u+b*v),step*(a*ut+b*vt),normalization,angular_rule))
        return (values[0]-values[1]-values[2]+values[3])/(4*step**2)
    # Original polynomial action is quartic. Richardson cancels h^2 exactly.
    return (4*central(h/2)-central(h))/3

def central_gauge_modes(sample,wall):
    alpha=(np.sqrt(45)-3)/2
    ja,jb=2.,4+2*alpha
    def norm(j):
        return np.exp(-(gammaln(j+ja+1)+gammaln(j+jb+1)-gammaln(j+1)-gammaln(j+ja+jb+1)-np.log(2*j+ja+jb+1))/2)
    s0,s1=norm(0),norm(1);c=5+2*alpha;d=8+2*alpha
    P=np.array([[-1/s0,0,0,1],[-(c+d)/(d*s0),-1/(d*s1),0,1]])
    Pd=np.array([[0,0,0,(alpha+1)/wall],[-(alpha+2)/(wall*s0),0,0,(alpha+2)/wall]])
    x=sample['rho']/wall;b=sample['radial_basis'];br=sample['radial_derivative_basis']
    residuals=[np.max(abs(b@P.T-np.c_[x**(alpha+1),x**(alpha+2)])),
               np.max(abs(b@Pd.T-br@P.T))]
    G=np.zeros((4,5,4,4,8));G0=np.zeros((4,5,4,4,8))
    for j,h in np.ndindex(2,4):
        col=4*j+h
        G[:,1,3,h,col]=Pd[j]
        G0[:,0,3,h,col]=P[j]
        for a in range(3):G[:,a+2,3,:,col]=P[j,:,None]*FRAME[a,h,:][None,:]
    return G.reshape(320,8),G0.reshape(320,8),residuals

def check(inputs,run,output):
    inputs,run,output=map(Path,(inputs,run,output));output.mkdir(parents=True,exist_ok=False)
    md,validation=verify_input(inputs);norm=md['MAXWELL_TO_CAP'];rng=np.random.default_rng(171017)
    direct=[];nulls=[];temporal=[]
    for side in ('incoming','outgoing'):
        for label in ('lo','q000','q001','q002','q003','hi'):
            s=dict(np.load(inputs/side/(label+'.npz'),allow_pickle=False));a=dict(np.load(run/(side+'_'+label+'.npz'),allow_pickle=False))
            G,G0,gres=central_gauge_modes(s,md['WALL']);gy=a['gauss_ids'];gz=a['dynamic_ids']
            gl=G[gz];orth=np.linalg.qr(gl)[0];eig,V=eigh((a['Mred']+a['Mred'].T)/2)
            nres={'side':side,'label':label,'gauge_profile_identity_max':float(max(gres)),
                'original_K_gauge_null':float(np.max(abs(a['K']@G))),
                'original_Btranspose_gauge_null':float(np.max(abs(a['B'].T@G))),
                'Gauss_electric_gauge_identity':float(np.max(abs(a['A']@G0[gy]+a['D']@gl))),
                'reduced_kinetic_gauge_null':float(np.max(abs(a['Mred']@gl))),
                'kinetic_nullspace_remainder':float(np.max(abs((np.eye(256)-orth@orth.T)@V[:,:8]))),
                'source_position_annihilation':float(np.max(abs(G.T@a['F_b']))),
                'reduced_source_momentum_annihilation':float(np.max(abs(gl.T@a['hred']))),
                'nonzero_eigenvalue9':float(eig[8])}
            nulls.append(nres)
            if label not in ('lo','hi'):continue
            # Test full ambient coefficient directions, not just an EM compression.
            u=rng.normal(size=320)/np.sqrt(320);ut=rng.normal(size=320)/np.sqrt(320)
            v=rng.normal(size=320)/np.sqrt(320);vt=rng.normal(size=320)/np.sqrt(320)
            expected=u@a['K']@v+u@a['B']@vt+ut@a['B'].T@v+ut@a['M']@vt
            comparisons=[]
            for h in (.5,.25,.125):
                got=mixed_scalar_derivative(s,u,ut,v,vt,h,norm)
                comparisons.append({'step':h,'absolute':float(abs(got-expected)),'value_real':float(got.real)})
            source_rows=[]
            for k in range(3):
                expected0=u@a['F_b'][:,k]+ut@a['H_b'][:,k]
                got0=mixed_scalar_derivative(s,u,ut,a['W'][:,k],a['Wdot'][:,k],.25,norm)
                expected1=u@a['F_bdot'][:,k]+ut@a['H_bdot'][:,k]
                got1=mixed_scalar_derivative(s,u,ut,np.zeros(320),a['W'][:,k],.25,norm)
                source_rows.append({'axis':k,'amplitude_error':float(abs(got0-expected0)),
                                    'amplitude_rate_error':float(abs(got1-expected1))})
            # Independent quadrature check uses full original scalar action, including quartic terms.
            # Use five phase angles rather than four: fourth Fourier harmonics need not vanish at four.
            x24=matrix_action(s,.2*u,.2*ut,norm,24)
            x50=matrix_action(s,.2*u,.2*ut,norm,50)
            beta=s['radial_basis'];electric=s['metric_densities'][:,0]
            coeff=-.5*s['H_selected_charge_coefficients'][3]*probe_coefficients(s)['R4_wall']**2*np.einsum('r,ri,r->i',norm*s['radial_quadrature']*electric,beta,beta[:,3])
            pred=np.zeros((4,4,3))
            for k in range(3):pred[:,3-k,k]=coeff
            central=a['F_bdot'].reshape(4,5,4,4,3)[:,0,3]
            direct.append({'side':side,'label':label,'quadratic_expected':float(expected),
                'independent_angular_action_rule_difference':float(abs(x24-x50)),
                'independent_integrated_central_Gauss_formula_error':float(np.max(abs(pred-central))),
                'original_scalar_mixed_checks':comparisons,'source_checks':source_rows})
        # Actual supplied one-cell quadrature and actual endpoint momenta. No differentiation of a fitted polynomial.
        nodes=[];ws=[]
        for lab in ('q000','q001','q002','q003'):
            nodes.append(dict(np.load(run/(side+'_'+lab+'.npz'))))
            ws.append(json.loads((inputs/side/(lab+'.json')).read_text())['positive_time_quadrature'])
        aa=dict(np.load(run/(side+'_lo.npz')));bb=dict(np.load(run/(side+'_hi.npz')))
        ws=np.array(ws)
        vals={k:np.einsum('t,tij->ij',ws,np.array([n[k] for n in nodes])) for k in ('F_b','F_bdot','H_b','H_bdot','fred','hred')}
        # Euler bulk source for constant test and constant b: int F_b - [H_b].
        vals['constant_b_Euler320']=vals['F_b']-(bb['H_b']-aa['H_b'])
        vals['constant_b_reduced_Euler256']=vals['fred'][:,:3]-(bb['hred'][:,:3]-aa['hred'][:,:3])
        vals['lo_H_b']=aa['H_b'];vals['hi_H_b']=bb['H_b']
        vals['lo_H_bdot']=aa['H_bdot'];vals['hi_H_bdot']=bb['H_bdot']
        vals['lo_reduced_h']=aa['hred'];vals['hi_reduced_h']=bb['hred']
        # Source coefficients in temporal normalized coordinate tau, arbitrary linear b(tau).
        times=np.array([json.loads((inputs/side/(lab+'.json')).read_text())['coordinate_time'] for lab in ('q000','q001','q002','q003')])
        tlo=json.loads((inputs/side/'lo.json').read_text())['coordinate_time'];thi=json.loads((inputs/side/'hi.json').read_text())['coordinate_time'];duration=thi-tlo
        tau=(times-tlo)/duration
        # Assemble weak functional on test 1 and tau, and drive 1 and tau, not selecting a physical ramp.
        weak=np.zeros((2,2,320,3))
        for i in range(2):
            phi=np.ones(4) if i==0 else tau;phid=np.zeros(4) if i==0 else np.ones(4)/duration
            for j in range(2):
                psi=np.ones(4) if j==0 else tau;psid=np.zeros(4) if j==0 else np.ones(4)/duration
                for w,ph,phd,ps,psd,n in zip(ws,phi,phid,psi,psid,nodes):
                    weak[i,j]+=w*(ph*(n['F_b']*ps+n['F_bdot']*psd)+phd*(n['H_b']*ps+n['H_bdot']*psd))
        vals['affine_time_weak_test2_drive2_320x3']=weak
        save_npz(output/(side+'_time_integrated_source.npz'),vals)
        temporal.append({'side':side,'time_interval':[tlo,thi],'time_weight_sum':float(ws.sum()),
            'integrated_F_b_max':float(np.max(abs(vals['F_b']))),
            'constant_b_endpoint_momentum_difference_max':float(np.max(abs(bb['H_b']-aa['H_b']))),
            'constant_b_Euler320_max':float(np.max(abs(vals['constant_b_Euler320']))),
            'constant_b_reduced_Euler256_max':float(np.max(abs(vals['constant_b_reduced_Euler256']))),
            'affine_weak_max':float(np.max(abs(weak))),
            'temporal_convergence_claimed':False})
    result={'input_validation':validation,'independent_matrix_scalar_action':direct,'explicit_gauge_nulls':nulls,
        'time_integrated_sources':temporal,'physical_response_executed':False,'sources_are_per_unit_canonical_charge':True}
    groups={
        'input_archive_hashes':validation['file_hashes_verified']==47,
        'independent_original_quadratic_action':max(v['absolute'] for x in direct for v in x['original_scalar_mixed_checks'])<2e-10,
        'independent_magnetic_drive_source':max(v['amplitude_error'] for x in direct for v in x['source_checks'])<2e-10,
        'independent_drive_rate_source':max(v['amplitude_rate_error'] for x in direct for v in x['source_checks'])<2e-10,
        'independent_angular_quadrature':max(x['independent_angular_action_rule_difference'] for x in direct)<2e-10,
        'literal_integrated_central_Gauss':max(x['independent_integrated_central_Gauss_formula_error'] for x in direct)<2e-10,
        'explicit_gauge_profiles_in_original_radial_span':max(x['gauge_profile_identity_max'] for x in nulls)<2e-12,
        'original_action_and_reduced_kinetic_gauge_identities':max(max(x[k] for k in ('original_K_gauge_null','original_Btranspose_gauge_null','Gauss_electric_gauge_identity','reduced_kinetic_gauge_null')) for x in nulls)<2e-10,
        'gauge_compatible_source_and_momentum':max(max(x[k] for k in ('source_position_annihilation','reduced_source_momentum_annihilation')) for x in nulls)<2e-10,
        'positive_chronological_weights':all(x['time_weight_sum']>0 for x in temporal)
    }
    if not all(groups.values()):raise ArithmeticError('Scoped check group failed: '+str(groups))
    result['check_groups']=groups
    (output/'checks.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps(result,indent=2,sort_keys=True))
    return result

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--inputs',type=Path,required=True);p.add_argument('--run',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();check(a.inputs,a.run,a.output)
