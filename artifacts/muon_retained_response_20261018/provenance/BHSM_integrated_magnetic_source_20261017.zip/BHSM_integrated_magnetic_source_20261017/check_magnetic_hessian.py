"""Independent original scalar-action test of the integrated magnetic insertion."""
from pathlib import Path
import numpy as np,json
from integrated_source import verify_input,probe_coefficients,save_npz
from check_integrated_source import (field_coefficients,field_matrices,matrix_curvatures,rule)

def even_field(sample,v,vt,points):
    v=np.asarray(v).reshape(4,5,4);vt=np.asarray(vt).reshape(4,5,4)
    n=len(points);b,br=sample['radial_basis'],sample['radial_derivative_basis']
    base=lambda c: np.broadcast_to(c[:,None],(len(b),n)+c.shape[1:])
    return (base(np.einsum('rb,bfc->rfc',b,v)),base(np.einsum('rb,bfc->rfc',b,vt)),
        base(np.einsum('rb,bfc->rfc',br,v)),np.zeros((len(b),n,3,5,4)))

def original_action_given_fields(sample,delta,norm,aw):
    data=[sample[k][:,None]+v for k,v in zip(('connection_value','connection_coordinate_time','connection_radial','connection_angular'),delta)]
    X,T,Z,B=matrix_curvatures(field_matrices(data))
    e,r,da,k,sh=np.moveaxis(sample['metric_densities'],-1,0)
    inner=lambda x:-4*np.trace(x@x,axis1=-2,axis2=-1)
    Y=T-sh[:,None,None,None,None]*Z
    value=.5*(k[:,None]*inner(X)+e[:,None]*inner(Y).sum(-1)-r[:,None]*inner(Z).sum(-1)-da[:,None]*inner(B).sum(-1))
    return np.einsum('r,p,rp->',norm*sample['radial_quadrature'],aw,value,optimize=True)

def independent_third(sample,u,ut,v,vt,probe,probed,norm,step,angular=24):
    pts,aw=rule(angular)
    U=field_coefficients(sample,u,ut,pts);V=even_field(sample,v,vt,pts);P=field_coefficients(sample,probe,probed,pts)
    val=0j
    for a,b,c in np.ndindex(2,2,2):
        sa,sb,sc=2*a-1,2*b-1,2*c-1
        delta=tuple(step*(sa*x+sb*y+sc*z) for x,y,z in zip(U,V,P))
        val+=sa*sb*sc*original_action_given_fields(sample,delta,norm,aw)
    # A quartic polynomial has no fifth-order term; the symmetric triple
    # difference isolates exactly the third coefficient, before rounding.
    return val/(8*step**3)

def run(inputs,magnetic,output):
    root,mag,out=map(Path,(inputs,magnetic,output));out.mkdir(parents=True,exist_ok=False)
    md,_=verify_input(root);rng=np.random.default_rng(3171017);rows=[];times=[]
    for side in ('incoming','outgoing'):
        for label in ('lo','hi'):
            s=dict(np.load(root/side/(label+'.npz')));a=dict(np.load(mag/(side+'_'+label+'.npz')));p=probe_coefficients(s)
            u=rng.normal(size=320)/np.sqrt(320);ut=rng.normal(size=320)/np.sqrt(320)
            v=rng.normal(size=80)/np.sqrt(80);vt=rng.normal(size=80)/np.sqrt(80)
            for k in range(3):
                expected=u@a['b_vv'][k]@v+u@a['b_vt'][k]@vt+ut@a['b_tv'][k]@v
                expected_d=u@a['bdot_vv'][k]@v
                comp=[]
                for h in (.5,.25,.125):
                    got=independent_third(s,u,ut,v,vt,p['W'][:,k],p['Wdot'][:,k],md['MAXWELL_TO_CAP'],h)
                    got_d=independent_third(s,u,ut,v,vt,np.zeros(320),p['W'][:,k],md['MAXWELL_TO_CAP'],h)
                    comp.append({'step':h,'b_error':float(abs(expected-got)),'bdot_error':float(abs(expected_d-got_d))})
                rows.append({'side':side,'label':label,'axis':k,'b_expected':float(expected),'bdot_expected':float(expected_d),'comparisons':comp})
        nodes=[dict(np.load(mag/(side+f'_q{i:03d}.npz'))) for i in range(4)]
        ss=[json.loads((root/side/(f'q{i:03d}.json')).read_text()) for i in range(4)]
        ws=np.array([x['positive_time_quadrature'] for x in ss]);ts=np.array([x['coordinate_time'] for x in ss])
        tlo=json.loads((root/side/'lo.json').read_text())['coordinate_time'];thi=json.loads((root/side/'hi.json').read_text())['coordinate_time']
        T=thi-tlo;tau=(ts-tlo)/T
        integrated={k:np.einsum('t,tkij->kij',ws,np.array([x[k] for x in nodes])) for k in nodes[0]}
        full=np.zeros((2,3,2,320,2,80))
        for h,i,j in np.ndindex(2,2,2):
            b=np.ones(4) if h==0 else tau;bd=np.zeros(4) if h==0 else np.ones(4)/T
            phi=np.ones(4) if i==0 else tau;phid=np.zeros(4) if i==0 else np.ones(4)/T
            psi=np.ones(4) if j==0 else tau;psid=np.zeros(4) if j==0 else np.ones(4)/T
            for w,gg,ggd,f,fd,p,pd,a in zip(ws,b,bd,phi,phid,psi,psid,nodes):
                full[h,:,i,:,j,:]+=w*(gg*(f*p*a['b_vv']+f*pd*a['b_vt']+fd*p*a['b_tv'])+ggd*f*p*a['bdot_vv'])
        integrated['affine_drive2_axes3_odd2x320_even2x80']=full
        save_npz(out/(side+'_time_integrated_magnetic_hessian.npz'),integrated)
        times.append({'side':side,'time_integrated_max':{k:float(np.max(abs(v))) for k,v in integrated.items()},'convergence_claimed':False})
    res={'independent_original_third_derivative':rows,'time_integrated_weak_magnetic_operators':times,
        'quantum_magnetic_insertion_or_complete_physical_derivative_evaluated':False}
    groups={
        'independent_integrated_magnetic_third_variation':max(v['b_error'] for r in rows for v in r['comparisons'])<2e-10,
        'independent_integrated_probe_rate_third_variation':max(v['bdot_error'] for r in rows for v in r['comparisons'])<2e-10
    }
    if not all(groups.values()):raise ArithmeticError('Magnetic check failed: '+str(groups))
    res['check_groups']=groups
    (out/'checks.json').write_text(json.dumps(res,indent=2,sort_keys=True)+'\n');print(json.dumps(res,indent=2,sort_keys=True))
    return res

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--inputs',required=True);p.add_argument('--magnetic',required=True);p.add_argument('--output',required=True)
    a=p.parse_args();run(a.inputs,a.magnetic,a.output)
