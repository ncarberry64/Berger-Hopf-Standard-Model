# BHSM magnetic odd-response connection

This package consumes the actual previously evaluated incoming/outgoing spatial
magnetic arrays. It maps their new source into the existing full400 odd frame,
checks ordinary gradient/coexact content, and evaluates the magnetic derivative
of the original spatial gauge identity. It does not solve the physical retarded
or quantum muon problem.

## Reproduce

Python with NumPy and SymPy is required. From this directory:

```text
python check_connection.py --output fresh_run_A
python check_connection.py --output fresh_run_B
```

Existing output folders are not overwritten. The two saved runs contain 46
byte-identical corresponding files. `VERIFICATION.json` gives the exact claim
boundary and hashes; `DERIVATION.md` gives equations and scopes.

`source_inputs/` holds the preserved raw field arrays, magnetic arrays and
predecessor verification/manifest. `dependencies/` contains unchanged copies of
source-derived routines from the preceding supplied packages. The raw-field
provenance is the earlier CRC-verified partial repository archive extraction;
no full original archive SHA verification is claimed.

The physical2e-10 criterion remains unchanged. No coupled state correction,
physical a_mu/g_mu, error bar, repository write, or Windows-worktree change
was produced.
