# Reuse boundary for the physical continuation

1. Compare the source conventions against the live original harmonic functions
   at the current repository revision. This package was anchored at70e82fd4;
   preserve newer work. Integrate only reviewed code/evidence, not caches.
2. The map U sends cartesian n1 harmonic-major80 to
   (field5,internal4,odd20)400. Apply it to each declared weak source and jet.
   Its exact signed permutation is a coordinate map, not a new physical mode.
3. Reuse the complete old odd angular operator implementation, including At/Ar,
   only after updating all background/independent-field/source coefficients to
   the same state as the magnetic insertion. Do not substitute the old central
   hypercharge Green or the old eight-source compression.
4. The coexact n1 component has leading curl squared9; the old regular radial
   Jacobi family is reusable there. The source also has gradient components:
   retain their covariant Gauss/constraint equations and separate endpoint rules.
5. Assemble the integrated radial/history magnetic forcing from the actual
   even response, physical magnetic extension, and total source/interface/native
   jets. The provided wall spatial density is not a surface coupling or a
   complete integrated K_B. Do not multiply it by the old wall Green by shape alone.
6. Use K delta_u = delta_f - (delta_K)u on the common physical domain, including
   moving constraints and trace terms. Test the differentiated spatial gauge
   identity as a regression, but not as physical outgoing-derivative admission.
7. Continue to the2e-10 outgoing derivative check, then a coupled correction and
   fresh preparation-specific original Maxwell/all226 rows. Only an admitted
   state may supply pole/residue, two-spin magnetic response and native overlap
   accounting. No primordial state or magnetic-moment value is chosen here.

The immediate deliverable is the integrated force actually consumed by the
constrained odd retarded solve—not another refinement of the unchanged K_B array.
