"""Evaluate new graph/field response columns; reuse all saved Higgs-only columns.

No physical wall law is closed. The Maxwell normal-shape and gravitational/
GHY/eta/native responses remain uncomputed rather than silently set to zero.
"""
from __future__ import annotations
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1');os.environ.setdefault('OMP_NUM_THREADS','1')
from pathlib import Path
import json,argparse
import numpy as np
from scipy.linalg import solve
import graph_action as ga
from graph_action import ROOT,blocks,maxabs,gauss_table,save_npz,rule8,rule24


def records_for(side,output):
    meta=json.loads((ROOT/'inputs/metadata.json').read_text());T=meta['sides'][side]['duration']
    oldcoef=dict(np.load(ROOT/'inputs'/f'{side}_higgs_coefficients.npz'))
    oldresp=dict(np.load(ROOT/'inputs'/f'{side}_higgs_response.npz'))
    J=np.eye(84);J[:80,:80]=oldresp['coordinate_frame']
    nodes={};rawout={};metrics={'legacy_blocks_max':0.,'angular_rule_max':0.,'literal_base_max':0.,'neutral_shape_gauge_cross_max':0.}
    nd=142;ni=32
    for lab in ('lo','q000','q001','q002','q003','hi'):
        ss=dict(np.load(ROOT/'inputs'/f'{side}_{lab}.npz'));tau=meta['sides'][side]['samples'][lab]['tau']
        a=blocks(ss['raw']);b=blocks(ss['raw'],rule24)
        for key in ('Higgs_M','Higgs_B','Higgs_K','area_per_gamma_M','area_per_gamma_B','area_per_gamma_K'):
            metrics['angular_rule_max']=max(metrics['angular_rule_max'],maxabs(a[key]-b[key]));rawout[lab+'_'+key]=a[key]
        metrics['literal_base_max']=max(metrics['literal_base_max'],maxabs(ga.literal_action(ss['raw'],np.zeros(84),np.zeros(84))-np.array([a['Higgs_value'],a['area_per_gamma_value']])))
        original=ga.wall_data(ss['raw']);shape_cross=a['Higgs_K'][80:84,16:80]@ss['Wg']
        metrics['neutral_shape_gauge_cross_max']=max(metrics['neutral_shape_gauge_cross_max'],maxabs(shape_cross))
        sc=[]
        for name,scale in [('M',1.),('B',T),('K',T*T)]:
            value=scale*J.T@a['Higgs_'+name]@J
            metrics['legacy_blocks_max']=max(metrics['legacy_blocks_max'],maxabs(value[:80,:80]-oldcoef[lab+'_'+name]))
            # The already executed lower blocks are reused byte-for-byte.
            value[:80,:80]=oldcoef[lab+'_'+name]
            sc.append(value)
        M,B,K=sc
        ar={name:scale*J.T@a['area_per_gamma_'+name]@J for name,scale in [('M',1.),('B',T),('K',T*T)]}
        G=np.zeros((68,nd));Gd=np.zeros_like(G)
        G[:64,:64]=np.eye(64);G[:64,64:128]=tau*np.eye(64);Gd[:64,64:128]=np.eye(64)
        W=ss['Wg'];Wd=T*ss['Wgdot'];G[:64,128:131]=W;G[:64,131:134]=tau*W
        Gd[:64,128:131]=Wd;Gd[:64,131:134]=W+tau*Wd
        G[64:,134:138]=np.eye(4);G[64:,138:142]=tau*np.eye(4);Gd[64:,138:142]=np.eye(4)
        mx,bx,kx=M[:16,:16],B[:16,:16],K[:16,:16]
        h=B[16:,:16].T@G+M[:16,16:]@Gd;f=K[:16,16:]@G+B[:16,16:]@Gd
        sol=solve(mx,np.c_[bx.T,np.eye(16),h],assume_a='pos')
        neg=-sol[:,:16];iv=sol[:,16:32];src=-sol[:,32:]
        F=np.block([[neg,iv],[kx+bx@neg,bx@iv]]);force=np.vstack((src,f+bx@src))
        nodes[lab]=dict(M=M,B=B,K=K,G=G,Gd=Gd,F=F,force=force,area=ar,base=a)
        for k in ('Higgs_gradient','area_per_gamma_gradient','Higgs_value','area_per_gamma_value'):
            rawout[lab+'_'+k]=a[k]
        print(side,lab,'graph Hessian and source constructed',flush=True)
    save_npz(output/f'{side}_graph_coefficients.npz',rawout)
    return nodes,oldresp,J,T,metrics


def propagate(side,nodes,old,J,T,output,metrics):
    c,b,A=gauss_table();n=32;nd=142;nt=n+nd;points=[nodes[f'q{i:03d}'] for i in range(4)]
    mat=np.eye(4*n);rhs=np.zeros((4*n,8))
    for i in range(4):
        for j,r in enumerate(points):
            mat[i*n:(i+1)*n,j*n:(j+1)*n]-=A[i,j]*r['F']
            rhs[i*n:(i+1)*n]+=A[i,j]*r['force'][:,134:]
    new=solve(mat,rhs).reshape(4,n,8)
    stage=np.concatenate((old['stages'],new),axis=2)
    initial=np.c_[np.eye(n),np.zeros((n,nd))]
    rates=np.array([r['F']@z+np.c_[np.zeros((n,n)),r['force']] for r,z in zip(points,stage)])
    final=np.concatenate((old['final'],np.einsum('i,ijk->jk',b,rates[:,:,166:])),axis=1)
    wall=np.zeros((nd,nt));awall=np.zeros_like(wall);read={}
    residuals=[]
    for i,lab in enumerate(('lo','q000','q001','q002','q003','hi')):
        r=nodes[lab];z=initial if lab=='lo' else final if lab=='hi' else stage[i-1]
        zd=r['F']@z+np.c_[np.zeros((n,n)),r['force']]
        q=np.vstack((z[:16],np.c_[np.zeros((68,n)),r['G']]))
        qd=np.vstack((zd[:16],np.c_[np.zeros((68,n)),r['Gd']]))
        gradient=r['K']@q+r['B']@qd;momentum=r['M']@qd+r['B'].T@q
        areag=r['area']['K']@q+r['area']['B']@qd;areap=r['area']['M']@qd+r['area']['B'].T@q
        read[lab]=dict(q=q,qd=qd,grad=gradient,mom=momentum,areagrad=areag,areamom=areap)
        residuals.append(maxabs(momentum[:16]-z[16:]))
        if lab.startswith('q'):
            wall+=b[i-1]*(r['G'].T@gradient[16:]+r['Gd'].T@momentum[16:])
            awall+=b[i-1]*(r['G'].T@areag[16:]+r['Gd'].T@areap[16:])
    endpoint=nodes['hi']['G'].T@read['hi']['mom'][16:]-nodes['lo']['G'].T@read['lo']['mom'][16:]
    aendpoint=nodes['hi']['G'].T@read['hi']['areamom'][16:]-nodes['lo']['G'].T@read['lo']['areamom'][16:]
    JS=np.block([[np.zeros((16,16)),np.eye(16)],[-np.eye(16),np.zeros((16,16))]])
    Ff=final[:,n:]
    metrics.update(legacy_stages_byte_preserved=bool(np.array_equal(stage[:,:,:166],old['stages'])),
        legacy_final_byte_preserved=bool(np.array_equal(final[:,:166],old['final'])),
        legacy_wall_difference=maxabs(wall[:134,:166]-old['weak_wall']),
        graph_drive_stage_residual=maxabs(mat@new.reshape(128,8)-rhs),
        scalar_momentum_residual=max(residuals),
        wall_temporal_Green=maxabs(wall[:,n:]-wall[:,n:].T+Ff.T@JS@Ff),
        area_weak_symmetry=maxabs(awall[:,n:]-awall[:,n:].T),
        graph_to_scalar_final_max=maxabs(final[:,166:]),
        graph_to_gauge_wall_max=maxabs(wall[:134,166:]),
        gauge_to_graph_wall_max=maxabs(wall[134:,32:166]),
        graph_endpoint_momentum_max=maxabs(endpoint[134:]),
        area_graph_weak_max_per_gamma=maxabs(awall[134:,166:]),
        area_graph_endpoint_max_per_gamma=maxabs(aendpoint[134:,166:]))
    # Independent unreduced scalar position/momentum/Euler collocation, only new inputs.
    a=np.zeros((128,128));rr=np.zeros((128,8))
    for i,r in enumerate(points):
        ix=slice(32*i,32*i+16);ip=slice(32*i+16,32*(i+1))
        a[ix,ix]=np.eye(16);a[ip,ix]=r['B'][:16,:16].T;a[ip,ip]=r['M'][:16,:16]
        rr[ip]=-r['B'][16:,:16].T@r['G'][:,134:]-r['M'][:16,16:]@r['Gd'][:,134:]
        for j,rj in enumerate(points):
            jx=slice(32*j,32*j+16);jv=slice(32*j+16,32*(j+1))
            a[ix,jv]-=A[i,j]*np.eye(16)
            a[ip,jx]-=A[i,j]*rj['K'][:16,:16];a[ip,jv]-=A[i,j]*rj['B'][:16,:16]
            rr[ip]+=A[i,j]*(rj['K'][:16,16:]@rj['G'][:,134:]+rj['B'][:16,16:]@rj['Gd'][:,134:])
    y=solve(a,rr).reshape(4,32,8);direct=[];dr=[]
    for r,z in zip(points,y):
        q=np.vstack((z[:16],r['G'][:,134:]));qd=np.vstack((z[16:],r['Gd'][:,134:]))
        p=r['M']@qd+r['B'].T@q;gf=r['K']@q+r['B']@qd
        direct.append(np.vstack((z[:16],p[:16])));dr.append(np.vstack((z[16:],gf[:16])))
    direct=np.array(direct);df=np.einsum('i,ijk->jk',b,np.array(dr))
    metrics.update(independent_original_stage_residual=maxabs(a@y.reshape(128,8)-rr),
        independent_original_stage_difference=maxabs(direct-new),independent_original_final_difference=maxabs(df-final[:,166:]))
    save_npz(output/f'{side}_graph_response.npz',dict(stages=stage,final=final,weak_wall=wall,wall_temporal_endpoint=endpoint,
        wall_euler=wall-endpoint,area_weak_per_gamma=awall,area_endpoint_per_gamma=aendpoint,
        coordinate_frame=J,time_scale=T,direct_graph_stages=direct,graph_drive_stage_system=mat,graph_drive_rhs=rhs))
    return metrics


def run(output):
    out=Path(output)
    if out.exists():raise FileExistsError('preserve prior scientific output')
    out.mkdir(parents=True)
    result=[]
    for side in ('incoming','outgoing'):
        nodes,old,J,T,measures=records_for(side,out)
        m=propagate(side,nodes,old,J,T,out,measures)
        # A sparse n1 displacement is evaluated; no gamma or physical source selected.
        m['first_sample_area_coefficients_per_gamma']={key:float(nodes['lo']['base']['area_per_gamma_'+key][80,80]) for key in ('M','B','K')}
        m['first_sample_normal_Higgs_cross_max']=float(maxabs(nodes['lo']['base']['Higgs_K'][:16,80:]))
        result.append(dict(side=side,measures=m))
        print(json.dumps(result[-1],sort_keys=True),flush=True)
    claims=dict(classification='EVALUATED_INTRINSIC_NORMAL_GRAPH_HIGGS_AND_SYMBOLIC_AREA_RESPONSE',
        input_revision='70e82fd4dbe5f53ff27ae17f6aaac7a4727c1fde',
        initial_fields_selected=False,normal_graph_selected_as_physical_mode=False,
        membrane_strength_selected=False,normal_Maxwell_GHY_bulk_response_evaluated=False,
        physical_wall_closed=False,full_physical_derivative_admitted=False,coupled_corrections=0,
        physical_a_mu=None,physical_g_mu=None,total_uncertainty=None,git_writes=False,
        records=result,error_scope='fixed n1 source/response and supplied four-node temporal rule; original-action/directional/DAE controls only, no time/radial/physical-domain enclosure')
    (out/'result.json').write_text(json.dumps(claims,indent=2,sort_keys=True,allow_nan=False)+'\n')

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True)
    run(p.parse_args().output)
