"""Independent high-precision metric/doublet checks and explicit omission probes."""
from __future__ import annotations
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1');os.environ.setdefault('OMP_NUM_THREADS','1')
import argparse,json
from pathlib import Path
import numpy as np
import mpmath as mp
import torch
import graph_action as ga
from graph_action import ROOT,maxabs,rule8,FRAME,RADIUS0,C_ORBIT,LAM,NU2


def mp_action(raw,coeff,rate,*,uniform=False):
    r=[mp.mpf(float(x)) for x in raw];q=r[:37];v=r[37:74];m=r[74:98]
    pi=mp.mpf(float(np.pi));R0=mp.mpf(float(RADIUS0));
    cs=R0*mp.exp(q[0]+sum(q[1+k]*(-1)**(k+1) for k in range(12))+sum(q[13+j]*(-1)**j for j in range(12)))
    lc=v[0]+sum(v[1+k]*(-1)**(k+1) for k in range(12))+sum(v[13+j]*(-1)**j for j in range(12))
    independent=np.array(raw[100:180]).reshape(4,5,4)[3][[0,2,3,4]]
    pointset,w=rule8();total=[mp.mpf(0),mp.mpf(0)]
    pauli=[mp.matrix([[0,1],[1,0]]),mp.matrix([[0,-mp.j],[mp.j,0]]),mp.matrix([[1,0],[0,-1]])]
    G=[(-mp.j/(2*mp.sqrt(2)))*p for p in pauli]+[-mp.j/(2*mp.sqrt(mp.mpf(10)/3))*mp.eye(2)]
    for p in range(len(w)):
        Y=[mp.mpf(float(x)) for x in 2*pointset[p]]
        DY=[[mp.mpf(float(z)) for z in rr] for rr in 2*np.einsum('aij,j->ai',FRAME,pointset[p])]
        if uniform:
            sval=coeff[80];srate=rate[80];grad=[mp.mpf(0)]*3
        else:
            sval=sum(Y[k]*coeff[80+k] for k in range(4));srate=sum(Y[k]*rate[80+k] for k in range(4));grad=[sum(DY[a][k]*coeff[80+k] for k in range(4))/cs for a in range(3)]
        sig=r[98]+sval;chi=pi/4+sig/cs;chidot=(r[99]+srate-lc*sig)/cs
        ck=[mp.cos(4*k*chi) for k in range(1,13)];cj=[mp.cos(4*j*chi) for j in range(12)]
        wi=mp.sin(2*chi)**2;u=sum(ck[j]*q[1+j] for j in range(12));ww=wi*sum(cj[j]*q[13+j] for j in range(12));bb=wi*sum(cj[j]*q[25+j] for j in range(12))
        radius=R0*mp.exp(q[0]);C=radius*mp.exp(u+ww);A=radius*mp.exp(u+bb)*mp.cos(chi);B=radius*mp.exp(u-bb)*mp.sin(chi)
        N=mp.exp(sum(ck[j]*m[j] for j in range(12)));bet=mp.sin(4*chi)*sum(cj[j]*m[12+j] for j in range(12));LF=mp.sqrt(A*A+B*B);R=A*B/LF;lam=A*A/(LF*LF)
        vv=mp.matrix([chidot+bet]+grad);metric=mp.diag([N*N,-R*R,-R*R,-R*R])-C*C*vv*vv.T
        vol=mp.sqrt(-mp.det(metric));hd=vol*metric**-1
        hr=[r[260+i]+sum(coeff[4*i+k]*Y[k] for k in range(4)) for i in range(4)]
        htr=[r[264+i]+sum(rate[4*i+k]*Y[k] for k in range(4)) for i in range(4)]
        dhr=[[sum(coeff[4*i+k]*DY[a][k] for k in range(4)) for i in range(4)] for a in range(3)]
        H=mp.matrix([hr[0]+mp.j*hr[2],hr[1]+mp.j*hr[3]])
        dh=[mp.matrix([htr[0]+mp.j*htr[2],htr[1]+mp.j*htr[3]])]+[mp.matrix([row[0]+mp.j*row[2],row[1]+mp.j*row[3]]) for row in dhr]
        for f in range(4):
            op=mp.zeros(2)
            for c in range(4):
                g=mp.mpf(float(independent[f,c]))+sum(coeff[16+(f*4+c)*4+k]*Y[k] for k in range(4))
                if f>0 and c==f-1:g+=mp.sqrt(8)*(lam-1)
                op+=g*G[c]
            dh[f]+=op*H
        kinetic=sum(hd[f,g]*(dh[f].conjugate().T*dh[g])[0] for f in range(4) for g in range(4)).real
        norm=sum(abs(x)**2 for x in H)
        total[0]+=mp.mpf(float(w[p]))*mp.mpf(float(C_ORBIT))*(kinetic-vol*mp.mpf(float(LAM))*(norm-mp.mpf(float(NU2)))**2)
        total[1]-=mp.mpf(float(w[p]))*vol*LF**3
    return total


def checked_hessian(co,sector):
    M,B,K=(co[f'{sector}_{name}'] for name in ('M','B','K'))
    return np.block([[K,B[:,ga.RATE]],[B[:,ga.RATE].T,M[np.ix_(ga.RATE,ga.RATE)]]])

def run(out):
    out=Path(out);out.mkdir(parents=True,exist_ok=False);mp.mp.dps=65
    data=[];rng=np.random.default_rng(173901)
    for side in ('incoming','outgoing'):
        raw=np.load(ROOT/'inputs'/f'{side}_lo.npz')['raw']
        saved=np.load(ROOT/'replay_A'/f'{side}_graph_coefficients.npz')
        blocks={k[len('lo_'):]:saved[k] for k in saved.files if k.startswith('lo_')}
        hess=[checked_hessian(blocks,s) for s in ('Higgs','area_per_gamma')]
        vv=[]
        for kind in ('normal_value','normal_rate','mixed_field_graph'):
            d=np.zeros(104)
            if kind=='normal_value':d[80]=1.
            elif kind=='normal_rate':d[100]=1.
            else:
                d=rng.standard_normal(104);d/=np.linalg.norm(d);d[80]=.65;d[100]=.25
            q=[mp.mpf(float(x)) for x in d[:84]];qd=[mp.mpf(0)]*84
            for i,v in zip(ga.RATE,d[84:]):qd[i]=mp.mpf(float(v))
            f=lambda t:mp_action(raw,[t*x for x in q],[t*x for x in qd])
            exact=[mp.diff(lambda t:f(t)[s],mp.mpf(0),2) for s in range(2)]
            actual=[float(d@hh@d) for hh in hess]
            steps=[]
            for st in (.002,.001,.0005):
                h=mp.mpf(str(st));values={j:f(j*h) for j in (-2,-1,0,1,2)}
                der=[(-values[2][s]+16*values[1][s]-30*values[0][s]+16*values[-1][s]-values[-2][s])/(12*h*h) for s in range(2)]
                steps.append(dict(step=st,truncation_to_mp_derivative=[float(abs(x-y)) for x,y in zip(der,exact)],absolute_to_binary64_hessian=[float(abs(x-y)) for x,y in zip(der,actual)]))
            vv.append(dict(direction=kind,mp_hessian=[float(x) for x in exact],original_minus_assembled=[float(abs(x-y)) for x,y in zip(exact,actual)],finite_difference_sweep=steps))
        # Independently derive spatial contribution from the homogeneous area law.
        z=[mp.mpf(0)]*84
        def area_hom(t,u):
            q=z.copy();r=z.copy();q[80]=t;r[80]=u
            return mp_action(raw,q,r,uniform=True)[1]
        homss=mp.diff(lambda x:area_hom(x,0),mp.mpf(0),2)
        homsr=mp.diff(lambda x:mp.diff(lambda y:area_hom(x,y),mp.mpf(0)),mp.mpf(0))
        homrr=mp.diff(lambda x:area_hom(0,x),mp.mpf(0),2)
        w0=ga.wall_data(raw);b0=ga.base(raw)
        r4=w0['R4'];rho=w0['A']**3*w0['B']**3;N=w0['ambient_lapse'];C=w0['C'];root=w0['lapse']/N
        grad_coeff=-N*rho*C*C/(r4*r4*root*b0['cs']**2)
        predicted=np.array([float(homss)+3*grad_coeff,float(homsr),float(homrr)])
        actual=np.array([blocks['area_per_gamma_K'][80,80],blocks['area_per_gamma_B'][80,80],blocks['area_per_gamma_M'][80,80]])
        # Deliberately incomplete geometry controls; keep them distinct from original code.
        x=torch.zeros(104,requires_grad=True)
        diagonal=torch.autograd.functional.hessian(lambda x:ga.torch_action(raw,x,diagonal_metric_control=True)[0],x,vectorize=True).detach().numpy()
        frozen=torch.autograd.functional.hessian(lambda x:ga.torch_action(raw,x,frozen_fiber_control=True)[1],x,vectorize=True).detach().numpy()
        errors=dict(diagonal_metric_hessian_difference=maxabs(diagonal-hess[0]),frozen_fiber_area_hessian_difference=maxabs(frozen-hess[1]))
        row=dict(side=side,independent_high_precision=vv,area_homogeneous_plus_angular_identity_difference=maxabs(predicted-actual),area_homogeneous_plus_angular_values=predicted.tolist(),area_gradient_coefficient=grad_coeff,omission_controls=errors)
        data.append(row);print(json.dumps(row),flush=True)
    (out/'checks.json').write_text(json.dumps(dict(records=data,scope='Independent local action derivatives on retained samples, not full outgoing derivative',physical_admission=False),indent=2,sort_keys=True)+'\n')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);run(p.parse_args().output)
