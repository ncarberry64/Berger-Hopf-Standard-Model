# Development and retained nonpasses

The scope of the new program was narrowed to the original intrinsic Higgs action
and symbolic membrane area. The general angular Maxwell shape, full gravitational,
eta, GHY/Hayward and native sectors were not guessed or filled with zeros.

The finite-step second-derivative sweeps at 0.002, 0.001 and 0.0005 include
truncation discrepancies above 2e-10. All are saved in check_A/checks.json and its
independent repeat. Their approximately sixteenfold reduction under step halving
and agreement with an independent high-precision derivative identify truncation
at this tested local scope. No physical derivative admission follows.

Deliberately incomplete diagonal-metric and frozen-fiber formulas are used only
for explicit omission controls; their nonzero changes are not errors assigned
to the historical BHSM code.

The earlier Maxwell reconstruction failure is inherited unchanged. No new source
formula was adjusted to force that test to pass.
