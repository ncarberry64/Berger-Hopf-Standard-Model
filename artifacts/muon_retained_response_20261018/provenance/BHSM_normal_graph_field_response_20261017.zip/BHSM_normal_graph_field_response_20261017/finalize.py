"""Finalize manifest and honest claim ledger for the executed continuation."""
from pathlib import Path
import hashlib,json,zipfile,sys
import numpy,scipy,torch,mpmath
ROOT=Path(__file__).resolve().parent

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def verify_old(name):
    p=Path('/mnt/data/work_inputs')/name
    manifest=p/'SHA256SUMS.json'; hashes=json.loads(manifest.read_text())
    for filename,digest in hashes.items():
        if sha(p/filename)!=digest:raise ValueError('input mismatch: '+str(p/filename))
    return {'manifest_sha256':sha(manifest),'verified_count':len(hashes)}

def finish():
    manifests={name:verify_old(name) for name in ('BHSM_higgs_wall_coupled_response_20261017','BHSM_RETAINED_HISTORY_INPUTS_20261017')}
    replay=[]
    for suba,subb in [('replay_A','replay_B'),('check_A','check_B'),('gauge_A','gauge_B')]:
        for p in sorted((ROOT/suba).iterdir()):
            q=ROOT/subb/p.name
            if p.read_bytes()!=q.read_bytes(): raise ValueError('nonidentical replay '+p.name)
            replay.append({'path':p.relative_to(ROOT).as_posix(),'repeat':q.relative_to(ROOT).as_posix(),'byte_identical':True,'sha256':sha(p)})
    results=json.loads((ROOT/'replay_A/result.json').read_text())
    c=json.loads((ROOT/'check_A/checks.json').read_text())
    gauges=json.loads((ROOT/'gauge_A/checks.json').read_text())
    maxmp=max(v for row in c['records'] for r in row['independent_high_precision'] for v in r['original_minus_assembled'])
    lastfd=max(v for row in c['records'] for r in row['independent_high_precision'] for v in r['finite_difference_sweep'][-1]['absolute_to_binary64_hessian'])
    gauge=max(d['complete_mixed_gauge_shape_residual'] for row in gauges['records'] for d in row['samples'])
    g={
        'input_integrity':True,
        'legacy_columns_unchanged':all(x['measures']['legacy_final_byte_preserved'] and x['measures']['legacy_stages_byte_preserved'] and x['measures']['legacy_wall_difference']==0 for x in results['records']),
        'independent_quadratic_angular_rule':max(x['measures']['angular_rule_max'] for x in results['records'])<2e-10,
        'independent_original_high_precision_local_derivative':maxmp<2e-10,
        'homogeneous_area_plus_angular_identity':max(x['area_homogeneous_plus_angular_identity_difference'] for x in c['records'])<2e-10,
        'independent_original_scalar_stage_equations':max(x['measures']['independent_original_stage_difference'] for x in results['records'])<2e-10,
        'complete_scalar_canonical_momentum':max(x['measures']['scalar_momentum_residual'] for x in results['records'])<2e-10,
        'boundary_and_temporal_Green_identity':max(x['measures']['wall_temporal_Green'] for x in results['records'])<2e-10,
        'mixed_gauge_shape_identity':gauge<2e-10,
        'direct_neutral_Higgs_shape_cancellation':max(x['measures']['neutral_shape_gauge_cross_max'] for x in results['records'])<2e-10,
    }
    assert all(g.values())
    verification=dict(
        classification=results['classification'],source_revision=results['input_revision'],
        scoped_checks=g,scoped_check_group_count=len(g),all_new_scoped_checks_pass=all(g.values()),
        input_manifests=manifests,replay_byte_identical=True,replay_comparisons=replay,
        actual_retained_samples=12,old_Higgs_response_columns_reused=166,new_graph_drive_columns=8,
        independent_mp_local_Hessian_max_absolute=maxmp,independent_mp_decimal_precision=65,
        last_recorded_finite_step_comparison_max=lastfd,
        all_last_recorded_finite_step_checks_below_2e_10=bool(lastfd<2e-10),
        mixed_gauge_shape_identity_max=gauge,
        membrane_strength_selected=False,initial_physical_state_selected=False,
        normal_Maxwell_geometry_eta_GHY_native_completed=False,
        topology_changing_cascade_evaluated=False,physical_wall_equation_closed=False,
        physical_outgoing_derivative_admitted=False,physical_Maxwell_all226_admitted=False,
        previous_Maxwell_gauge_reconstruction_failure_resolved=False,
        coupled_background_corrections=0,a_mu=None,g_mu=None,total_uncertainty=None,git_writes=False,
        numerical_method='four-stage Gauss collocation on supplied nodes, original local graph Hessian, independent original scalar DAE and complex action derivative',
        error_scope='finite local/temporal consistency; no continuum, temporal, radial, physical state/domain or total error enclosure',
        environment={'python':sys.version,'numpy':numpy.__version__,'scipy':scipy.__version__,'torch':torch.__version__,'mpmath':mpmath.__version__},
        results=results['records'],independent_checks=c['records'])
    (ROOT/'VERIFICATION.json').write_text(json.dumps(verification,indent=2,sort_keys=True,allow_nan=False)+'\n')
    checkpoint=dict(stage=results['classification'],input_revision=results['input_revision'],
        reusable='New graph-Higgs forcing and returned normal response plus symbolic area coefficients; old field response unchanged',
        next_operand='Compatible Maxwell-shape and geometry/eta/GHY/interface/current/native response on the same nonuniform material graph, with actual physical wall and transition equations. Do not substitute old homogeneous coefficients or set missing sectors to zero.',
        full_physical_outgoing_derivative_admitted=False,physical_wall_equation_closed=False,
        physical_a_mu=None,physical_g_mu=None,uncertainty=None,coupled_corrections=0,
        old_Maxwell_field_reconstruction_failure_preserved=True,
        all_last_finite_step_comparisons_at_guard=False,membrane_gamma=None,
        measured_scalar_ancestry='Inherited calibrated lambda_H and nu_squared_action=4 unchanged',
        git_writes=False)
    (ROOT/'CHECKPOINT.json').write_text(json.dumps(checkpoint,indent=2,sort_keys=True)+'\n')
    # Exclude transient compilation caches and the manifest itself.
    hashes={p.relative_to(ROOT).as_posix():sha(p) for p in sorted(ROOT.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.name!='SHA256SUMS.json'}
    (ROOT/'SHA256SUMS.json').write_text(json.dumps(hashes,indent=2,sort_keys=True)+'\n')
    out=ROOT.with_suffix('.zip')
    with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as zz:
        for p in sorted(ROOT.rglob('*')):
            if p.is_file() and '__pycache__' not in p.parts:
                zi=zipfile.ZipInfo(ROOT.name+'/'+p.relative_to(ROOT).as_posix(),(2026,10,17,0,0,0));zi.compress_type=zipfile.ZIP_DEFLATED
                zz.writestr(zi,p.read_bytes(),compresslevel=6)
    with zipfile.ZipFile(out) as z:
        if z.testzip() is not None:raise ValueError('output CRC failure')
    print(json.dumps({'input_manifests':manifests,'output_files_hashed':len(hashes),'replay_files':len(replay),'scoped_groups':len(g),'zip':str(out),'zip_bytes':out.stat().st_size,'zip_sha256':sha(out),'mp_max':maxmp,'last_fd_max':lastfd,'gauge_max':gauge},indent=2))
if __name__=='__main__':finish()
