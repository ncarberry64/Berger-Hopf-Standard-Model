# BHSM normal-graph Higgs / symbolic interface response

This package supplies finite n1 boundary-deformation response columns on the
actual retained incoming/outgoing samples. Read DERIVATION.md before interpreting
its arrays. It does not close the physical wall or calculate a magnetic moment.

Dependencies: Python, NumPy, SciPy, PyTorch (CPU/double), mpmath.

Reproduce:

```text
python run_graph_response.py --output replay_new
python check_graph_action.py --output checks_new
python check_graph_gauge.py --output gauge_new
```

The two check scripts use the published replay_A matrices for their independent
comparison. No download, new physical input, Git change, or Windows access occurs.
The run script rejects an existing output directory to preserve evidence.

Map input ordering: scalar canonical initial32, old wall-drive134, graph-drive8.
Normal drives are four n1 coordinates times 1 and tau. Wall outputs: old134,
normal8. Gamma is symbolic; do not choose it as one for a physical answer or assume
missing Maxwell/geometry/native terms vanish. Initial fields are arbitrary inputs.

The old 166 response columns are reused byte-for-byte. The complete fixed-boundary
Maxwell/Higgs map is NOT re-added or replaced by this scalar normal-port extension.
Only the new mixed/normal blocks should be coupled with compatible existing work.

Finite-step derivative truncation and prior Maxwell reconstruction failures remain
explicit. Tiny stage residuals are numerical checks, not continuum error bars.
