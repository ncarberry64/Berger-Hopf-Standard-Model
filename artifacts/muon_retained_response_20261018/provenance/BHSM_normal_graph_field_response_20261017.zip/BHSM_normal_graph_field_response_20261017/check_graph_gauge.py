"""Gauge/shape Ward identity including motion of the mechanical connection.

An off-shell mixed derivative is not a physical gauge-breaking force. This
check evaluates the original Higgs action's necessary second-map contact.
"""
from __future__ import annotations
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1');os.environ.setdefault('OMP_NUM_THREADS','1')
import json,argparse
from pathlib import Path
import numpy as np
import graph_action as g
from build_higgs_response import higgs_blocks

def run(out):
    out=Path(out);out.mkdir(parents=True,exist_ok=False);records=[]
    for side in ('incoming','outgoing'):
        co=np.load(g.ROOT/'replay_A'/f'{side}_graph_coefficients.npz');group=[]
        for lab in ('lo','q000','q001','q002','q003','hi'):
            raw=np.load(g.ROOT/'inputs'/f'{side}_{lab}.npz')['raw'];base=higgs_blocks(raw)
            rr=raw.astype(complex);rr[98]+=1e-20j;ls=g.wall_data(rr)['lam'].imag/1e-20
            K=co[f'{lab}_Higgs_K'];B=co[f'{lab}_Higgs_B'];H=raw[260:264];Hd=raw[264:268]
            gr=g.generators()[1];A=base['wall']['connection'][[0,2,3,4]]
            errors=[];firsts=[];contacts=[]
            for c,h in np.ndindex(4,4):
                t=np.zeros(84);td=np.zeros(84);t[:16].reshape(4,4)[:,h]=-gr[c]@H;td[:16].reshape(4,4)[:,h]=-gr[c]@Hd
                tg=t[16:80].reshape(4,4,4)
                for f in range(4):
                    if c<3:tg[f,:3,h]=np.cross(A[f,:3],np.eye(3)[c])/np.sqrt(2)
                    if f>0:tg[f,c,:]+=g.FRAME[f-1,h,:]
                partial=K[80:]@t+B[80:]@td
                correction=np.zeros(4)
                if c<3:
                    for f in range(1,4):
                        comm=2*ls*np.cross(np.eye(3)[f-1],np.eye(3)[c])
                        correction[h]+=base['gauge_grad'][f,:3]@comm
                errors.append(partial+correction);firsts.append(partial);contacts.append(correction)
            errors=np.array(errors);firsts=np.array(firsts);contacts=np.array(contacts)
            row=dict(sample=lab,complete_mixed_gauge_shape_residual=g.maxabs(errors),without_mechanical_frame_contact=g.maxabs(firsts),contact_max=g.maxabs(contacts),mechanical_lambda_shape_first=float(ls))
            group.append(row)
        records.append(dict(side=side,samples=group))
    (out/'checks.json').write_text(json.dumps(dict(records=records,scope='Higgs mixed gauge/material-graph identity on twelve retained samples; not full BRST/native domain'),indent=2,sort_keys=True)+'\n')
    print(json.dumps(records,indent=2))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);run(p.parse_args().output)
