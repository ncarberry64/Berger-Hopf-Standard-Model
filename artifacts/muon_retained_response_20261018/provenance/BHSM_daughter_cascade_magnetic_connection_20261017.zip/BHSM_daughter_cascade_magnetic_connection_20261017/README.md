# Daughter-cascade magnetic connection

This package contains a conditional mathematical reduction, not a muon prediction.
Read DERIVATION.md for the physical and domain assumptions.

Run with Python, NumPy, SciPy and SymPy:

```text
python check_connection.py --output fresh_check/result.json
```

`cascade_connection.py` supplies tested finite contracted derivatives and
pole-response utilities. It does not construct missing physical operator blocks,
choose the inherited sea, assign a fragmentation rate or act on the user's Git
worktree. Continuum solver/domain adapters must be supplied from the actual BHSM
action. The accompanying results use constructed matrices and a supplied reset
control, never physical muon operands.

Repository anchor read: 70e82fd4dbe5f53ff27ae17f6aaac7a4727c1fde, PR #465.
Existing stored Maxwell/geometry/source/daughter results were not recomputed.
Both existing replays are retained with hashes. No GitHub update was made.
