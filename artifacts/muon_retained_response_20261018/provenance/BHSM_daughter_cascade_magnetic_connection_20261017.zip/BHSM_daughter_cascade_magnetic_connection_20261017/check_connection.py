"""Executed algebra controls for the cascade-to-pole connection, NOT BHSM data."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import numpy as np
import sympy as sp
from scipy.linalg import expm
from scipy.integrate import quad_vec
from cascade_connection import (Blocks, prepare_return, contracted_first, pole_first,
                                event_sensitivity, stationary_analyzer_signal, PAULI)


def norm(x):
    return float(np.max(abs(np.asarray(x))))


def test_all():
    checks={}
    s=sp.symbols('s', real=True)
    aa,bb,cc,dd=[sp.Function(q)(s) for q in ('A','B','C','D')]
    expected=sp.diff(aa,s)-sp.diff(bb,s)*cc/dd-bb*sp.diff(cc,s)/dd+bb*sp.diff(dd,s)*cc/dd**2
    assert sp.simplify(sp.diff(aa-bb*cc/dd,s)-expected)==0
    checks['exact_scalar_schur_product_rule']={'passed':True}

    # A constructed complex analytic matrix curve, not an operator fitted to data.
    rng=np.random.default_rng(7017)
    def rand(shape): return (rng.normal(size=shape)+1j*rng.normal(size=shape))/7
    A0=rand((3,3)); B0=rand((3,5)); C0=rand((5,3)); D0=np.eye(5)*3+rand((5,5))
    A1=rand((3,3)); B1=rand((3,5)); C1=rand((5,3)); D1=rand((5,5))
    L=rand((2,3));R=rand((3,2))
    def curve(t):
        return Blocks(A0+t*A1+(t*t)*np.eye(3)/11,
                      B0+t*B1, C0+t*C1, D0+t*D1+t*t*np.eye(5)/13)
    base=curve(0);pr=prepare_return(base,L,R)
    jet=Blocks(A1,B1,C1,D1)
    analytic=contracted_first(pr,jet)
    def literal(t):
        q=curve(t)
        # Independent original full inverse, compressed and inverted to Schur.
        full=np.block([[q.A,q.B],[q.C,q.D]])
        geff=np.linalg.inv(full)[:3,:3]
        return L@np.linalg.inv(geff)@R
    errors=[]
    for h in (0.02,0.01,0.005,0.0025):
        fd=(-literal(2*h)+8*literal(h)-8*literal(-h)+literal(-2*h))/(12*h)
        errors.append({'step':h,'max_absolute':norm(fd-analytic)})
    assert errors[-1]['max_absolute']<2e-10
    checks['analytic_left_contraction_vs_full_inverse_derivative']={
        'passed':True,'steps':errors,'base_max_absolute':norm(pr.reduced-literal(0))}

    # A constructed degenerate two-spin Hamiltonian with a coupled daughter block.
    I=np.eye(2);x,y,z=PAULI
    e0,ed,v=1.,3.,0.4
    hm=-0.7*z+0.13*x
    hd=0.21*z+0.05*y
    w=0.03*x+0.02j*z
    E0=(e0+ed-np.sqrt((e0-ed)**2+4*v*v))/2
    def H(B):
        return np.block([[e0*I+B*hm,v*I+B*w.conj().T],
                         [v*I+B*w,ed*I+B*hd]])
    b0=Blocks((E0-e0)*I,-v*I,-v*I,(E0-ed)*I)
    p0=prepare_return(b0,I,I)
    zero=np.zeros((2,2))
    ej=Blocks(I,zero,zero,I)
    bj=Blocks(-hm,-w.conj().T,-w,-hd)
    response=pole_first(p0,ej,{'B':bj})
    eig=np.linalg.eigvalsh(response['B'])
    rows=[]
    for h in (0.002,0.001,0.0005,0.00025):
        ep=np.linalg.eigvalsh(H(h))[:2]
        em=np.linalg.eigvalsh(H(-h))[:2][::-1]
        slopes=(ep-em)/(2*h)
        rows.append({'step':h,'max_absolute':norm(slopes-eig)})
    assert rows[-1]['max_absolute']<2e-9
    U=np.vstack((I,v/(E0-ed)*I))/np.sqrt(1+v*v/(E0-ed)**2)
    direct=U.conj().T@np.block([[hm,w.conj().T],[w,hd]])@U
    assert norm(direct-response['B'])<1e-14
    unnormalized=-contracted_first(p0,bj)
    checks['two_spin_pole_including_residue']={
        'passed':True,'base_reduced_residual':norm(p0.reduced),
        'full_normalized_pole_comparison':norm(direct-response['B']),
        'omitting_Z_changes_result':norm(unnormalized-response['B']),
        'finite_field_step_checks':rows,
        'scope':'constructed dimensionless control; eigenvalues are not BHSM magnetic moments'}

    # Sequential daughter sectors must be eliminated coherently, not added as
    # independent rates or independently inverted while cross coupling is present.
    H0=H(0)
    V12=np.array([[.07,.03j],[-.02j,.06]])
    H6=np.block([[H0[:2,:2],H0[:2,2:],np.zeros((2,2))],
                 [H0[2:,:2],H0[2:,2:],V12],
                 [np.zeros((2,2)),V12.conj().T,4*np.eye(2)+.04*x]])
    zz=.9+.2j
    K=zz*np.eye(6)-H6
    directS=K[:2,:2]-K[:2,2:]@np.linalg.solve(K[2:,2:],K[2:,:2])
    mid=K[2:4,2:4]-K[2:4,4:]@np.linalg.solve(K[4:,4:],K[4:,2:4])
    staged=K[:2,:2]-K[:2,2:4]@np.linalg.solve(mid,K[2:4,:2])
    uncoupled=K[:2,:2]-K[:2,2:4]@np.linalg.solve(K[2:4,2:4],K[2:4,:2])
    assert norm(directS-staged)<1e-14 and norm(directS-uncoupled)>1e-6
    checks['cascade_elimination_and_cross_sector_return']={
        'passed':True,'staged_vs_joint':norm(directS-staged),
        'deleted_cross_coupling_error':norm(directS-uncoupled)}

    # Exact elimination in time retains a complement initial amplitude.
    initial=np.array([.8,.1j,.2,.15j],complex);initial/=np.linalg.norm(initial)
    t=.7
    full=expm(-1j*H0*t)@initial
    zfree=expm(-1j*ed*I*t)@initial[2:]
    def integrand(s):
        mu=(expm(-1j*H0*s)@initial)[:2]
        return expm(-1j*ed*I*(t-s))@(v*I)@mu
    integral,error=quad_vec(integrand,0,t,epsabs=1e-13,epsrel=1e-13)
    restored=zfree-1j*integral
    assert norm(restored-full[2:])<1e-13
    checks['chronological_elimination_retains_initial_complement']={
        'passed':True,'original_history_comparison':norm(restored-full[2:]),
        'quadrature_estimate':float(error),'omitted_initial_return_error':norm(zfree)}

    # Event-time dependence; before/after dimensions differ. The guard and reset
    # are deliberately chosen controls, not BHSM formation laws.
    fm=np.array([1.,2.]);fp=np.array([.7,-.2,.1]);x0=np.array([.2,-.4]);par=.05;T=2.
    def trajectory(xinit,p):
        tau=1+.2*p-xinit[0]
        xm=xinit+fm*tau
        reset=np.array([xm[0]+.3*xm[1]+p*tau,-xm[1]+.1*p,.4*xm[0]])
        return reset+fp*(T-tau)
    tau=1+.2*par-x0[0]
    rx=np.array([[1,.3],[0,-1],[.4,0.]])
    rt=np.array([par,0,0]);rp=np.array([[tau],[.1],[0.]])
    ev=event_sensitivity(f_before=fm,f_after=fp,reset_x=rx,reset_t=rt,
        reset_parameter=rp,guard_x=np.array([1.,0.]),guard_t=0.,
        guard_parameter=np.array([-.2]),transversality_floor=1e-12)
    dx=np.array([.04,-.03]);dp=.02
    ejump=ev['state']@dx+ev['parameter'][:,0]*dp
    er=[]
    for h in (.02,.01,.005):
        fd=(trajectory(x0+h*dx,par+h*dp)-trajectory(x0-h*dx,par-h*dp))/(2*h)
        er.append({'step':h,'max_absolute':norm(fd-ejump)})
    assert er[-1]['max_absolute']<1e-12
    naive=rx@dx+rp[:,0]*dp
    assert norm(naive-ejump)>1e-3
    checks['event_time_contact']={'passed':True,'independent_event_solve':er,
        'fixed_event_time_error':norm(naive-ejump),
        'scope':'conditional transverse reset test; no BHSM event guard or reset chosen'}

    # Arbitrary positive analyzer affects visibility and phase, not the frequency,
    # under explicitly stationary spin evolution and scalar loss.
    D=I+.1*x+.2*y+.3*z;P=np.array([.6,-.2,.1]);rho=(I+np.einsum('a,aij->ij',P,PAULI))/2
    times=np.linspace(0,13,43);om=.8;rate=.12
    direct=[]
    for t in times:
        u=expm(-.5j*om*t*z)
        direct.append((np.trace(D@(u@rho@u.conj().T))*np.exp(-rate*t)).real)
    derived=stationary_analyzer_signal(D,P,omega=om,decay_rate=rate,times=times)
    assert norm(derived-direct)<1e-14
    unpol=stationary_analyzer_signal(D,np.zeros(3),omega=om,decay_rate=rate,times=times)
    assert norm(unpol-np.exp(-rate*times)*np.trace(D).real/2)<1e-14
    checks['analyzer_not_magnetic_generator']={'passed':True,
        'explicit_density_evolution_comparison':norm(derived-direct),
        'unpolarized_no_spin_modulation':norm(unpol-np.exp(-rate*times)*np.trace(D).real/2),
        'scope':'stationary scalar loss only; no BHSM polarization or omega selected'}

    return {'scope':'CONDITIONAL_MATHEMATICAL_REDUCTION_AND_CONSTRUCTED_CONTROLS',
        'repository_anchor':'70e82fd4dbe5f53ff27ae17f6aaac7a4727c1fde',
        'checks':checks,'all_checks_pass':True,
        'physical_cascade_application':False,'physical_outgoing_derivative_admitted':False,
        'physical_pole_or_magnetic_matrix_evaluated':False,'coupled_corrections':0,
        'physical_a_mu':None,'physical_g_mu':None,'total_uncertainty':None,
        'empirical_muon_anomaly_used':False,'GitHub_write':False}


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args()
    if a.output.exists():raise FileExistsError('preserve existing evidence')
    result=test_all()
    a.output.parent.mkdir(parents=True,exist_ok=True)
    a.output.write_text(json.dumps(result,sort_keys=True,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print(json.dumps({'all_checks_pass':True,'groups':len(result['checks']),'output':str(a.output)}))
