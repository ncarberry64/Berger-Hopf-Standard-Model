"""Exact Haar integral of the source-owned odd magnetic insertion.

This evaluates a specified Maxwell cubic coefficient, not an interacting
background or a quantum pole. One constant (even) gauge test, one normalized
n=1 test, and the actual local-magnetic wavefunction extension are used.
"""
import sympy as s


def evaluate():
    x=s.Matrix(s.symbols('x0:4',real=True));p,u,v=s.symbols('p u v',real=True)
    m=[s.Matrix([[0,-1,0,0],[1,0,0,0],[0,0,0,-1],[0,0,1,0]]),
       s.Matrix([[0,0,-1,0],[0,0,0,1],[1,0,0,0],[0,-1,0,0]]),
       s.Matrix([[0,0,0,-1],[0,0,-1,0],[0,1,0,0],[1,0,0,0]])]
    L=[-m[2],-m[1],-m[0]]
    E=lambda j,f:sum(s.diff(f,x[k])*(L[j]*x)[k] for k in range(4))
    q=s.Matrix([-x[3],-x[2],-x[1]])
    Q=s.Matrix([0,0,s.sqrt(2),s.sqrt(s.Rational(10,3))])
    def cross(a,b):return s.Matrix([*list(s.Matrix(a[:3]).cross(s.Matrix(b[:3]))/s.sqrt(2)),0])
    # Source-owned A_B=(B cross q)/2 in unit-right-frame components, e R4^2 factored.
    photon=[-q[1]*Q/2,q[0]*Q/2,s.zeros(4,1)]
    def case(f):
        A=[p*photon[i] for i in range(3)]
        A[0]+=u*s.Matrix([1,0,0,0]);A[1]+=v*f*s.Matrix([0,1,0,0])
        B=[]
        for i,j,k in ((0,1,2),(1,2,0),(2,0,1)):
            B.append(2*A[i]+A[k].applyfunc(lambda z:E(j,z))-A[j].applyfunc(lambda z:E(k,z))+cross(A[j],A[k]))
        S=-sum(b.dot(b) for b in B)/2
        coeff=s.expand(s.diff(S,p,u,v).subs({p:0,u:0,v:0}))
        poly=s.Poly(coeff,*x);haar=s.Integer(0)
        for powers,c in poly.terms():
            deg=sum(powers)
            if any(k%2 for k in powers):continue
            # This coefficient is degree at most two.
            if deg==0:haar+=c
            elif deg==2:haar+=c/4
            else:raise AssertionError('unsupported Haar moment degree')
        return s.factor(coeff),s.simplify(haar)
    oddpoly,odd=case(2*x[0]);evenpoly,even=case(s.Integer(1))
    assert odd == -s.Rational(3,4)
    assert even == 0
    return {'even_odd_integrand':str(oddpoly),'normalized_even_odd_integral':str(odd),
            'even_even_integrand':str(evenpoly),'even_even_integral':str(even),
            'normalization':'unit Haar, e R4^2 times angular-density prefactor external',
            'physical_field_or_mode_selected':False,
            'scope':'one exact source-defined local Maxwell angular coefficient at homogeneous zero connection; not a moving/collider domain'}

if __name__=='__main__':print(evaluate())
