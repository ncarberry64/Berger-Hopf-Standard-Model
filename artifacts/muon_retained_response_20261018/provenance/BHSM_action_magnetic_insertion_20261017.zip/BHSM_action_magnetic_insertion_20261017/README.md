# Original-action magnetic Hessian insertion

This is a local mathematical continuation for Norman Carberry's BHSM muon work,
not a physical magnetic-moment result or a Git update. Read DERIVATION.md first.

Run with Python, NumPy and SymPy:

```sh
python check_action_insertion.py new_replay_A
python check_action_insertion.py new_replay_B
```

Outputs refuse to overwrite an existing directory. Source-dependent normalization
factors remain symbolic; normalized contact entries and Haar coefficients are
not dimensionless a_mu values. The included `anchor_magnetic_contact3x24x24.npy`
contains only the direct gauge-curvature term in a declared aligned internal
frame. It is not a complete 24-leg propagator or a physical covariance.

This package contains a source-derived implementation, not byte-for-byte imports
of a locally checked-out repository. Compare live source conventions, action
normalization, row permutations and source/domain jets before integration.
No old frozen coefficients or controls are superseded by these files.
