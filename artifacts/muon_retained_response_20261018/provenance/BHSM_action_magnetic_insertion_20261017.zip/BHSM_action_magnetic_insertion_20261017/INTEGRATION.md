# Narrow integration target (no autonomous Git writes performed)

1. Preserve latest local work and the published 70e82fd4 source ancestry. Compare
   source-defined formulas against the live original Maxwell/Higgs evaluators.
2. Reuse the existing local-magnetic source. Do not choose a new field profile,
   plasma reconnection rate, surface tension or particle pole.
3. Supply original-action magnetic Hessian applications with complete value/time/
   radial/angular field jets. Keep all three curvature placements and moving
   density, measure and test terms. Do not replace these by frequency derivatives.
4. Keep magnetic odd/even angular blocks. The exact even/odd coefficient -3/4 is
   a regression on the stated homogeneous coefficient comparison, not a physical
   source/current or evidence of an existing production-code mistake.
5. Carry the actual source/domain/trace motion through quotient_trace_return_first
   and the full daughter tensor derivative. Do not identify that field Green
   with the multiparticle quantum daughter propagator.
6. Do not add a fixed-Q Higgs fluctuation term into a comoving-Q_H(H) chart without
   its field-map contacts. Preserve the published zero direct aligned-Higgs-force
   result. Do not hide required metric or native response in a fitted coefficient.
7. Before physical promotion, the actual external modes, inherited reference,
   quantum operator/domain, retarded source/current projection and complete E/B
   derivatives must exist on a common solution. No physical 2e-10, Maxwell/226,
   pole/residue, Pauli, a_mu, g_mu or total uncertainty is supplied by this package.

Next meaningful deliverable: an evaluated original-action magnetic insertion
consumed on an actual physical mode/history/domain, not more small-step precision
on the unchanged static field-frequency derivative or further generic controls.
