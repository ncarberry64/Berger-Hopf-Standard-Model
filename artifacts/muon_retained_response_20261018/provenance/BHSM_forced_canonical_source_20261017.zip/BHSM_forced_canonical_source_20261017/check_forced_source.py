"""Independent symbolic and finite-DAE controls; NOT a physical muon run."""
from __future__ import annotations
from pathlib import Path
import argparse,json,hashlib,sys
import numpy as np
import sympy as sp
from scipy.linalg import solve
from scipy.integrate import solve_ivp
from forced_canonical_source import Form,forced_gauss_schur,moving_lift_pullback,canonical_rhs,canonical_tangent


def raw_form(t,s):
    """Declared constructed time-varying scalar action with nonzero Gauss source."""
    dtype=np.result_type(t,s,float)
    A=np.array([[2+.1*t+.05*s,.13],[.13,1.7+.04*t*t]],dtype=dtype)
    C=np.array([[.2,-.12,.08,.11],[-.04,.13,.09,-.07]],dtype=dtype)*(1+.1*s)
    D=np.array([[.14,.02,-.06,.03],[-.03,.12,.01,-.04]],dtype=dtype)*(1+.08*t)
    M=np.diag(np.array([1.6,1.5,1.8,1.4],dtype=dtype)*(1+.04*t))
    M[0,3]=M[3,0]=.07*(1+.2*s)
    B=np.array([[.03,.02,0,.04],[-.01,.01,.015,0],[0,-.02,.04,.015],[.01,0,-.01,.02]],dtype=dtype)*(1+.1*t+.1*s)
    K=-np.diag(np.array([.5,.6,.4,.7],dtype=dtype)*(1+.03*t))
    K[0,2]=K[2,0]=.04*(1+.2*s)
    jy=np.array([.3*(1+.2*s)*np.cos(.8*t),-.18*(1+t/3)+.04*s],dtype=dtype)
    jz=np.array([.03*np.sin(t),-.02*(1+s)*np.cos(t),.01*t*t,.025],dtype=dtype)
    h=np.array([.04*t,-.03*np.cos(t),.02*(1+s),.01*np.sin(t)],dtype=dtype)
    Af=np.zeros((6,6),dtype=dtype);Af[2:,2:]=M
    Bf=np.zeros_like(Af);Bf[:2,2:]=D;Bf[2:,2:]=B
    Kf=np.block([[A,C],[C.T,K]])
    return Form(Af,Bf,Kf,np.r_[jy,jz],np.r_[np.zeros(2),h],.01*t*(1+s))


def boundary(t,s):
    v=t**3*(1-t)**3
    vd=3*t*t*(1-t)**3-3*t**3*(1-t)**2
    return (1+.2*s)*v,(1+.2*s)*vd


def chart(t,s,which=1):
    """Two computational lift choices with the SAME boundary trace."""
    a=(.2+.03*s)*t;b=(.13-.02*s)*t
    c,ss=np.cos(a),np.sin(a);ad=.2+.03*s
    rot=np.array([[c,-ss,0],[ss,c,0],[0,0,1]],dtype=np.result_type(t,s,float))
    rotd=ad*np.array([[-ss,-c,0],[c,-ss,0],[0,0,0]],dtype=rot.dtype)
    tri=np.array([[np.exp(.06*t),b,0],[0,1,0],[0,0,np.exp(-.04*t)]],dtype=rot.dtype)
    trid=np.array([[.06*np.exp(.06*t),.13-.02*s,0],[0,0,0],[0,0,-.04*np.exp(-.04*t)]],dtype=rot.dtype)
    E=np.vstack((rot@tri,np.zeros((1,3))))
    Ed=np.vstack((rotd@tri+rot@trid,np.zeros((1,3))))
    beta,bd=boundary(t,s);v=np.array([.2,-.15,.05,1.])
    w=v*beta;wd=v*bd
    if which==2:
        shift=(1+.1*s)*np.array([.09*np.cos(t),.04*np.sin(2*t),-.06*(1+t)],dtype=rot.dtype)
        shiftd=(1+.1*s)*np.array([-.09*np.sin(t),.08*np.cos(2*t),-.06],dtype=rot.dtype)
        w=w+E@shift;wd=wd+Ed@shift+E@shiftd
    return E,Ed,w,wd


def pulled(t,s,which=1):
    a=forced_gauss_schur(raw_form(t,s),2)
    E,Ed,w,wd=chart(t,s,which)
    return moving_lift_pullback(a['form'],E=E,E_dot=Ed,w=w,w_dot=wd)


def initial_physical(s):
    b,_=boundary(0.,s)
    return np.array([.04,-.03,.02,b]),np.array([.02,.01,-.01])


def initial_chart(s,which):
    z,p=initial_physical(s);E,Ed,w,wd=chart(0.,s,which)
    return np.r_[solve(E[:3],z[:3]-w[:3]),E[:3].T@p]


def independent_fields(t,state,s):
    """Literal original Gauss+momentum border; no Schur or moving-lift routine."""
    full=raw_form(t,s);A=full.K[:2,:2];C=full.K[:2,2:];D=full.B[:2,2:]
    M=full.M[2:,2:];B=full.B[2:,2:];K=full.K[2:,2:]
    beta,bd=boundary(t,s);z=np.r_[state[:3],beta];pI=state[3:]
    # Unknowns are zdot_internal and temporal field y.
    border=np.block([[M[:3,:3],D[:,:3].T],[D[:,:3],A]])
    rhs=np.r_[pI-B[:,:3].T@z-M[:3,3]*bd-full.h[2:5],
              -C@z-D[:,3]*bd-full.f[:2]]
    ans=solve(border,rhs,assume_a='gen');zd=np.r_[ans[:3],bd];y=ans[3:]
    p=M@zd+B.T@z+D.T@y+full.h[2:]
    pd=B@zd+K@z+C.T@y+full.f[2:]
    return dict(z=z,zd=zd,y=y,p=p,pd=pd,gauss=A@y+C@z+D@zd+full.f[:2],
        rhs=np.r_[zd[:3],pd[:3]])


def reconstruct(t,state,s,which):
    E,Ed,w,wd=chart(t,s,which);form=pulled(t,s,which)
    x,px=np.split(state,2);xd=canonical_rhs(form,state)[:3]
    z=E@x+w;zd=E@xd+Ed@x+wd
    e=forced_gauss_schur(raw_form(t,s),2)
    y=e['At_value_map']@z+e['At_velocity_map']@zd+e['At_source_value']
    f=raw_form(t,s);fullq=np.r_[y,z];fullqd=np.r_[np.zeros(2),zd]
    p=f.momentum(fullq,fullqd)[2:]
    pd=f.position_gradient(fullq,fullqd)[2:]
    return dict(z=z,zd=zd,y=y,p=p,pd=pd,px=px,
        momentum_pullback_defect=np.max(abs(px-E.T@p)),
        action_pullback_defect=abs(f.action(fullq,fullqd)-form.action(x,xd)),
        gauss=e['Gauss_matrix']@y+e['Gauss_value_row']@z+e['Gauss_velocity_row']@zd+e['Gauss_source'])


def boundary_reaction(t,state,s):
    """Independent original action trace force, including d_t of boundary momentum."""
    c=independent_fields(t,state,s);h=1e-25
    p4dot=np.imag(independent_fields(t+1j*h,state+1j*h*c['rhs'],s)['p'][3])/h
    return c['pd'][3]-p4dot


def form_first(t,s,which=1):
    h=1e-25;a=pulled(t,s+1j*h,which)
    return Form(*(np.imag(getattr(a,k))/h for k in ('M','B','K','f','h')),np.imag(a.c)/h)


def sympy_checks():
    # One algebraic coordinate, two unrestricted dynamic coordinates.
    A,c1,c2,d1,d2,j=sp.symbols('A c1 c2 d1 d2 j',nonzero=True,real=True)
    z1,z2,v1,v2=sp.symbols('z1 z2 v1 v2',real=True)
    z=sp.Matrix([z1,z2]);v=sp.Matrix([v1,v2]);C=sp.Matrix([[c1,c2]]);D=sp.Matrix([[d1,d2]])
    M=sp.Matrix([[3,sp.Rational(1,5)],[sp.Rational(1,5),2]])
    B=sp.Matrix([[sp.Rational(1,3),sp.Rational(1,7)],[sp.Rational(-1,4),sp.Rational(2,5)]])
    K=sp.Matrix([[-2,sp.Rational(1,6)],[sp.Rational(1,6),-3]])
    f=sp.Matrix(sp.symbols('f1 f2',real=True));h=sp.Matrix(sp.symbols('h1 h2',real=True))
    y=-((C*z)[0]+(D*v)[0]+j)/A
    scalar=(v.T*M*v)[0]/2+(z.T*B*v)[0]+(z.T*K*z)[0]/2+(f.T*z)[0]+(h.T*v)[0]+y*((C*z)[0]+(D*v)[0]+j)+A*y*y/2
    mr=M-D.T*D/A;br=B-C.T*D/A;kr=K-C.T*C/A;fr=f-C.T*j/A;hr=h-D.T*j/A
    reduced=(v.T*mr*v)[0]/2+(z.T*br*v)[0]+(z.T*kr*z)[0]/2+(fr.T*z)[0]+(hr.T*v)[0]-j*j/(2*A)
    assert sp.expand(scalar-reduced)==0
    e=sp.Matrix(sp.symbols('e1 e2',real=True));ed=sp.Matrix(sp.symbols('ed1 ed2',real=True));w=sp.Matrix(sp.symbols('w1 w2',real=True));wd=sp.Matrix(sp.symbols('wd1 wd2',real=True))
    x,xd=sp.symbols('x xd',real=True)
    old=(v.T*M*v)[0]/2+(z.T*B*v)[0]+(z.T*K*z)[0]/2+(f.T*z)[0]+(h.T*v)[0]
    subs=dict(zip((z1,z2,v1,v2),[*list(e*x+w),*list(e*xd+ed*x+wd)]))
    mx=(e.T*M*e)[0];bx=(ed.T*M*e+e.T*B*e)[0];kx=(ed.T*M*ed+e.T*B*ed+ed.T*B.T*e+e.T*K*e)[0]
    pw=M*wd+B.T*w+h;hx=(e.T*pw)[0];fx=(e.T*(K*w+B*wd+f)+ed.T*pw)[0]
    cx=(wd.T*M*wd)[0]/2+(w.T*B*wd)[0]+(w.T*K*w)[0]/2+(f.T*w)[0]+(h.T*wd)[0]
    assert sp.expand(old.subs(subs,simultaneous=True)-(mx*xd*xd/2+bx*x*xd+kx*x*x/2+fx*x+hx*xd+cx))==0
    return {'forced_gauss_action':'exact zero symbolic difference','moving_lift_action':'exact zero symbolic difference'}


def execute(out):
    out=Path(out)
    if out.exists():raise FileExistsError('preserve previous executions')
    out.mkdir(parents=True);groups={'symbolic_action_identities':sympy_checks()};s=.17
    times=np.linspace(0.,1.,81);opts=dict(method='DOP853',rtol=3e-13,atol=3e-15,max_step=.025,dense_output=True)
    z,p=initial_physical(s);orig=solve_ivp(lambda t,y:independent_fields(t,y,s)['rhs'],(0,1),np.r_[z[:3],p],**opts)
    assert orig.success
    originals=[independent_fields(t,y,s) for t,y in zip(times,orig.sol(times).T)]
    oi={key:np.array([d[key] for d in originals])for key in ('z','zd','y','p','pd','gauss')}
    curves=[];rec=[]
    for which in (1,2):
        sol=solve_ivp(lambda t,y:canonical_rhs(pulled(t,s,which),y),(0,1),initial_chart(s,which),**opts)
        assert sol.success
        data=[reconstruct(t,y,s,which)for t,y in zip(times,sol.sol(times).T)]
        a={key:np.array([d[key]for d in data])for key in ('z','zd','y','p','pd')}
        errors={key:float(np.max(abs(a[key]-oi[key])))for key in a}
        err=max(errors.values());assert err<2e-10
        control={**errors,'momentum_pullback':float(max(d['momentum_pullback_defect']for d in data)),
                 'scalar_action_pullback':float(max(d['action_pullback_defect']for d in data)),
                 'Gauss_original':float(max(np.max(abs(d['gauss']))for d in data))}
        rec.append(control);curves.append(a)
        for key,val in a.items():np.save(out/f'lift{which}_{key}.npy',val,allow_pickle=False)
    groups['literal_original_DAE_vs_reduced_lifts']={'runs':rec,'scope':'constructed finite time-dependent action only'}
    lift_delta=max(float(np.max(abs(curves[0][k]-curves[1][k]))) for k in curves[0]);assert lift_delta<2e-10
    reactions=[]
    for curve in curves:
        reactions.append(np.array([boundary_reaction(t,np.r_[z[:3],p[:3]],s)for t,z,p in zip(times,curve['z'],curve['p'])]))
    reactdiff=float(np.max(abs(reactions[0]-reactions[1])));assert reactdiff<2e-10
    groups['lift_independence']={'full_solution_max_difference':lift_delta,'boundary_action_reaction_max_difference':reactdiff,
        'two_different_internal_lifts':True,'same_boundary_and_physical_initial_data':True}
    # Independent scalar equality at a nontrivial off-shell test point.
    t=.37;e=forced_gauss_schur(raw_form(t,s),2);r=e['form'];x=np.array([.07,-.02,.04,.01]);xd=np.array([.12,-.03,.05,-.01]);yy=e['At_value_map']@x+e['At_velocity_map']@xd+e['At_source_value']
    f=raw_form(t,s);err=abs(f.action(np.r_[yy,x],np.r_[np.zeros(2),xd])-r.action(x,xd));assert err<1e-13
    omitted_gauss_source=float(np.linalg.norm(e['Gauss_source']))
    omitted_momentum=float(np.linalg.norm(r.h-f.h[2:]));assert omitted_momentum>1e-3
    omitted_force=float(np.linalg.norm(r.f-f.f[2:]));assert omitted_force>1e-3
    E,Ed,w,wd=chart(t,s,1);correct=moving_lift_pullback(r,E=E,E_dot=Ed,w=w,w_dot=wd)
    frozen=moving_lift_pullback(r,E=E,E_dot=0*Ed,w=w,w_dot=wd)
    missing_frame=float(np.max(abs(correct.K-frozen.K)));assert missing_frame>1e-3
    groups['omission_detection']={'Gauss_load_norm_if_discarded':omitted_gauss_source,
        'canonical_source_shift_norm_if_discarded':omitted_momentum,'force_shift_norm_if_discarded':omitted_force,
        'moving_inclusion_stiffness_contact_max':missing_frame,'scalar_action_exact_reconstruction_error':float(err)}
    # Initial variations include both changed lift and moving momentum chart.
    h=1e-25;init=initial_chart(s,1);inits=np.imag(initial_chart(s+1j*h,1))/h
    def aug(t,z):
        state,st=np.split(z,2);f=pulled(t,s,1);fd=form_first(t,s,1)
        return np.r_[canonical_rhs(f,state),canonical_tangent(f,fd,state,st)]
    sol=solve_ivp(aug,(0,1),np.r_[init,inits],**opts);assert sol.success
    y,ys=np.split(sol.y[:,-1],2)
    # Reconstruct source derivative by analytic continuation of the entire map.
    recs=reconstruct(1.,y+1j*h*ys,s+1j*h,1)
    analytic=np.r_[np.imag(recs['z'])/h,np.imag(recs['p'])/h,np.imag(recs['y'])/h]
    sweep=[]
    for step in (.02,.01,.005):
        ends=[]
        for mult in (2,1,-1,-2):
            sj=s+mult*step;zz,pp=initial_physical(sj)
            ss=solve_ivp(lambda t,y:independent_fields(t,y,sj)['rhs'],(0,1),np.r_[zz[:3],pp],**opts);assert ss.success
            o=independent_fields(1.,ss.y[:,-1],sj);ends.append(np.r_[o['z'],o['p'],o['y']])
        fd=(-ends[0]+8*ends[1]-8*ends[2]+ends[3])/(12*step)
        sweep.append({'step':step,'max_absolute':float(np.max(abs(fd-analytic)))})
    assert sweep[-1]['max_absolute']<2e-10
    groups['total_parameter_derivative']={'independent_original_DAE_sweep':sweep,
        'changes':'raw M/B/K, additive Gauss source, force, momentum source, boundary, moving frame and initial chart',
        'scope':'finite constructed action sensitivity, not physical outgoing derivative'}
    # Negative test: singular unresolved algebraic block is not pseudoinverted.
    ff=raw_form(.2,s);kk=ff.K.copy();kk[:2,:2]=0
    try:forced_gauss_schur(Form(ff.M,ff.B,kk,ff.f,ff.h,ff.c),2)
    except np.linalg.LinAlgError:groups['singular_block_guard']={'passed':True}
    else:raise AssertionError('singular Gauss block silently admitted')
    np.save(out/'times.npy',times,allow_pickle=False)
    np.save(out/'total_parameter_derivative.npy',analytic,allow_pickle=False)
    for i,r in enumerate(reactions,1):np.save(out/f'lift{i}_boundary_action_reaction.npy',r,allow_pickle=False)
    result={'classification':'EXACT_FORCED_FORM_CONSTRUCTION_WITH_INDEPENDENT_FINITE_DAE_CONTROLS',
        'groups':groups,'group_count':len(groups),'all_scoped_checks_pass':True,
        'physical_retarded_solve_executed':False,'physical_Maxwell_226_after_state':None,
        'physical_outgoing_derivative_admitted':False,'coupled_corrections':0,'a_mu':None,'g_mu':None,'total_uncertainty':None,
        'historical_coefficients_refined':False,'actual_BHSM_history_arrays_used_as_numerical_ODE_inputs':False}
    (out/'result.json').write_text(json.dumps(result,indent=2,sort_keys=True,allow_nan=False)+'\n')
    print(json.dumps(result,indent=2,sort_keys=True))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args();execute(a.output)
