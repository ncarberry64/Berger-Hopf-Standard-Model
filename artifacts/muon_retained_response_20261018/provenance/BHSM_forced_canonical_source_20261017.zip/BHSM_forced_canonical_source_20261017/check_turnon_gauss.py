"""Actual retained-wall coefficient of a magnetic turn-on rate in Gauss rows.

An angular coefficient of the original bulk density, not radially or temporally
integrated forcing. Reuses the actual raw268 inputs and geometric source map.
"""
from pathlib import Path
import sys,json,argparse,hashlib
import numpy as np
import sympy as sp
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'dependencies'))
from retained_magnetic_application import wall_data,fields,rule8,rule24,FRAME
from action_magnetic_kernel import bracket,FieldJet,zero_field,local_hessian
from forced_canonical_source import Form,forced_gauss_schur_first,forced_gauss_schur
from check_forced_source import raw_form


def apply(raw,rule):
    q,w=rule();d,base,probes,_,_,_=fields(raw,q)
    e=d['dang']*d['R4']**2/d['ambient_lapse']**2
    Y=2*q;EY=2*np.einsum('aij,pj->pai',FRAME,q)
    n=len(q);I=np.eye(4)
    # Temporal one-form test has value Y_h e_c and angular derivative E_iY_h e_c.
    t=np.zeros((n,16,5,4),complex);ta=np.zeros((n,16,3,5,4),complex)
    t[:,:,0,:]=np.einsum('ph,cb->phcb',Y,I).reshape(n,16,4)
    ta[:,:,:,0,:]=np.einsum('pih,cb->phcib',EY,I).reshape(n,16,3,4)
    test=FieldJet(t[:,None],np.zeros_like(t[:,None]),np.zeros_like(t[:,None]),ta[:,None])
    den=np.array([e,0,0,0,0],complex)
    values=[];literal=[];momentum=[]
    for probe in probes:
        # Coefficient of g_dot at fixed g: delta A=0, delta A_dot=b_spatial.
        p=FieldJet(np.zeros_like(probe.value),probe.value,np.zeros_like(probe.value),np.zeros_like(probe.angular))
        val=np.einsum('p,pij->ij',w,local_hessian(base,p,test,den)).ravel()
        b=probe.value[:,0,0,2:]
        Di=ta[:,:, :,0,:]+bracket(d['connection'][None,None,2:,:],t[:,:,0,None,:])
        lit=-e*np.einsum('p,pic,ptic->t',w,b,Di)
        values.append(val);literal.append(lit)
        momentum.append(e*np.einsum('p,ph,pic->ich',w,Y,b))
    return np.array(values),np.array(literal),np.array(momentum),e,d


def run(out):
    out=Path(out)
    if out.exists():raise FileExistsError('preserve previous outputs')
    out.mkdir(parents=True);records=[]
    for side in ('incoming','outgoing'):
        path=ROOT/'inputs'/f'{side}_raw_fields.npy';raw=np.load(path,allow_pickle=False)
        a,l,p,e,d=apply(raw,rule8);b,lb,pb,_,_=apply(raw,rule24)
        err=float(np.max(abs(a-l)));ref=float(np.max(abs(a-b)))
        assert err<2e-10 and ref<2e-10 and np.max(abs(a))>1e-5
        U=np.load(ROOT/'inputs/odd_isometry400x80.npy',allow_pickle=False)
        assert U.shape==(400,80) and np.array_equal(U.T@U,np.eye(80))
        cov=np.zeros((3,4,5,4),complex);cov[:,:,0,:]=a.reshape(3,4,4)
        mom=np.zeros_like(cov);mom[:,:,2:,:]=p.transpose(0,3,1,2)
        old=cov.reshape(3,80)@U.T;oldp=mom.reshape(3,80)@U.T
        assert np.array_equal(old@U,cov.reshape(3,80))
        assert np.array_equal(oldp@U,mom.reshape(3,80))
        for key,v in [('Gauss_gdot3x16',a),('spatial_momentum_gdot3x3x4x4',p),
                      ('Gauss_gdot_old_full400',old),('momentum_gdot_old_full400',oldp)]:
            np.save(out/(side+'_'+key+'.npy'),v,allow_pickle=False)
        records.append({'side':side,'raw_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
            'electric_density':float(e.real),'Gauss_gdot_max_per_e':float(np.max(abs(a))),
            'Gauss_gdot_max_divided_by_electric_R4_squared':float(np.max(abs(a))/(e*d['R4']**2).real),
            'direct_covariant_divergence_identity_max':err,'independent_angular_rule_max':ref,
            'central_hypercharge_gdot_max':float(np.max(abs(a.reshape(3,4,4)[:,:,3]))),
            'scope':'coefficient of probe rate at retained material wall; NOT a surface delta source or integrated retarded forcing'})
    # Exact matrix-solve derivative uses original finite control data, not the above densities as a physical solve.
    h=1e-25;t=.37;s=.17;f=raw_form(t,s);f0=raw_form(t,s+1j*h)
    df=Form(*(np.imag(getattr(f0,k))/h for k in ('M','B','K','f','h')),np.imag(f0.c)/h)
    an=forced_gauss_schur_first(f,df,2);ref=forced_gauss_schur(f0,2)['form']
    errors={k:float(np.max(abs(getattr(an['first'],k)-np.imag(getattr(ref,k))/h)))for k in ('M','B','K','f','h','c')}
    assert max(errors.values())<2e-12
    # Exact central-Y coefficient from the owned right frame and Haar second moments.
    xx=sp.Matrix(sp.symbols('x0:4',real=True));sy=sp.sqrt(sp.Rational(10,3))
    qp=-sp.Matrix([xx[3],xx[2],xx[1]])
    from action_magnetic_kernel import epsilon
    ep=epsilon();central_exact=[]
    for axis in range(3):
        bvec=sp.Matrix([-sp.Rational(1,2)*sy*sum(int(ep[i,j,axis])*qp[j] for j in range(3)) for i in range(3)])
        div=sum((sp.Matrix(FRAME[i].astype(int))*xx).dot(sp.Matrix([sp.diff(bvec[i],z)for z in xx]))for i in range(3))
        assert sp.expand(div-sy*qp[axis])==0
        # Haar <(2x_h)x_j> = delta_hj/2.
        central_exact.append([str(sp.simplify(sp.diff(div,z)/2))for z in xx])
    result={'classification' :'RETAINED_WALL_TURNON_GAUSS_COEFFICIENT_AND_EXACT_FORCED_SCHUR_FIRST',
        'records':records,'analytic_forced_schur_first_errors':errors,
        'central_Gauss_rate_matrix_divided_by_electric_R4_squared':central_exact,
        'central_exact_divergence':'div(b_Y)/(e_can R4^2)=sqrt(10/3)*q_axis',
        'physical_probe_rate_or_protocol_chosen':False,'integrated_physical_Gauss_source':None,
        'retarded_collider_solve_executed':False}
    (out/'result.json').write_text(json.dumps(result,indent=2,sort_keys=True,allow_nan=False)+'\n')
    print(json.dumps(result,indent=2,sort_keys=True))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args();run(a.output)
