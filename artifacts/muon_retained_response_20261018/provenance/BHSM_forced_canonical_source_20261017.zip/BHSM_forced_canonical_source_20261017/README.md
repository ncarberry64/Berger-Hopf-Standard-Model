# BHSM forced canonical source continuation

Two distinct applications:

1. `check_turnon_gauss.py`: source-defined magnetic turn-on Gauss coefficient on
   the actual retained wall arrays, plus an exact central-U1 symbolic check.
2. `check_forced_source.py`: symbolic forced-action construction and independent
   finite DAE/lift/derivative controls; NOT physical muon histories.

Run with Python, NumPy, SciPy and SymPy in an existing suitable environment:

```text
python check_turnon_gauss.py --output new_retained_run
python check_forced_source.py --output new_response_control_run
```

Existing output directories are rejected. The original proof scope is preserved.
The `forced_canonical_source.py` functions consume actual explicit form/source and
lift arrays. They do not choose physical Cauchy data, constraints or a quantum
reference. No final magnetic moment or physical derivative admission is included.
See DERIVATION.md for equations and exact missing physical applications.
