# Targeted integration

Keep all source packages and newer repository work. Reuse original angular/source,
radial and geometric implementations. Do not stage untracked archives wholesale.

The forced `constrained_gauss_schur` extension has the SAME quadratic sign convention
as the existing scalar action. Reconcile the actual linear action coefficients
first. Do not silently regard them as negative residuals. A nonzero algebraic
source modifies reduced force, velocity-source momentum, the action constant,
and the actual temporal conormal. Retain the original border if its algebraic
block is not admitted; no positive-geometry pseudoinverse is introduced.

For the actual retarded problem, bind the frozen radial/source frame, all actual
stage fields/lifts and explicit inherited clock terms before integration. Different
computational interior lifts of the same prescribed trace are equivalent only if
the original equations, response space and physical initial data agree.

Do not set the source-generated Gauss component to zero because the saved purely
spatial magnetic insertion had no central-Y rows. The evaluated time-derivative
term is different and nonzero. It is a bulk density at the wall, not a new surface
source. Integrate its actual profile; do not multiply it directly by an unrelated
old wall Green. This term alone is not a static magnetic anomaly.

No physical outgoing derivative, correction, pole or Pauli value is supplied.
No change of benchmark energy/packet/radiation choices is requested.

Do not add the turn-on Gauss coefficient twice: if it arises from Cw+Dwdot
in the prescribed lift, the lifted Schur action already includes it. Keep
independent j_y sources distinct from that representation of the same probe.
