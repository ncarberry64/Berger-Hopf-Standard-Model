"""Evaluate the retained-data direct finite-time lepton response and scoped controls."""
from __future__ import annotations
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import argparse,json,time
from pathlib import Path
import numpy as np
from scipy.integrate import solve_ivp
from scipy.linalg import expm
from scipy.optimize import brentq
import sympy as sp
from finite_time_response import *


def representation_checks(h):
    g,w,x=haar_rule(8);phi=scalar_values(g,2);q=-x[:,[3,2,1]]
    literal=np.einsum('p,pi,pa,pj->aij',w,phi.conj(),q,phi)
    Tq=quaternion_multiplication(2)
    E=derivatives(2);eps=np.zeros((3,3,3));eps[0,1,2]=eps[1,2,0]=eps[2,0,1]=1;eps[0,2,1]=eps[2,1,0]=eps[1,0,2]=-1
    labels=scalar_labels(2);Pi=np.diag([(-1)**n for n,m,k in labels]);P=np.kron(Pi,np.eye(6))
    # Literal action on fields at independent Haar points; no assembled H or V used.
    with np.load(ROOT/'inputs'/f"{h['side']}.npz",allow_pickle=False) as a:raw=a['lo_raw_fields']
    d,point,G18,a18=full18_point(raw);idx=h['ops'][0]['family_indices'];G=G18[:,idx][:,:,idx];al=a18[:,idx][:,:,idx]
    rng=np.random.default_rng(71623);coef=rng.normal(size=(len(labels),6))+1j*rng.normal(size=(len(labels),6));coef/=np.linalg.norm(coef)
    ps=phi@coef;epsi=np.einsum('ph,ahk,kj->paj',phi,E,coef)
    Om=np.einsum('fc,cij->fij',d['connection'][[0,2,3,4]],G)
    hr=raw[-8:-4];hh=hr[:2]+1j*hr[2:];mass=np.zeros((6,6),complex);m=YUKAWA[1]*np.kron(hh[:,None],np.eye(2));mass[:4,4:]=m;mass[4:,:4]=m.conj().T
    gamma5=np.diag([-1.]*4+[1.]*2)
    out=-1j*d['lapse']/d['R4']*np.einsum('aij,paj->pi',al,epsi+np.einsum('aij,pj->pai',Om[1:],ps))
    out+=ps@(d['lapse']*(mass+1.5*gamma5/d['R4'])-1j*Om[0]).T
    integrated=np.einsum('p,ph,pi->hi',w,phi.conj(),out).ravel()
    hx=mx(integrated-h['H'][0]@coef.ravel());vcheck=[]
    for k in range(3):
        a=-.5*d['R4']**2*np.einsum('ij,pj,c->pic',eps[:,:,k],q,d['charge'])
        dom=np.einsum('pac,cij->paij',a,G)
        application=-1j*d['lapse']/d['R4']*np.einsum('aij,pajk,pk->pi',al,dom,ps)
        literalV=np.einsum('p,ph,pi->hi',w,phi.conj(),application).ravel()
        vcheck.append(mx(literalV-h['V'][0,k]@coef.ravel()))
    frame=0.
    steps=[1e-4,5e-5]
    # Independent right-frame differentiation of the actual polynomial functions.
    for a in range(3):
        e=steps[-1];xp=x[:12]@expm(e*FRAME[a]).T;xm=x[:12]@expm(-e*FRAME[a]).T
        xpp=x[:12]@expm(2*e*FRAME[a]).T;xmm=x[:12]@expm(-2*e*FRAME[a]).T
        from compatible_source import su2_from_quaternions
        pp=lambda z:scalar_values(su2_from_quaternions(z),2)
        fd=(-pp(xpp)+8*pp(xp)-8*pp(xm)+pp(xmm))/(12*e)
        frame=max(frame,mx(fd-phi[:12]@E[a]))
    return dict(angular_Gram=mx(np.einsum('p,pi,pj->ij',w,phi.conj(),phi)-np.eye(14)),
       exact_CG_vs_Haar=mx(Tq-literal),source_hermiticity=mx(h['V']-dagger(h['V'])),
       hamiltonian_hermiticity=mx(h['H']-dagger(h['H'])),full18_family_invariance=max(o['full18_family_commutator'] for o in h['ops']),
       original_point_H_application=hx,original_point_magnetic_application=max(vcheck),
       parity_H=mx(P@h['H']-h['H']@P),parity_V=mx(P@h['V']+h['V']@P),
       source_H_axis= h['sampled_source_charge_difference'],
       independent_frame_derivative=frame),P


def proper_clock_check(h,U):
    # Explicit polynomial representation of sampled lapse, not a physical clock fit.
    poly=np.polynomial.Polynomial.fit(h['s'],h['N'],5,domain=[0,1]).convert()
    integral=poly.integ();tot=float(integral(1)-integral(0));n=h['H'].shape[-1]
    def t_of(v):
        if v<=0:return 0.
        if v>=1:return 1.
        return brentq(lambda s:(integral(s)-integral(0))/tot-v,0.,1.,xtol=5e-15)
    def rhs(v,y):
        s=t_of(v);N=float(poly(s));H=interpolate(h['s'],h['H'],s)
        return (-1j*h['T']*tot/N*H@y.reshape(n,n)).ravel()
    sol=solve_ivp(rhs,(0,1),np.eye(n,dtype=complex).ravel(),method='DOP853',rtol=2e-12,atol=2e-14,max_step=.125)
    if not sol.success:raise ArithmeticError('proper clock solve')
    err=mx(sol.y[:,-1].reshape(n,n)-U(1.))
    return dict(proper_duration_in_unmatched_action_units=h['T']*tot,independent_proper_time_evolution=err,
                initial_coordinate_source_max=mx(h['V'][0]),initial_proper_source_max=mx(h['V'][0]/h['N'][0]),
                initial_lapse=float(h['N'][0]))


def frame_test(h,U):
    n=h['H'].shape[-1];spin=h['S'][2];diag=spin.diagonal().real;T=h['T']
    def r(s):return np.diag(np.exp(-1j*(.3*s+.2*s*s)*diag))
    def rhs(with_contact):
        def fn(s,y):
            R=r(s);H=T*R@interpolate(h['s'],h['H'],s)@dagger(R)
            if with_contact:H=H+(.3+.4*s)*spin
            return (-1j*H@y.reshape(n,n)).ravel()
        return fn
    uf=[]
    for contact in [True,False]:
        sol=solve_ivp(rhs(contact),(0,1),np.eye(n,dtype=complex).ravel(),method='DOP853',rtol=5e-13,atol=1e-14,max_step=.08,dense_output=True)
        if not sol.success:raise ArithmeticError('frame test')
        uf.append(lambda s,sol=sol:sol.sol(s).reshape(n,n))
    ts=.31;tf=.87;R0=r(ts);Rf=r(tf);V=interpolate(h['s'],h['V'],ts)[0];O=h['S'][1]
    original=impulse_operator(U(tf),U(ts),V,O)
    moved=impulse_operator(uf[0](tf),uf[0](ts),R0@V@dagger(R0),Rf@O@dagger(Rf))
    wrong=impulse_operator(uf[1](tf),uf[1](ts),R0@V@dagger(R0),Rf@O@dagger(Rf))
    return dict(complete_frame_propagator=mx(uf[0](1)-r(1)@U(1)),complete_frame_kernel=mx(original-moved),
                omitted_frame_connection_kernel_difference=mx(original-wrong))


def open_system_controls():
    # No physical coefficients or densities are assigned to BHSM by these controls.
    from scipy.integrate import quad
    om=.7;gamma0=.23;gv=np.array([.04,-.07,.09]);rv=np.array([.2,-.3,.4]);ov=np.array([.5,.1,-.2])
    rho=(np.eye(2)+np.einsum('a,aij->ij',rv,PAULI))/2
    H=np.einsum('a,aij->ij',ov,PAULI)/2;G=gamma0*np.eye(2)+np.einsum('a,aij->ij',gv,PAULI)
    dr=-1j*comm(H,rho)-(G@rho+rho@G)/2;dn=np.trace(dr).real
    rdot=np.einsum('aij,ji->a',PAULI,dr).real-rv*dn
    bloch=mx(rdot-nojump_bloch(rv,ov,gv))
    # Conditional signal: pure scalar loss cancels exactly from normalized response.
    H0=.71*PAULI[2]/2;V=.3*PAULI[2];t=.8;D=np.eye(2)+.4*PAULI[0];rr=(np.eye(2)+.6*PAULI[0])/2
    U=expm(-1j*H0*t);du=-1j*t*V@U
    expected=np.trace(D@(du@rr@dagger(U)+U@rr@dagger(du))).real
    errs=[]
    for g in [0.,.3,1.2]:
        A=np.exp(-g*t/2)*U;da=np.exp(-g*t/2)*du;r=A@rr@dagger(A);rd=da@rr@dagger(A)+A@rr@dagger(da)
        val=conditional_response(np.trace(D@r).real,np.trace(r).real,np.trace(D@rd).real,np.trace(rd).real)
        errs.append(abs(val-expected))
    # Magnetic dependence of survival must not be misread as rotation.
    gp=.13;g=.3;A=np.exp(-g*t/2)*U;da=np.exp(-g*t/2)*(du-.5*gp*t*U)
    state=A@rr@dagger(A);dstate=da@rr@dagger(A)+A@rr@dagger(da)
    p=float(np.trace(state).real);dp=float(np.trace(dstate).real)
    num=float(np.trace(D@state).real);dnum=float(np.trace(D@dstate).real)
    quotient_error=abs(conditional_response(num,p,dnum,dp)-expected)
    omitted_survival=abs(dnum/p-expected)
    # Conditional local generator can be singular even when the state map is smooth.
    bad=False
    try:open_channel_measurement(np.diag([1.,0]),np.eye(2))
    except ValueError:bad=True
    # Explicit identity from Pauli multiplication, independent symbolic arithmetic.
    rx,ry,rz,ox,oy,oz,gx,gy,gz,g0=sp.symbols('rx ry rz ox oy oz gx gy gz g0',real=True)
    P=[sp.Matrix([[0,1],[1,0]]),sp.Matrix([[0,-sp.I],[sp.I,0]]),sp.diag(1,-1)]
    st=sum((r*p for r,p in zip([rx,ry,rz],P)),sp.zeros(2));st=(sp.eye(2)+st)/2
    hh=sum((o*p/2 for o,p in zip([ox,oy,oz],P)),sp.zeros(2));gg=g0*sp.eye(2)+sum((g*p for g,p in zip([gx,gy,gz],P)),sp.zeros(2))
    drs=-sp.I*(hh*st-st*hh)-(gg*st+st*gg)/2;loss=sp.trace(drs)
    result=sp.Matrix([sp.trace(p*drs)-r*loss for p,r in zip(P,[rx,ry,rz])])
    rvec=sp.Matrix([rx,ry,rz]);gvec=sp.Matrix([gx,gy,gz]);ovec=sp.Matrix([ox,oy,oz])
    sym=all(sp.simplify(z)==0 for z in result-(ovec.cross(rvec)-gvec+(gvec.dot(rvec))*rvec))
    assert sym and bad and bloch<1e-14 and max(errs)<1e-14 and quotient_error<1e-14 and omitted_survival>1e-3
    return dict(symbolic_conditional_Bloch_identity=sym,numerical_conditional_Bloch=bloch,
                scalar_loss_cancels_in_normalized_spin_response=max(errs),magnetic_survival_quotient_identity=quotient_error,
                omitted_magnetic_survival_derivative_error=omitted_survival,singular_time_local_generator_rejected=bad,
                scope='CONSTRUCTED_2SPIN_CONTROLS_NOT_BHSM_DECAY_PARAMETERS')


def run(out):
    out=Path(out)
    if out.exists():raise FileExistsError('preserve preceding output')
    out.mkdir(parents=True);records=[]
    osc=open_system_controls()
    for side in ['incoming','outgoing']:
        h=actual_history(side);r,P=representation_checks(h);U=evolve(h);base=response_basis(h,U,12);b24=response_basis(h,U,24)
        n=h['H'].shape[-1];times=h['s'];us=U(times)
        # Entire finite84 kernel plus exact reachable30 input projection are saved.
        kernel=np.zeros((6,6,3,3,n,n),complex)
        for i,ti in enumerate(times):
            for j,sj in enumerate(times):
                if sj>ti:continue
                for a,b in np.ndindex(3,3):kernel[i,j,a,b]=impulse_operator(us[i],us[j],h['V'][j,a],h['S'][b])
        pe=(np.eye(n)+P)/2;po=(np.eye(n)-P)/2
        parity_response=max(mx(pe@k@pe) for k in base['spin_readout_first'].reshape(-1,n,n))
        phaseH=mx(h['H'][-1]-h['H'][0]);phaseV=mx(h['V'][-1]-h['V'][0])
        # Independent perturbed evolution, no response or jet helper in those solves.
        aa=np.array([.7,-.4,.5]);drive=lambda s:1+.3*s
        dU=np.einsum('a,aij->ij',aa,base['propagator_first'][0]+.3*base['propagator_first'][1])
        exactspin=np.einsum('a,abij->bij',aa,base['spin_readout_first'][0]+.3*base['spin_readout_first'][1])
        comparisons=[]
        for step in [1.,.5,.25]:
            plus=evolve(h,strength=step,axis=aa,drive=drive)(1.);minus=evolve(h,strength=-step,axis=aa,drive=drive)(1.)
            fd=(plus-minus)/(2*step)
            ofs=(dagger(plus)@h['S']@plus-dagger(minus)@h['S']@minus)/(2*step)
            comparisons.append(dict(step=step,propagator_first_max=mx(fd-dU),spin_readout_first_max=mx(ofs-exactspin)))
        # No artificial physical coefficient change: compare numerical interpolants only.
        U4=evolve(h,indices=[1,2,3,4]);interp_difference=mx(U4(1)-U(1))
        bclock=proper_clock_check(h,U);frame=frame_test(h,U)
        ms=dict(r);ms.update(unitarity=max(mx(dagger(ui)@ui-np.eye(n)) for ui in us),
             kernel_hermiticity=mx(kernel-dagger(kernel)),
             integrated_insertion_rule12_vs24=mx(base['integrated_insertion']-b24['integrated_insertion']),
             even_input_even_spin_readout=parity_response,
             observable_kernel_max=mx(kernel),integrated_spin_response_max=mx(base['spin_readout_first']),
             direct_propagator_first_max=mx(base['propagator_first']),
             six_sample_H_change=phaseH,six_sample_magnetic_source_change=phaseV,
             distinct_time_H_commutator=mx(comm(h['H'][0],h['H'][-1])),
             four_vs_six_node_interpolant_final_difference=interp_difference,
             **bclock,**frame)
        checks={
          'source_representation':r['original_point_H_application']<1e-11 and r['original_point_magnetic_application']<1e-11 and r['exact_CG_vs_Haar']<1e-12,
          'original_hermiticity_and_family':r['hamiltonian_hermiticity']<1e-12 and r['full18_family_invariance']<1e-12,
          'unitary_finite_evolution':ms['unitarity']<1e-11,
          'retarded_kernel_hermiticity':ms['kernel_hermiticity']<1e-11,
          'independent_field_derivative':max(c['spin_readout_first_max'] for c in comparisons)<2e-10,
          'kernel_integration':ms['integrated_insertion_rule12_vs24']<2e-10,
          'proper_clock_consistency':bclock['independent_proper_time_evolution']<2e-10,
          'moving_spin_frame':frame['complete_frame_kernel']<2e-10 and frame['omitted_frame_connection_kernel_difference']>1e-4,
          'parity_diagnostic':parity_response<1e-12 and mx(kernel)>1e-3,
          'two_spin_conditional_controls':True}
        if not all(checks.values()):raise ArithmeticError(json.dumps({'failed':checks,'measurements':ms}))
        write_npz(out/f'{side}_time_operators.npz',{'sample_time':h['t'],'H_coordinate_time':h['H'],
          'direct_magnetic_insertions_per_e':h['V'],'sample_lapse':h['N'],'spin_generators':h['S'],'sample_U':us,
          'family_yukawa':YUKAWA,'family_indices':h['ops'][0]['family_indices'],'angular_parity':P})
        write_npz(out/f'{side}_causal_kernel.npz',{'times_coordinate':h['t'],'kernel_outputtime_inputtime_probeaxis_spinaxis':kernel,
           'lowest_input30_kernel':kernel[...,:30,:30]})
        write_npz(out/f'{side}_integrated_response.npz',base)
        records.append(dict(side=side,measurements=ms,finite_difference_checks=comparisons,scoped_checks=checks,
            physical_state_selected=False,decay_kernel_evaluated=False))
        (out/'progress.json').write_text(json.dumps(records,indent=2,sort_keys=True,allow_nan=False)+'\n')
        print(side,json.dumps(ms,sort_keys=True),flush=True)
    result=dict(classification='RETAINED_TIME_DEPENDENT_INTRINSIC_LEPTON_DIRECT_MAGNETIC_KERNEL_NOT_PHYSICAL_MUON',
      source_revision='70e82fd4dbe5f53ff27ae17f6aaac7a4727c1fde',records=records,open_system_controls=osc,
      physical_muon_a=None,physical_muon_g=None,physical_decay_or_survival_rate=None,total_uncertainty=None,
      physical_outgoing_derivative_admitted=False,physical_background_corrections=0,quantum_reference_selected=False,
      physical_initial_density_selected=False,arms_joined=False,magnetic_feedback_or_native_completion_evaluated=False,
      full18_middle_family_invariance_used=True,quantum_mode_space='6 middle-family components x 14 scalar harmonics through n2; no pole projection',
      exact_first_order_reach_scope='n<=1 initial coefficients reach n<=2 under one magnetic n1 insertion on homogeneous reference',
      time_representation='explicit degree5 interpolation of six supplied coefficient samples; not an exact full BHSM history',
      time_in_seconds_or_muon_lifetime_matched=False,git_writes=False)
    (out/'result.json').write_text(json.dumps(result,indent=2,sort_keys=True,allow_nan=False)+'\n')
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',required=True,type=Path);a=p.parse_args();run(a.output)
