# Integration target

Preserve the complete prior Maxwell/Higgs/normal-source outputs. The new engine
consumes time-dependent h and V rather than first demanding a stationary pole.
Compare the reconstructed operator/representations with the source-pinned live
functions before production use. The six-component middle-family subspace follows
from exact family invariance of this component, not from physical muon selection.

Immediate next physical application: assemble the same-history TOTAL local
magnetic insertion V_direct + D_Phi h delta_B Phi, with actual physical source,
wall/normal coupling and field normalization. Keep any nonlocal native response
as a two-time operator and differentiate it with all three time arguments as
needed. Use the full correlated preparation and the physical daughter analyzer.

Do not replace the finite histories by a constant background, identify coordinate
clock changes with g drift, or insert an empirical exponential lifetime. Test
conditioned spin, unnormalized daughter counts and muon-sector occupancy separately.
A population can change while its magnetic coupling is constant. Sector occupancy
is not first-decay survival when return flux remains possible.

Only extract a time-local g tensor where the physical two-spin generator and its
charge/mass/clock correspondence exist. Otherwise retain the causal signal kernel.
An observed time-dependent signal alone is not a time-dependent magnetic moment.
No additional measurement parameters, reconnection coefficient or mode fit to the
muon anomaly are authorized by this mathematical application.
