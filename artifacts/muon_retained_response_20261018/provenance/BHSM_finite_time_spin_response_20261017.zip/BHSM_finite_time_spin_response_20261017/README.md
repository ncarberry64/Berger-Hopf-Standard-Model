# BHSM finite-time spin response — 2026-10-17

Run `python run_response.py --output replay_new` in this directory. Requires numpy,
scipy, sympy. The inputs are self-contained. No network, Git write, additional user
export, initial density, lifetime or physical magnetic-field amplitude is required.
Read DERIVATION.md before using the matrices. This is a time-dependent direct
one-particle lepton response on provisional histories, NOT the physical muon
formation/decay or full quantum magnetic moment.

The causal kernel preserves all six middle-family component indices and scalar
harmonics n<=2. Exact first-order angular reach is only claimed for initial n<=1.
The initial 30x30 subblock is saved separately. All source units are per e_can.
The full kernel is computed for the stated finite truncation. No density is selected.

Files:
- finite_time_response.py: original-action construction, evolution and response.
- run_response.py: evaluated applications and independent checks.
- inputs/: exact compact excerpts of the user-exported histories and provenance.
- dependencies/: unchanged prior source-defined harmonic and wall helpers.
- replay_A/, replay_B/: independent executions; eight files per replay.
- VERIFICATION.json and SHA256SUMS.json: execution and integrity record.

Do not reuse the Hermitian conjugate dual of this real-time finite model on a
complex analytic-leaf problem without its actual left evolution. Do not use the
three component-spin generators as if physical muon pole/residue spins had been
selected. Do not interpret a Hamiltonian interpolation, basis truncation, or the
short action-coordinate interval as an admitted collider or measured lifetime.
