# Finite Maxwell initial-value and wall-response continuation

This package **solves** two finite time-dependent Maxwell response systems on the
uploaded retained histories. It uses the prior completed coefficient arrays,
preserves 64 material-wall trace inputs, and retains the source-dependent momentum.
It does not solve the physical exterior/collider/muon or select a quantum state.

## Reproduce

Python with NumPy and SciPy is required. From this extracted folder:

```powershell
$env:OPENBLAS_NUM_THREADS = '1'
$env:OMP_NUM_THREADS = '1'
& 'C:\Python314\python.exe' '.\run_response.py' --output '.\fresh_A'
& 'C:\Python314\python.exe' '.\run_response.py' --output '.\fresh_B'
& 'C:\Python314\python.exe' '.\verify_replays.py' '.\fresh_A' '.\fresh_B'
```

The output folders must not already exist. There is no Git command and no write
to any research worktree. Thread settings are for repeatability/performance, not
physical approximations.

`prepare_inputs.py` is an optional extraction producer for the ORIGINAL complete
integrated-source and history packages. It is not needed to reproduce the response
from the included self-contained `inputs/` files. It does not recompute M/B/K.

## Output conventions

Each `*_causal_maps.npz` uses 408 normalized canonical initial coordinates and
134 drive coordinates. The drives are 64 wall traces times (1,tau), then the three
saved magnetic traces times (1,tau). The same six latter columns are isolated in
`*_magnetic_columns.npz`. No physical amplitude or switching protocol is selected.

The wall trace ordering is (At,A1,A2,A3), each with (internal4,harmonic4). Ar is
not given a tangential wall boundary condition. The full320 reconstruction uses
(radial4,field5,internal4,harmonic4). At-rate placeholders in action maps do not
assert a physically vanishing time derivative of At.

The returned `weak_wall_*` arrays multiply the scaled action S_hat=T*S_original.
`wall_Euler_*` additionally remove the saved temporal endpoint contribution.
Terminal interior momentum is time-scaled and kinetically whitened as detailed in
DERIVATION.md. These maps are not physical exterior conditions to impose unchanged.

All primary finite-equation tests pass; an additional stricter raw field/rate
comparison between gauge-coordinate reconstructions does not pass 2e-10. No
continuum radial/time error or physical 2e-10 derivative admission is claimed.
