"""Extract only completed coefficient arrays; do not recompute Maxwell forms."""
from pathlib import Path
import sys, json, hashlib, numpy as np
from port_response import save_npz,digest,maxabs

def make(integrated, histories, output):
    integrated,histories,out=map(Path,(integrated,histories,output));out.mkdir(exist_ok=False)
    # Check all supplied prior-manifest entries, retaining scope of those files.
    checks={}
    for label,root in [('integrated',integrated),('histories',histories)]:
        manifest=json.loads((root/'SHA256SUMS.json').read_text());count=0
        for name,h in manifest.items():
            p=(root/name).resolve()
            if not p.is_relative_to(root.resolve()) or digest(p)!=h:raise ValueError('input mismatch '+str(p))
            count+=1
        checks[label]=dict(hashes_verified=count,manifest_sha256=digest(root/'SHA256SUMS.json'))
    sys.path.insert(0,str(integrated))
    from check_integrated_source import central_gauge_modes
    md=json.loads((histories/'MANIFEST.json').read_text());sides={};ancestry={};gcheck=[]
    gg=None
    for side in ['incoming','outgoing']:
        lo=json.loads((histories/side/'lo.json').read_text())['coordinate_time'];hi=json.loads((histories/side/'hi.json').read_text())['coordinate_time']
        samples={}
        for lab in ['lo','q000','q001','q002','q003','hi']:
            original=integrated/f'replay_A/{side}_{lab}.npz';raw=histories/side/(lab+'.npz');sm=json.loads((histories/side/(lab+'.json')).read_text())
            saved=dict(np.load(original,allow_pickle=False));fields=dict(np.load(raw,allow_pickle=False))
            G,G0,err=central_gauge_modes(fields,md['WALL'])
            if gg is None:
                gg=(G,G0)
                save_npz(out/'gauge_maps.npz',dict(full_spatial_gauge=G,full_temporal_gauge=G0,
                    relative_spatial_gauge=G[:,:4]-G[:,4:],relative_temporal_gauge=G0[:,:4]-G0[:,4:]))
            if not np.array_equal(G,gg[0]) or not np.array_equal(G0,gg[1]):raise ValueError('frozen gauge frame moved')
            dat={k:saved[k] for k in ['M','B','K','W','Wdot']}
            save_npz(out/(side+'_'+lab+'.npz'),dat)
            ancestry[side+'_'+lab]=dict(coefficient_sha256=digest(original),history_sample_sha256=digest(raw),history_meta_sha256=digest(histories/side/(lab+'.json')))
            samples[lab]=dict(time=sm['coordinate_time'],tau=(sm['coordinate_time']-lo)/(hi-lo),time_weight=sm['positive_time_quadrature'])
            gcheck.append(dict(side=side,label=lab,profile_error=float(max(err)),stiffness_null=maxabs(dat['K']@G),
                BT_null=maxabs(dat['B'].T@G),gauge_electric=maxabs(dat['M']@G+dat['B'].T@G0),
                gauge_value=maxabs(dat['B']@G+dat['K']@G0)))
        sides[side]=dict(lo=lo,hi=hi,duration=hi-lo,samples=samples)
    meta=dict(classification='UNCHANGED_EXTRACTS_OF_PREVIOUSLY_EVALUATED_PROVISIONAL_MAXWELL_FORMS',
        sides=sides,previous_revision=md['configuration']['head'],input_ancestry=ancestry,input_checks=checks,
        original_gauge_checks=gcheck,wall_trace_order='harmonic component inside field At,A1,A2,A3; no Ar trace condition',
        raw_field_order='radial4,field5,internal4,harmonic4',calibrated_backgrounds=True,
        physical_collider_history=False,new_background_or_state_selected=False)
    (out/'metadata.json').write_text(json.dumps(meta,indent=2,sort_keys=True)+'\n')
    (out/'SHA256SUMS.json').write_text(json.dumps({p.name:digest(p) for p in sorted(out.iterdir()) if p.is_file()},indent=2,sort_keys=True)+'\n')
    print(json.dumps(checks,indent=2))

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--integrated',type=Path,required=True);p.add_argument('--histories',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();make(a.integrated,a.histories,a.output)
