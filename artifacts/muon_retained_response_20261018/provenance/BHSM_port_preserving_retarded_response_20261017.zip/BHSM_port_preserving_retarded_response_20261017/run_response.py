"""Evaluate and independently verify finite causal maps on both uploaded arms.

Run with OPENBLAS_NUM_THREADS=1 for repeatable small BLAS contractions.
No repository writes or physics-parameter selection are performed.
"""
from __future__ import annotations
import argparse,json,sys,platform
from pathlib import Path
import numpy as np
import scipy
from port_response import *


def run(inputs,output):
    inputs,output=Path(inputs),Path(output)
    output.mkdir(parents=True,exist_ok=False)
    manifest=json.loads((inputs/'SHA256SUMS.json').read_text())
    for name,expected in manifest.items():
        if digest(inputs/name)!=expected:raise ValueError('source changed '+name)
    records=[]
    for side in ('incoming','outgoing'):
        d=prepare(side,inputs,'interior');s=causal_solve(d);wall=boundary_maps(d,s)
        direct=independent_original_dae(d)
        other=prepare(side,inputs,'normal_wall');so=causal_solve(other);wo=boundary_maps(other,so)
        n=2*d['nx'];nd=d['nd'];mag=slice(n+128,n+134);T=d['duration']
        # Compare the same zero-interior-initial-data boundary response in two
        # exact central-gauge representatives, not two physical preparations.
        Ng,Nt=d['gaugeN'],d['gaugeNt'];fixed=d['fixed'];gfix=Ng[fixed]
        gauge_rows=[];stage_mag={};spatial=np.arange(320).reshape(4,5,4,4)[:,1:].ravel();timeids=np.setdiff1d(np.arange(320),spatial)
        for lab in ('lo','q000','q001','q002','q003','hi'):
            a,b=wall['responses'][lab],wo['responses'][lab]
            diff=(a['qphys']-b['qphys'])[:,n:];vdiff=(a['vphys']-b['vphys'])[:,n:]
            ga=solve(gfix,diff[fixed]);gad=solve(gfix,vdiff[fixed]);expected=Ng@ga+Nt@gad
            gauge_rows.append(dict(label=lab,
                spatial_field_modulo_gauge=maxabs((diff-expected)[spatial]),
                time_rescaled_At_modulo_gauge=T*maxabs((diff-expected)[timeids]),
                rescaled_spatial_rate_modulo_gauge=T*maxabs(vdiff[spatial]-Ng[spatial]@gad),
                port_force_difference=maxabs((a['forceg']-b['forceg'])[:,n:]),
                port_momentum_difference=maxabs((a['momg']-b['momg'])[:,n:])))
            stage_mag[lab+'_physical_field_coefficients']=a['qphys'][:,mag]
            stage_mag[lab+'_spatial_rate_times_duration']=T*a['vphys'][spatial,mag]
            stage_mag[lab+'_scaled_wall_force']=a['forceg'][:,mag]
            stage_mag[lab+'_scaled_wall_momentum']=a['momg'][:,mag]
        maps=dict(initial_to_final=s['final'][:,:n],trace_and_probe_to_final=s['final'][:,n:],
            weak_wall_from_initial=wall['weak_wall'][:,:n],weak_wall_from_trace_and_probe=wall['weak_wall'][:,n:],
            wall_Euler_from_initial=wall['wall_euler_weak'][:,:n],wall_Euler_from_trace_and_probe=wall['wall_euler_weak'][:,n:],
            wall_temporal_endpoint=wall['wall_temporal_endpoint'],coefficient_reconstruction_frame=d['J'],
            kinetic_whitening=d['whitening'],original_indices_At_interior=d['y'],original_indices_dynamic=d['x'],
            original_indices_wall_trace=d['g'],gauge_fixed_indices=d['fixed'],
            final_original_DAE_difference=s['final']-direct['final'])
        save_npz(output/(side+'_causal_maps.npz'),maps)
        save_npz(output/(side+'_magnetic_columns.npz'),stage_mag)
        save_npz(output/(side+'_gauge_comparison.npz'),dict(
            weak_wall_difference=wall['weak_wall'][:,n:]-wo['weak_wall'][:,n:],
            Euler_wall_difference=wall['wall_euler_weak'][:,n:]-wo['wall_euler_weak'][:,n:]))
        measures=dict(
            stage_system_absolute=s['stage_equation_absolute'],stage_system_backward=s['stage_backward_error'],
            original_DAE_system_absolute=direct['equation_absolute'],original_DAE_system_backward=direct['backward_error'],
            canonical_vs_original_stage_difference=maxabs(s['stages']-direct['stages']),
            canonical_vs_original_final_difference=maxabs(s['final']-direct['final']),
            original_interior_Gauss=max(a['gauss'] for a in wall['responses'].values()),
            original_interior_momentum=max(a['momentum'] for a in wall['responses'].values()),
            original_interior_Euler=max(a['euler'] for a in wall['responses'].values()),
            homogeneous_symplectic=s['homogeneous_symplectic_error'],
            point_Hamiltonian_identity=s['homogeneous_hamiltonian_identity'],
            discrete_wall_temporal_Green=wall['discrete_boundary_green_error'],
            wall_antisymmetry_without_temporal=wall['wall_antisymmetry_without_temporal_term'],
            alternative_gauge_wall_weak_difference=maxabs(wall['weak_wall'][:,n:]-wo['weak_wall'][:,n:]),
            alternative_gauge_wall_Euler_difference=maxabs(wall['wall_euler_weak'][:,n:]-wo['wall_euler_weak'][:,n:]))
        finite_tests={
            'causal_stage_equations':measures['stage_system_absolute']<2e-10,
            'independent_original_DAE':max(measures['original_DAE_system_absolute'],measures['canonical_vs_original_stage_difference'],measures['canonical_vs_original_final_difference'])<2e-10,
            'Gauss_momentum_Euler_equations':max(measures['original_interior_Gauss'],measures['original_interior_momentum'],measures['original_interior_Euler'])<2e-10,
            'homogeneous_symplectic_map':measures['homogeneous_symplectic']<2e-10,
            'wall_temporal_Green_identity':measures['discrete_wall_temporal_Green']<2e-10,
            'independent_gauge_wall_response':max(measures['alternative_gauge_wall_weak_difference'],measures['alternative_gauge_wall_Euler_difference'])<2e-10,
            'positive_finite_gauge_slice_mass':d['kinetic_min_unwhitened']>0,
            'nonzero_At_trace_response_preserved':max(maxabs(a['forceg'][:16,mag]) for a in wall['responses'].values())>1e-12,
        }
        # Preserve additional, stricter reconstruction diagnostics rather than
        # promoting tiny boundary differences to full-field relative-gauge accuracy.
        diagnostic=max(max(x['spatial_field_modulo_gauge'],x['time_rescaled_At_modulo_gauge'],x['rescaled_spatial_rate_modulo_gauge']) for x in gauge_rows)
        record=dict(side=side,duration=T,finite_equation_checks=finite_tests,measures=measures,
            kinetic_eigenvalue_min_unwhitened=d['kinetic_min_unwhitened'],kinetic_eigenvalue_max_unwhitened=d['kinetic_max_unwhitened'],
            additional_gauge_field_diagnostic=gauge_rows,
            field_gauge_reconstruction_max_absolute=diagnostic,
            field_gauge_reconstruction_at_2e_10=diagnostic<2e-10,
            magnetic_response_coefficients=dict(
                final_spatial_field_max_per_unit_canonical_charge=maxabs(wall['responses']['hi']['qphys'][spatial,mag]),
                final_scaled_interior_momentum_max_per_unit_canonical_charge=maxabs(s['final'][d['nx']:,mag]),
                wall_At_response_max_in_scaled_action=max(maxabs(a['forceg'][:16,mag]) for a in wall['responses'].values()),
                constant_amplitude_wall_At_response_max_in_scaled_action=max(maxabs(a['forceg'][:16,n+128:n+131]) for a in wall['responses'].values())),
            scope='finite four-stage initial-value response on held provisional Maxwell coefficients; all wall traces are unresolved external inputs')
        records.append(record)
        (output/'progress.json').write_text(json.dumps(records,indent=2,sort_keys=True)+'\n')
        print(side,json.dumps(measures,sort_keys=True),flush=True)
    result=dict(classification='EVALUATED_FINITE_CAUSAL_MAXWELL_WALL_RESPONSE_WITH_OPEN_TRACE_INPUTS',
        source_revision='70e82fd4dbe5f53ff27ae17f6aaac7a4727c1fde',records=records,
        input_files_verified=len(manifest),integration=dict(method='four-stage Gauss-Legendre canonical collocation at exactly the exported nodes',
            subintervals=1,no_time_interpolation=True,temporal_continuum_error_certified=False,radial_continuum_error_certified=False),
        layout=dict(original_value_coordinates=320,interior_At_eliminated=48,wall_At_preserved=16,
            wall_spatial_tangential_components=48,full_wall_trace_inputs=64,Ar_wall_boundary_condition_imposed=False,
            zero_trace_central_gauge_dimensions=4,central_gauge_dimensions_with_nonzero_wall_trace=4,
            dynamical_coordinates=204,canonical_initial_variables=408,
            affine_trace_coefficients=128,magnetic_trace_coefficients=6,all_response_input_columns=542),
        basis_and_units=dict(tau='(t-t_lo)/duration',action_scaled='S_hat=duration*S_original',
            temporal_gauge_coordinate='A_hat_t=duration*A_t',interior_canonical_variables='X=R*x, Pi_hat=R^-T*duration*p',
            R='fixed Cholesky of actual relative-gauge-slice kinetic matrix at the initial endpoint',
            source_basis='general 64 wall traces times (1,tau), plus three actual magnetic W(t) traces times (1,tau)',
            physical_B_or_switching_protocol_selected=False,
            At_rate_array='unused At-rate slots omitted; no assertion that actual d_t At vanishes'),
        all_primary_finite_equation_checks_pass=all(all(r['finite_equation_checks'].values()) for r in records),
        full_field_gauge_reconstruction_guard_pass=all(r['field_gauge_reconstruction_at_2e_10'] for r in records),
        physical_outgoing_derivative_admitted=False,physical_exterior_closed=False,
        physical_collider_state_constructed=False,interface_between_arms_supplied=False,
        matter_native_reference_composed=False,muon_quantum_pole_or_magnetic_moment_evaluated=False,
        coupled_corrections=0,fresh_collider_Maxwell_all226=None,a_mu=None,g_mu=None,total_uncertainty=None,git_writes=False,
        NEXT_OPERAND='Couple the retained 64 wall trace/reaction relation on each arm to the actual matter, moving interface, exterior/native domain and inherited-state response. Do not set the returned wall electric equations or gauge-edge data to zero. Obtain physical preparation, convergence and complete derivatives before any all226 correction or muon readout.')
    (output/'result.json').write_text(json.dumps(result,indent=2,sort_keys=True,allow_nan=False)+'\n')
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--inputs',type=Path,default=Path(__file__).parent/'inputs');p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();run(a.inputs,a.output)
