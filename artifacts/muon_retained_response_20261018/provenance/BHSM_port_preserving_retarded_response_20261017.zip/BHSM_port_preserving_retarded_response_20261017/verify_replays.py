"""Compare deterministic response outputs without changing either run."""
from pathlib import Path
import argparse,hashlib,json

def verify(a,b):
    a,b=Path(a),Path(b)
    aa={p.relative_to(a).as_posix():p for p in a.rglob('*') if p.is_file()}
    bb={p.relative_to(b).as_posix():p for p in b.rglob('*') if p.is_file()}
    if aa.keys()!=bb.keys():raise AssertionError('different output members')
    table=[]
    for name in sorted(aa):
        ha=hashlib.sha256(aa[name].read_bytes()).hexdigest();hb=hashlib.sha256(bb[name].read_bytes()).hexdigest()
        if ha!=hb:raise AssertionError('replay differs: '+name)
        table.append(dict(path=name,sha256=ha,byte_identical=True))
    return table

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('a',type=Path);p.add_argument('b',type=Path);args=p.parse_args()
    print(json.dumps(dict(replays=verify(args.a,args.b)),indent=2))
