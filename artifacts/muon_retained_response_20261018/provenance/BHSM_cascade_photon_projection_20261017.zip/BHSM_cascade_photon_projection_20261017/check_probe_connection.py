"""Reproducible constructed tests, explicitly not a physical BHSM execution."""
from __future__ import annotations
import argparse, json
from dataclasses import fields
from pathlib import Path
import numpy as np
import sympy as sp
from scipy.linalg import expm
from probe_connection import (DaughterData, amplitude, coherent_source_and_first,
    real_parameter_rate, schur_lifts, projected_photon_vertex,
    ward_residual, pole_firsts, double_spectral_return)


def maxabs(x): return float(np.max(np.abs(x)))

def main(output):
    out=Path(output)
    if out.exists(): raise FileExistsError('preserve previous evidence')
    out.mkdir(parents=True)
    rng=np.random.default_rng(71017)
    def complex_random(shape,scale=1):
        return scale*(rng.normal(size=shape)+1j*rng.normal(size=shape))
    groups={}
    n,legs=7,24
    base=dict(right=complex_random((n,legs,2,4),.15),
       field_return=complex_random((n,legs,legs),.08),
       left=complex_random((n,legs,4,2),.15),
       muon=complex_random((n,4,2),.3),
       neutrino_left=complex_random((n,2),.3),
       electron_left=complex_random((n,2,4),.3),
       antineutrino=complex_random((n,2),.3),weight=np.linspace(.2,.8,n))
    first={k:complex_random(np.shape(v),.02) for k,v in base.items() if k!='weight'}
    first['weight']=np.linspace(-.02,.015,n)
    data=DaughterData(**base);ddata=DaughterData(**first)
    app=coherent_source_and_first(data,ddata)
    # Independent route constructs all64 tensor entries first and then contracts.
    tensor=np.einsum('naij,nab,nbkl->nijkl',base['right'],base['field_return'],base['left'])
    # c is tensor index k; keep exact index order nu,mu,e,anti.
    direct=np.einsum('nijkl,ni,njs,nrk,nl->nrs',tensor,base['neutrino_left'],
        base['muon'],base['electron_left'],base['antineutrino'])
    action_error=maxabs(direct-app['amplitude'])
    assert action_error<1e-13
    def independent_source(h):
        d={k:v+h*first[k] for k,v in base.items()}
        c=np.einsum('naij,nab,nbkl->nijkl',d['right'],d['field_return'],d['left'])
        a=np.einsum('nijkl,ni,njs,nrk,nl->nrs',c,d['neutrino_left'],d['muon'],d['electron_left'],d['antineutrino'])
        return (np.sqrt(d['weight'])[:,None,None]*a).reshape(-1,2)
    sweeps=[]
    for h in (.02,.01,.005,.0025):
        fd=(-independent_source(2*h)+8*independent_source(h)-8*independent_source(-h)+independent_source(-2*h))/(12*h)
        sweeps.append(dict(step=h,error=maxabs(fd-app['source_first'])))
    assert sweeps[-1]['error']<2e-10
    rate,drate=real_parameter_rate(app['source'],app['source_first'])
    h=.0025
    def gram(t):
        f=independent_source(t);return f.conj().T@f
    dgram=(-gram(2*h)+8*gram(h)-8*gram(-h)+gram(-2*h))/(12*h)
    assert maxabs(dgram-drate)<2e-10
    groups['coherent_all24_source_and_total_first']={
        'passed':True,'all24_legs_retained':True,'joint_nodes':n,'source_shape':list(app['source'].shape),
        'tensor_route_error':action_error,'source_first_sweep':sweeps,
        'rate_first_error':maxabs(dgram-drate),'rate_min_eigenvalue':float(np.linalg.eigvalsh(rate)[0]),
        'physical_external_sections':False}

    size,retained=8,2
    x0=complex_random((size,size),.2)+np.diag(np.linspace(2,5,size))
    x1=x0+complex_random((size,size),.1)
    Q=np.diag([1,1,0,1,-1,2,1,0]).astype(complex)
    q=np.array([.3,.11,-.07,.13])
    target=x1@Q-Q@x0
    photon=np.zeros((4,size,size),complex);photon[0]=target/q[0]
    antisym=np.zeros((4,4,size,size),complex)
    for i in range(4):
        for j in range(i):
            antisym[i,j]=complex_random((size,size),.3);antisym[j,i]=-antisym[i,j]
    photon+=np.einsum('b,abij->aij',q,antisym)
    ward=ward_residual(x1,x0,photon,q,Q,retained)
    assert maxabs(ward['full_residual'])<1e-13
    assert maxabs(ward['reduced_residual'])<1e-13
    incomplete=photon.copy();incomplete[:,retained:,retained:]=0
    omission=ward_residual(x1,x0,incomplete,q,Q,retained)
    assert maxabs(omission['reduced_residual'])>1e-6
    groups['schur_vertex_preserves_finite_transfer_ward_identity']={
        'passed':True,'full_residual':maxabs(ward['full_residual']),
        'reduced_residual':maxabs(ward['reduced_residual']),
        'deleted_daughter_insertion_error':maxabs(omission['reduced_residual']),
        'ward_vertex_constructed_not_physical':True}

    # Pure daughter-frame motion must not change the retained operator.
    g=complex_random((size-retained,size-retained),.2)
    g=(g+g.conj().T)/2
    generator=np.zeros((size,size),complex);generator[retained:,retained:]=1j*g
    dx=x0@generator-generator@x0
    lift=schur_lifts(x0,retained)
    fullfirst=lift['left']@dx@lift['right']
    daughteronly=np.zeros_like(dx);daughteronly[retained:,retained:]=dx[retained:,retained:]
    spurious=lift['left']@daughteronly@lift['right']
    frame=expm(.17*generator)
    transformed=schur_lifts(frame.conj().T@x0@frame,retained)['reduced']
    assert maxabs(fullfirst)<1e-13 and maxabs(transformed-lift['reduced'])<1e-13
    assert maxabs(spurious)>1e-6
    groups['moving_daughter_frame_contact_cancellation']={
        'passed':True,'complete_first':maxabs(fullfirst),
        'finite_frame_change':maxabs(transformed-lift['reduced']),
        'spurious_frozen_coupling_first':maxabs(spurious)}

    # Exact two-spin degenerate parent counterexample: same B=0 response,
    # but off-diagonal daughter magnetic coupling changes the splitting.
    hd=sp.diag(2,4);v=sp.eye(2);hm=hd.inv()
    H=hm.row_join(v).col_join(v.row_join(hd))
    Gamma=-H
    D=-hd;B=-v;C=-v
    S=Gamma[:2,:2]-B*D.inv()*C
    Z=sp.eye(2)+hd.inv()**2
    hb=sp.Matrix([[0,1],[1,0]])
    sb=hd.inv()*hb*hd.inv()
    M=Z.inv()*sb
    assert S==sp.zeros(2)
    assert sp.simplify(M.det()+sp.Rational(1,85))==0 and sp.trace(M)==0
    G=np.array(Gamma,dtype=complex)
    magnetic=np.zeros((3,4,4),complex);magnetic[0,2:,2:]=-np.array(hb,dtype=complex)
    result=pole_firsts(G,np.eye(4),magnetic,2,np.eye(2),np.eye(2))
    slopes=np.sort(np.linalg.eigvals(result['magnetic_matrices'][0]).real)
    expected=np.array([-1,1])/np.sqrt(85)
    full_H=np.array(H,dtype=float)
    vals,vec=np.linalg.eigh(full_H);zero=vec[:,np.argsort(abs(vals))[:2]]
    full_HB=-magnetic[0]
    actual=np.linalg.eigvalsh(zero.conj().T@full_HB@zero)
    assert maxabs(actual-expected)<1e-13
    double=double_spectral_return([2,4],np.eye(2),np.eye(2),np.array(hb,float),0.)
    assert maxabs(double-np.array(sb,float))<1e-14
    diagonal=double_spectral_return([2,4],np.eye(2),np.eye(2),np.zeros((2,2)),0.)
    groups['same_zero_field_data_different_transverse_response']={
        'passed':True,'exact_Z':['5/4','17/16'],'exact_response_eigenvalues':['-1/sqrt(85)','+1/sqrt(85)'],
        'eigenvalues':slopes.tolist(),'full_H_comparison':maxabs(actual-expected),
        'double_spectral_discrepancy':maxabs(double-np.array(sb,float)),
        'diagonal_spectral_truncation_misses':maxabs(double-diagonal),
        'daughter_energy_firsts':[0,0],
        'complete_B0_inverse_same_between_models':True,
        'new_BHSM_magnetic_coupling_selected':False}

    # Four-dimensional Pauli vertex is exactly transverse, so Ward alone
    # cannot select its coefficient. These are Clifford algebra controls.
    i=sp.I;I2=sp.eye(2);Z2=sp.zeros(2)
    pauli=[sp.Matrix([[0,1],[1,0]]),sp.Matrix([[0,-i],[i,0]]),sp.diag(1,-1)]
    gamma=[I2.row_join(Z2).col_join(Z2.row_join(-I2))]
    for s in pauli:gamma.append(Z2.row_join(s).col_join((-s).row_join(Z2)))
    qs=sp.symbols('q0:4',real=True)
    spin=[[i*(gamma[a]*gamma[b]-gamma[b]*gamma[a])/2 for b in range(4)]for a in range(4)]
    vertices=[sum((spin[a][b]*qs[b] for b in range(4)),sp.zeros(4))for a in range(4)]
    wardpauli=sum((qs[a]*vertices[a] for a in range(4)),sp.zeros(4))
    assert sp.simplify(wardpauli)==sp.zeros(4)
    assert any(v!=sp.zeros(4)for v in vertices)
    groups['pauli_is_transverse_not_determined_by_ward']={'passed':True,'q_sigma_q':'identically zero','Pauli_tensor_itself_nonzero':True,
        'new_Pauli_coefficient_inserted':False}

    # First/mixed interactions and their signs in exact scalar symbols.
    aa,bb,cc,dd,ap,bp,cp,dp=sp.symbols('a b c d a1 b1 c1 d1', nonzero=True)
    z=sp.symbols('s')
    expr=aa+z*ap-(bb+z*bp)*(cc+z*cp)/(dd+z*dp)
    expected_first=ap-bp*cc/dd-bb*cp/dd+bb*cc*dp/dd**2
    assert sp.simplify(sp.diff(expr,z).subs(z,0)-expected_first)==0
    groups['exact_schur_sign_and_all_contacts']={'passed':True,'scalar_product_rule':'exact'}

    packet={
        'classification':'CONSTRUCTED_AMPLITUDE_AND_GAUGED_SCHUR_CONNECTION_CONTROLS',
        'source_revision':'70e82fd4dbe5f53ff27ae17f6aaac7a4727c1fde',
        'groups':groups,'group_count':len(groups),'all_constructed_checks_pass':all(x['passed']for x in groups.values()),
        'physical_mode_projection_executed':False,'physical_quantum_daughter_operator_supplied':False,
        'physical_outgoing_derivative_admitted':False,'fresh_Maxwell_226_admission':False,
        'coupled_corrections':0,'physical_a_mu':None,'physical_g_mu':None,'total_uncertainty':None,
        'source_archive_bytes_imported':False,'repository_writes':False,
        'input_scope':'constructed finite arrays; source conventions inspected through GitHub; no physical C tensor reconstructed from summaries'}
    (out/'result.json').write_text(json.dumps(packet,indent=2,sort_keys=True,allow_nan=False)+'\n')
    print(json.dumps(packet,indent=2))

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    main(parser.parse_args().output)
