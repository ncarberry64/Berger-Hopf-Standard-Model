# BHSM cascade electromagnetic-insertion connection

## Status

Constructed mathematical controls only. No physical packet, quantum daughter
operator, inherited state, pole, magnetic moment, correction or Git write.
The source of the tested physical data is not replaced by the test fixtures.
Read `DERIVATION.md` before integration.

## Run the independent checks

Python with NumPy, SciPy and SymPy is required. From this directory:

```text
python check_probe_connection.py --output new_run_A
python check_probe_connection.py --output new_run_B
```

Output directories must not already exist. Compare their `result.json` bytes.
The included `replay_A` and `replay_B` record the executed controls. A physical
2e-10 admission is not implied by small residuals of these finite examples.

## Reusable functions

`probe_connection.py` contains the coherent all-leg daughter amplitude/source
and its total first derivative, real-parameter rate Gram, Schur lifts,
finite-transfer photon projection, Ward residual, supplied pole firsts, and
non-diagonal magnetic spectral return. Required physical inputs cannot be None;
unknown derivatives must not be replaced by test fixtures or zero arrays.

The source-data formula follows the read repository convention but is not a
byte-for-byte repository import. A reviewed integration must compare labels,
normalizations, source domains and analytic left placements with live owners.

The finite matrix functions are not continuum outgoing solvers. Call them on
an actual controlled discretization or use the same identities with the actual
inverse applications, retaining their errors, source and domain derivatives.

## Next physical application

At the retained shared physical state, construct the measuring-photon insertion
of the coupled quantum inverse (not merely the stored static frequency first).
Contract it through the actual outgoing daughter solves and two-spin pole.
Keep source, interaction, native completion, moving-frame and boundary contacts.
Check the Ward identity and transverse Pauli response separately. Do not start
another static daughter-energy scan to fill this missing magnetic operand.
