# Retained-data magnetic angular application

This package reads actual archived incoming/outgoing raw268 field coordinates at
BHSM PR #465 `70e82fd4dbe5f53ff27ae17f6aaac7a4727c1fde` and evaluates the
**spatial magnetic part** of the gauge-action third variation at the material
wall. Three 100-by-100 matrices per background retain n=0 and the complete n=1
scalar coefficient space in the owned right coframe.

It does not solve the collider preparation, radial/chronological return,
complete gauge-Higgs/native operator, quantum daughter propagator, or muon pole.
Its coefficients are per canonical e and are not magnetic moments or residual
improvements. No physical electric charge was newly chosen.

Run from this directory with Python, NumPy and SymPy installed:

```sh
python verify_inputs.py
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python check_retained_application.py new_run
```

On Windows, use the same Python command without the environment-variable prefix;
set those variables separately when reproducing byte-for-byte on a compatible
numerical environment. The program refuses to overwrite a previous output.
Cross-platform byte identity is not promised; compare numerical outputs within
explicit scope if the runtime changes.

`dependencies/` preserves the two reused files from the preceding supplied local
magnetic-action package. These are source-derived implementations, not an
installed full BHSM checkout. `PROVENANCE.json` records original repository
paths, source blob IDs, raw-entry CRCs/hashes and the fact that the whole NPZ was
not transferred or rehashed. `DERIVATION.md` gives the mathematical scope.

`replay_A` and `replay_B` were executed in this runtime and their 15 corresponding
files are byte-identical. The first exact floating-zero assertion failed at
roundoff scale; its files are preserved. An interrupted timed execution is also
preserved and is not counted as a completed run. Some independently sampled
coordinate-partial absolute errors exceed 2e-10. Relative convergence of this
partial is not the unchanged physical outgoing-derivative admission.

No GitHub or Windows-worktree writes were made.
