# Next original-action application

Use current local work; do not reset to the pinned source revision if newer work
exists. Preserve the two new numerical arrays' status as provisional reference
wall data, not physical collider sections.

1. Compare `wall_data` against the live `intrinsic_m4_weight_jet`,
   `geometric_connection_coefficient_jets`, and full trace-enriched wall
   reconstruction on the same raw268. R4 and lapse were independently checked
   against the source receipt; this is not a check of every live function.
2. Verify the explicit angular transformation from `(1,2x0,2x1,2x2,2x3)` into
   the current normalized Wigner real basis. Do not identify array indices by
   dimension or relabel the odd/even block as an old eight-source map.
3. This array is the original **bulk spatial density evaluated at the wall**.
   It is NOT an added surface interaction, radial integral, new terminal
   boundary condition, or a complete 24-leg field Green. Apply the actual
   radial fields/tests and integrate the original action with its existing
   Maxwell-to-cap normalization once, together with electric, radial, Higgs,
   geometric, source and interface terms.
4. Reuse actual source-compatible odd/even operator implementations. On a
   homogeneous static reference, first magnetic return crosses harmonic parity.
   Supply the appropriate common-domain returned solutions and source maps.
   On a nonhomogeneous physical packet/background, test the actual angular
   support rather than importing this parity reduction.
5. Recheck the complete source/domain derivatives against original equations.
   Do not use the four partials here as a full outgoing derivative, or repeat
   precision work solely to reduce this isolated block's roundoff.
6. For an unmatched background, the gauge Hessian identity includes the
   original action gradient contracted with the derivative of the gauge
   generator. The included check is not a proof of the complete BRST quotient
   and does not certify that a specific repository code omitted the contact.
7. Only after actual physical outgoing admission, perform a coupled correction
   and fresh Maxwell/all226 checks at 2e-10. Then apply the physical pole/residue
   and soft magnetic readout with native completion/overlap subtraction.

The pressing unresolved physical operand is still the mode/preparation/current
and retarded/native domain construction. A physical zero or final g cannot be
inferred from a static n=0 diagonal magnetic projection. No reconnection, bubble
surface force, sea budget, or state selection is added by this package.
