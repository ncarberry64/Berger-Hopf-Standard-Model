"""Verify the two visible GitHub range downloads and existing extracted NPYs.

This checks ZIP entry CRCs and hashes of the extracted entries. It does NOT
claim that the untransferred whole NPZ archive has been SHA256 verified.
"""
from pathlib import Path
import base64, hashlib, io, json, struct, zlib
import numpy as np

ROOT=Path(__file__).resolve().parent

def verify():
    p=json.loads((ROOT/'PROVENANCE.json').read_text())
    names={'incoming':'incoming_field_archive_range.b64','outgoing':'field_archive_tail.b64'}
    for e in p['entries']:
        b=base64.b64decode((ROOT/'source_snapshot'/names[e['side']]).read_bytes())
        pos=b.find(b'PK\x03\x04')
        if pos<0:raise ValueError('ZIP local header absent')
        h=struct.unpack_from('<4s5H3I2H',b,pos)
        if h[2]!=0 or h[3]!=8:raise ValueError('unsupported ZIP flags/compression')
        ns,es=h[-2:];name=b[pos+30:pos+30+ns].decode('utf-8')
        off=pos+30+ns+es
        raw=zlib.decompress(b[off:off+h[7]],-15)
        if name!=e['zip_entry'] or len(raw)!=h[8] or zlib.crc32(raw)!=h[6]:raise ValueError('entry identity/CRC mismatch')
        if raw!=(ROOT/'source_snapshot'/name).read_bytes():raise ValueError('extracted file changed')
        if hashlib.sha256(raw).hexdigest()!=e['npy_sha256']:raise ValueError('entry SHA256 mismatch')
        a=np.load(io.BytesIO(raw),allow_pickle=False)
        if a.shape!=(268,) or not np.isfinite(a).all():raise ValueError('invalid retained raw268')
    return {'extracted_entries_verified':2,'whole_archive_sha256_verified':False}

if __name__=='__main__': print(json.dumps(verify(),sort_keys=True))
