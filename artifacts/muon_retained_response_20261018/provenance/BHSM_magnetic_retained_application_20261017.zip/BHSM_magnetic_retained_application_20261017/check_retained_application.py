"""Checks on CRC-validated actual retained raw268 arrays, not synthetic bases."""
from pathlib import Path
import argparse, hashlib, json, sys, itertools, numpy as np
from retained_magnetic_application import (wall_data,fields,angular_matrix,unpack_point,rule8,rule24)
from action_magnetic_kernel import (FieldJet,curvature,curvature_first,pairing,local_hessian,bracket)
from check_action_insertion import independent_matrix_action

ROOT=Path(__file__).resolve().parent
REFS={'incoming':{'R4':0.9633777962755172,'lapse':1.108427234091954},
      'outgoing':{'R4':0.9633777962755175,'lapse':0.6981395735679908}}

def independent_element(raw,axis,i,j,step):
    x,w=rule8();d,base,probes,u,v,dens=fields(raw,x)
    sums=0j
    for p in range(len(x)):
        a,b,uu,vv=(unpack_point(base,p),unpack_point(probes[axis],p),
                   unpack_point(u,p,left_index=i),unpack_point(v,p,right_index=j))
        val=0j
        for ib,iu,iv in itertools.product((-1,1),repeat=3):
            val+=ib*iu*iv*independent_matrix_action(a.plus(b,ib*step).plus(uu,iu*step).plus(vv,iv*step),dens)
        sums+=w[p]*val/(8*step**3)
    return sums


def gauge_ward(raw):
    d=wall_data(raw);a=d['connection'];z=np.zeros_like(a)
    base=FieldJet(a,z,z,np.zeros((3,5,4)))
    dens=np.array([0,0,d['dang'],0,0]);units=np.eye(20).reshape(20,5,4)
    tests=[FieldJet(x,z,z,np.zeros((3,5,4))) for x in units]
    f=curvature(base)
    residual=np.array([pairing(f,curvature_first(base,v),dens) for v in tests])
    ward=[];naive=[]
    for aidx in range(3):
        alpha=np.eye(4)[aidx]
        orbit=FieldJet(bracket(a,alpha),z,z,np.zeros((3,5,4)))
        for v in tests:
            lhs=local_hessian(base,orbit,v,dens)
            contact=np.sum(residual.reshape(5,4)*bracket(v.value,alpha))
            ward.append(lhs+contact);naive.append(lhs)
    return {'max_complete_identity_absolute':float(np.max(abs(np.asarray(ward)))),
            'max_complete_identity_per_density':float(np.max(abs(np.asarray(ward)))/abs(d['dang'])),
            'naive_K_times_gauge_direction_max':float(np.max(abs(np.asarray(naive)))),
            'naive_K_times_gauge_direction_max_per_density':float(np.max(abs(np.asarray(naive)))/abs(d['dang'])),
            'spatial_wall_action_gradient_max':float(np.max(abs(residual))),
            'scope':'constant internal gauge directions; spatial action at retained wall, no full BRST quotient'}


def run(out):
    out=Path(out);out.mkdir(parents=True,exist_ok=False)
    records=[]
    for side in ('incoming','outgoing'):
        raw=np.load(ROOT/'source_snapshot'/f'{side}_raw_fields.npy',allow_pickle=False)
        matrices,d=angular_matrix(raw,rule8);check,_=angular_matrix(raw,rule24)
        pref=float(d['prefactor_per_e']);normalized=matrices/pref
        assert np.max(abs(matrices.imag))<1e-12
        assert max(abs(d[k]-v) for k,v in REFS[side].items())<1e-14
        np.save(out/(side+'_spatial_magnetic_matrix_per_e3x100x100.npy'),matrices.real,allow_pickle=False)
        np.save(out/(side+'_normalized_spatial_magnetic_matrix3x100x100.npy'),normalized.real,allow_pickle=False)
        # Independent indexed original scalar-action tests: nonzero, zero, and mixed coordinates.
        ix=[]
        for a in range(3):
            flat=np.argsort(abs(normalized[a]).ravel())[-4:]
            ix += [(a,*np.unravel_index(k,(100,100))) for k in flat]
            ix += [(a,8,33),(a,0,50),(a,8,8),(a,28,33)]
        pol=[]
        for h in (.5,1.):
            errors=[abs(independent_element(raw,a,i,j,h)-matrices[a,i,j]) for a,i,j in ix]
            pol.append({'step':h,'checked_entries':len(ix),'max_absolute':float(max(errors)),
                        'max_per_common_prefactor':float(max(errors)/abs(pref))})
        assert max(t['max_per_common_prefactor'] for t in pol)<2e-11
        derivative=[]
        for axis,name in ((0,'log_R'),(98,'normal_value'),(260,'H1_real'),(261,'H2_real')):
            x=raw.astype(complex);x[axis]+=1e-20j
            jc,_=angular_matrix(x,rule8);analytic=jc.imag/1e-20
            sequence=[]
            for h in (2e-3,1e-3,5e-4):
                vals=[]
                for v in (2,1,-1,-2):
                    moved=raw.copy();moved[axis]+=v*h;vals.append(angular_matrix(moved,rule8)[0].real)
                numerical=(-vals[0]+8*vals[1]-8*vals[2]+vals[3])/(12*h)
                err=float(np.max(abs(numerical-analytic)))
                sequence.append({'step':h,'max_absolute':err,'max_per_base_prefactor':err/abs(pref),
                    'relative_to_max_derivative':err/max(1.,float(np.max(abs(analytic))))})
            assert min(q['relative_to_max_derivative'] for q in sequence)<2e-10
            derivative.append({'raw_index':axis,'direction':name,'analytic_max_absolute':float(np.max(abs(analytic))),
                               'finite_difference':sequence})
            np.save(out/(side+f'_spatial_magnetic_rawpartial{axis}.npy'),analytic,allow_pickle=False)
        ward=gauge_ward(raw);assert ward['max_complete_identity_per_density']<2e-12
        row={'side':side,'R4':float(d['R4']),'lapse':float(d['lapse']),'connection_lambda':float(d['lam']),
             'angular_density_at_material_wall':float(d['dang']),'prefactor_per_e_can':pref,
             'retained_H_real':raw[260:264].tolist(),'retained_H_rate_real':raw[264:268].tolist(),
             'original_material_connection':d['connection'].tolist(),
             'max_matrix_per_e_can':float(np.max(abs(matrices))),
             'max_normalized_entry':float(np.max(abs(normalized))),
             'constant_constant_max':float(np.max(abs(matrices[:,:20,:20]))),
             'odd_odd_max':float(np.max(abs(matrices[:,20:,20:]))),
             'even_odd_max':float(np.max(abs(matrices[:,:20,20:]))),
             'normalized_even_odd_frobenius_per_axis':np.linalg.norm(normalized[:,:20,20:],axis=(1,2)).tolist(),
             'symmetry_max':float(np.max(abs(matrices-matrices.transpose(0,2,1)))),
             'exact_degree3_rule8_vs_rule24_absolute':float(np.max(abs(matrices-check))),
             'rule_difference_per_prefactor':float(np.max(abs(matrices-check))/abs(pref)),
             'independent_scalar_action_polarization':pol,'raw_coordinate_partials':derivative,'off_shell_gauge_identity':ward}
        assert row['rule_difference_per_prefactor']<2e-14
        assert max(row['constant_constant_max'],row['odd_odd_max'])/abs(pref)<2e-14
        records.append(row)
        (out/(side+'_result.json')).write_text(json.dumps(row,indent=2,sort_keys=True,allow_nan=False)+'\n')
        print(side,'actual retained spatial insertion evaluated',flush=True)
    result={'source_revision':'70e82fd4dbe5f53ff27ae17f6aaac7a4727c1fde',
       'classification':'EVALUATED_SPATIAL_MAGNETIC_ANGULAR_APPLICATION_ON_ACTUAL_RETAINED_WALL_DATA',
       'records':records,'retained_raw268_imported':True,'full_archive_downloaded_or_sha256_recomputed':False,
       'raw_entry_crc_verified':True,'angular_harmonics':'1,2x0,2x1,2x2,2x3',
       'field_order':'(At,Ar,A1,A2,A3) x unitTr16 (H1,H2,H3,HY); harmonic major',
       'scope':'per e_can, unit-Haar spatial magnetic density at material wall; not radially/time integrated or returned Green',
       'all_scoped_checks_pass':True,'physical_collider_state':False,'complete_gauge_Higgs_magnetic_insertion':False,
       'full_retarded_or_quantum_response_solved':False,'physical_outgoing_derivative_admitted':False,
       'coupled_corrections':0,'a_mu':None,'g_mu':None,'total_uncertainty':None,'repository_modified':False,
       'NEXT_OPERAND':'Compatible odd-sector radial/temporal/constraint Green, boundary maps and physical external mode injections; current spatial insertion must be assembled with the other terms exactly once.'}
    (out/'result.json').write_text(json.dumps(result,indent=2,sort_keys=True,allow_nan=False)+'\n')
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('output');args=p.parse_args();run(args.output)
