"""Independent component-action/matrix-action and exact coefficient checks.

All numerical nonzero backgrounds below are constructed derivative tests;
no physical collider or retained-history field values are supplied.
"""
from __future__ import annotations
import argparse, itertools, json, math
from pathlib import Path
import numpy as np
import sympy as sp
from action_magnetic_kernel import (
    FieldJet,zero_field,curvature,local_action,local_hessian,
    magnetic_hessian,magnetic_hessian_parts,anchor_photon_contact,
    anchored_probe,total_local_hessian_first,epsilon,
)

P=np.array([[[0,1],[1,0]],[[0,-1j],[1j,0]],[[1,0],[0,-1]]],complex)
GEN=np.concatenate((-1j*P/(2*np.sqrt(2)),(-.5j*np.eye(2)/np.sqrt(10/3))[None]))


def independent_matrix_action(jet,densities):
    """Original scalar action using matrix commutators, not component brackets."""
    conv=lambda a:np.einsum('...c,cij->...ij',a,GEN)
    a,at,ar,ea=[conv(getattr(jet,k)) for k in ('value','time','radial','angular')]
    comm=lambda a,b:a@b-b@a
    x=at[1]-ar[0]+comm(a[0],a[1])
    t=at[2:]-ea[:,0]+comm(a[0],a[2:])
    z=ar[2:]-ea[:,1]+comm(a[1],a[2:])
    b=2*a[2:].copy()
    for i,j,k in ((0,1,2),(1,2,0),(2,0,1)):
        b[i]+=ea[j,k+2]-ea[k,j+2]+comm(a[j+2],a[k+2])
    def inner(a,b):
        ia=np.trace(a,axis1=-2,axis2=-1)[...,None,None]*np.eye(2)/2
        ib=np.trace(b,axis1=-2,axis2=-1)[...,None,None]*np.eye(2)/2
        return np.sum(-4*np.trace((a-ia)@(b-ib),axis1=-2,axis2=-1)
                      -(20/3)*np.trace(ia@ib,axis1=-2,axis2=-1))
    e,r,d,k,beta=densities;y=t-beta*z
    return (k*inner(x,x)+e*inner(y,y)-r*inner(z,z)-d*inner(b,b))/2


def triple_polynomial_coefficient(base,b,u,v,densities,h):
    """Quartic original action => triple centered coefficient has no truncation."""
    value=0j
    for i,j,k in itertools.product((-1,1),repeat=3):
        x=base.plus(b,h*i).plus(u,h*j).plus(v,h*k)
        value+=i*j*k*independent_matrix_action(x,densities)
    return value/(8*h**3)


def field(seed,scale=1):
    rng=np.random.default_rng(seed)
    return FieldJet(*(scale*rng.normal(size=(5,4)) for _ in range(3)),
                    scale*rng.normal(size=(3,5,4)))


def original_hessian_by_polarization(base,u,v,d,h=.3):
    def mixed(step):
        return sum(i*j*independent_matrix_action(base.plus(u,i*step).plus(v,j*step),d)
                   for i,j in itertools.product((-1,1),repeat=2))/(4*step**2)
    # Quartic polynomial: only an h^2 contamination, removed exactly algebraically.
    return (4*mixed(h/2)-mixed(h))/3


def run(output):
    output=Path(output);output.mkdir(parents=True,exist_ok=False)
    checks={}
    base,b,u,v=field(120,.2),field(121,.3),field(122,.25),field(123,.2)
    densities=np.array([1.3,.8,1.1,.9,.17])
    original_error=abs(local_action(base,densities)-independent_matrix_action(base,densities))
    assert original_error<2e-14
    analytic=magnetic_hessian(base,b,u,v,densities)
    sweep=[]
    for h in (.4,.2,.1):
        direct=triple_polynomial_coefficient(base,b,u,v,densities,h)
        sweep.append({'step':h,'absolute_difference':float(abs(direct-analytic))})
    assert max(x['absolute_difference'] for x in sweep)<2e-11
    symmetry=max(abs(magnetic_hessian(base,*p,densities)-analytic)
                 for p in itertools.permutations((b,u,v)))
    parts=magnetic_hessian_parts(base,b,u,v,densities)
    assert symmetry<1e-13
    checks['source_defined_gauge_action_third_variation']={
        'matrix_vs_component_action_difference':float(original_error),
        'independent_triple_polarization':sweep,
        'third_variation_permutation_difference':float(symmetry),
        'omitted_background_curvature_contact_magnitude':float(abs(parts['probe_background_curvature'])),
        'scope':'constructed local jets, actual original action conventions; no physical base'}

    # Exact anchor contact on the three photon axes, 20 gauge + 4 scalar coordinates.
    n=np.array([0.,0.,-1.]);s=np.r_[-np.sqrt(2)*n,np.sqrt(10/3)]
    contact=anchor_photon_contact(n)
    exact_contact=np.array(contact,dtype=int)
    assert np.array_equal(contact,exact_contact)
    spectra=[]
    for axis in range(3):
        matrix=sp.Matrix(exact_contact[axis]);ev=matrix.eigenvals()
        assert ev=={sp.Integer(-1):2,sp.Integer(0):20,sp.Integer(1):2}
        assert matrix==matrix.T
        spectra.append({str(k):int(v) for k,v in sorted(ev.items(),key=lambda x:x[0])})
    # All 3x20x20 gauge entries verified against direct original curvature derivatives
    # at a nonzero generic background; the anchor b.value=0 makes this universal.
    tests=[]
    for j in range(20):
        a=np.eye(20)[j].reshape(5,4);tests.append(FieldJet(a,np.zeros_like(a),np.zeros_like(a),np.zeros((3,5,4))))
    discrepancy=0.
    for k in range(3):
        probe=anchored_probe(k,s)
        f=curvature(probe)
        wanted=np.zeros((3,4));wanted[k]=s
        assert np.max(abs(f[3]-wanted))<1e-14
        for i,j in itertools.product(range(20),repeat=2):
            actual=magnetic_hessian(base,probe,tests[i],tests[j],densities)
            discrepancy=max(discrepancy,abs(actual-densities[2]*contact[k,i,j]))
    assert discrepancy<1e-13
    neutral=np.zeros((24,3))
    for k in range(3):neutral[4*(2+k):4*(3+k),k]=s
    assert np.max(abs(contact@neutral))<1e-13
    np.save(output/'anchor_magnetic_contact3x24x24.npy',exact_contact,allow_pickle=False)
    checks['evaluated_original_anchor_contact']={
        'shape':[3,24,24], 'rank_each_axis':4,
        'exact_normalized_spectrum':spectra,
        'nonzero_entries_each_axis':[int(np.count_nonzero(a)) for a in exact_contact],
        'all_gauge_entries_vs_original_third_variation':float(discrepancy),
        'neutral_direction_annihilation':float(np.max(abs(contact@neutral))),
        'normalization':'factor angular_density * canonical_e * R4^2 not numerically selected',
        'frame':'H nonzero aligned down as a basis representative, not selected physical H'}

    # Independent exact symbolic scalar-action coefficient for a charged pair.
    a,c,p,d,eR=sp.symbols('a c p d eR',real=True)
    # B1=2a H1, B2=2c H2, B3=p eR Q_H +a*c H3/sqrt(2)
    mag2=4*a*a+4*c*c+(p*eR*sp.sqrt(2)+a*c/sp.sqrt(2))**2+(p*eR*sp.sqrt(sp.Rational(10,3)))**2
    S=-d*mag2/2
    triple=sp.diff(S,a,c,p).subs({a:0,c:0,p:0})
    assert sp.simplify(triple+d*eR)==0
    checks['exact_original_scalar_coefficient']={'d3S_dB_dA1H1_dA2H2':str(triple),
        'arbitrary_densities_or_charge_fitted':False}

    # Total source derivative with geometry/measure/test motion, not just held-source.
    uh,vh=field(130,.03),field(131,.02)
    dh=np.array([.03,-.02,.015,.011,.007]);w=1.7;wh=.06
    total=total_local_hessian_first(base=base,base_first=b,u=u,v=v,u_first=uh,v_first=vh,
        densities=densities,density_first=dh,weight=w,weight_first=wh)
    def original(s):
        return (w+s*wh)*original_hessian_by_polarization(base.plus(b,s),u.plus(uh,s),v.plus(vh,s),densities+s*dh)
    ts=[]
    for h in (.04,.02,.01,.005):
        derivative=(-original(2*h)+8*original(h)-8*original(-h)+original(-2*h))/(12*h)
        ts.append({'step':h,'absolute_difference':float(abs(derivative-total))})
    assert min(x['absolute_difference'] for x in ts)<2e-10
    checks['total_local_density_measure_and_test_derivative']={'comparisons':ts,
        'complete_outgoing_domain_claimed':False}

    # Higgs contrast: fixed electromagnetic generator versus a co-moving neutral-line chart.
    s0,x,y,kappa,charge,A=sp.symbols('s x y kappa charge A',real=True)
    # H=(x+i y, v), spatial derivative ik H_charged; photon acts on charged entry.
    sh=-(kappa-charge*s0*A)**2*(x*x+y*y)
    charged=sp.diff(sh,x,x,s0).subs({x:0,y:0,s0:0})
    assert sp.simplify(charged-4*kappa*charge*A)==0
    checks['neutral_background_vs_charged_fluctuation_scope']={
        'fixed_generator_scalar_KB':str(charged),
        'photon_first_on_background_Hcharged0':0,
        'scope':'fixed-generator local comparison; a moving Q_H(H) chart needs its cancelling map contacts; not a new Higgs restoring force'}

    from odd_even_action_check import evaluate as exact_angular_check
    checks['actual_magnetic_odd_even_angular_coefficient']=exact_angular_check()

    result={'source_revision':'70e82fd4dbe5f53ff27ae17f6aaac7a4727c1fde',
        'classification':'SOURCE_DEFINED_LOCAL_MAGNETIC_HESSIAN_INSERTION_AND_EXACT_ANCHOR_CONTACT',
        'checks':checks,'all_scoped_checks_pass':True,
        'physical_fields_evaluated':False,'retained_npz_imported':False,
        'full_quantum_photon_insertion_evaluated':False,'full_outgoing_derivative_admitted':False,
        'coupled_corrections':0,'physical_a_mu':None,'physical_g_mu':None,'total_uncertainty':None,
        'repository_modified':False,
        'NEXT_OPERAND':'Apply the three-slot original-action magnetic Hessian with the actual source/history/quotient jets and physical modes; retain odd/even angular connections and native completion.'}
    (output/'result.json').write_text(json.dumps(result,indent=2,sort_keys=True,allow_nan=False)+'\n')
    print(json.dumps(result,indent=2,sort_keys=True))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('output');run(p.parse_args().output)
