The first successful local run checked the field-to-spin application before the
joint classical wall/final maps were added to the output schema. Its log and JSON
result are preserved in the deliverable. The subsequent two complete executions
include that joint map and its balance checks. No failed scientific check was
removed or converted into a pass. Large redundant scratch arrays and duplicate
first-run NPZs are left in the working directory, not copied into the deliverable.
The final NPZ schema omits reconstructible redundant matrices; this deterministic
compact export was applied to both independent runs and is the current producer.
