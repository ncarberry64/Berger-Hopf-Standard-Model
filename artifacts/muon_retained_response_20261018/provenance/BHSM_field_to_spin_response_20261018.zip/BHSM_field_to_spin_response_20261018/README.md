# BHSM open field-to-spin connection

Evaluated on the two exported provisional histories. This package joins the saved
Higgs response and prescribed gauge-wall data to the finite-time lepton Hamiltonian,
while retaining the saved Maxwell/Higgs open boundary equations. No physical muon
magnetic moment, closed wall solution, quantum reference, or lifetime is selected.

Run:

```text
python run_connection.py --output replay_new
```

Outputs retain 166 input directions, 84 reached lepton components and 30 initial
component coordinates. The saved joint classical system uses 574 input directions.
`DERIVATION.md` states the equations, conventions, verification and limitations.
`VERIFICATION.json` records the two replay hashes and precise scopes.

The old direct magnetic response is already included in the gauge-wall part.
Do not add it a second time. The fixed-axis scalar response is not the complete
field-dependent neutral-generator derivative; its necessary residual contact is
checked separately. Unknown physical inputs have not been set to zero.

The scripts never write to GitHub or the Windows worktree. The dependencies are
unchanged copies of previous supplied source-derived implementations, not a full
repository checkout. Live integration must check the pinned conventions.
