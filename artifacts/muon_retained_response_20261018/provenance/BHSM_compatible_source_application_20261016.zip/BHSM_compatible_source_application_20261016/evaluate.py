"""Execute source projection/jet tests, not a physical collider solve."""
from __future__ import annotations
import argparse, json, math, hashlib, itertools
from pathlib import Path
import numpy as np
from scipy.linalg import expm
from compatible_source import *


def maxabs(x):return float(np.max(np.abs(x)))


def exp_linear_jet(base,h,k,hk):
    return Jet(base,base*h,base*k,base*(hk+h*k))

class ConstructedControl:
    """Finite algebra control with normalized full18 sections; not physical packets."""
    def __init__(self):
        self.g,self.w,self.q=quadrature24();self.Y=even_values(self.g)
        self.Phi=scalar_values(self.g,1)
        rng=np.random.default_rng(160465)
        z=rng.normal(size=(90,4))+1j*rng.normal(size=(90,4))
        self.C0=np.linalg.qr(z)[0]
        def anti(n,scale):
            a=rng.normal(size=(n,n))+1j*rng.normal(size=(n,n));a=a-a.conj().T
            return scale*a/np.linalg.norm(a,2)
        self.A=anti(90,.8);self.B=anti(90,.6);self.D=anti(90,.3)
        ar=rng.normal(size=(10,10));self.YA=.2*(ar-ar.T)/np.linalg.norm(ar-ar.T,2)
        br=rng.normal(size=(10,10));self.YB=.3*(br-br.T)/np.linalg.norm(br-br.T,2)
        self.d1=.1+.08*self.q[:,0];self.d2=-.05+.07*self.q[:,1];self.d12=.03*self.q[:,2]
        self.b0=np.tile([0.,0.,0.,1.],(24,1))
        self.bh=np.tile([.07,-.05,.03,.02],(24,1))
        self.bk=np.tile([-.02,.06,.01,-.04],(24,1))
        self.bhk=np.tile([.01,.015,-.02,.01],(24,1))
        self.H0=np.array([.6+.2j,.8-.1j]);self.Hh=np.array([.1-.07j,-.04+.03j]);self.Hk=np.array([.03+.02j,.05+.01j]);self.Hhk=np.array([-.01+.02j,.03-.01j])
        self.coefficients=mode_coefficients()
        self.G,self.alpha,self.vertices=retained_representation();self.pair=original_pair_algebra()
    def eval_modes(self,C):return np.einsum('pn,nas->pas',self.Phi,C.reshape(5,18,4))
    def primitives(self,h=0.,k=0.):
        C=expm(h*self.A)@expm(k*self.B)@expm(h*k*self.D)@self.C0
        # LEFT is continued independently, not conjugated at complex h/k.
        Cl=self.C0.conj().T@expm(-h*k*self.D)@expm(-k*self.B)@expm(-h*self.A)
        logd=h*self.d1+k*self.d2+h*k*self.d12
        right=self.eval_modes(C)*np.exp(-logd[:,None,None]/2)
        left=np.einsum('ina,pn->pia',Cl.reshape(4,5,18),self.Phi.conj())*np.exp(-logd[:,None,None]/2)
        time_factor=np.exp(.13*h-.09*k+.04*h*k)
        weights=self.w*np.exp(logd)*time_factor
        cauchy=self.w*np.exp(logd)
        wall=self.b0+h*self.bh+k*self.bk+h*k*self.bhk
        Y=self.Y@expm(h*self.YA)@expm(k*self.YB)
        N=np.full(24,1.4)*np.exp(.17*h-.11*k+.04*h*k)
        R=np.full(24,2.3)*np.exp(-.09*h+.14*k-.03*h*k)
        H=self.H0+h*self.Hh+k*self.Hk+h*k*self.Hhk
        Hl=self.H0.conj()+h*self.Hh.conj()+k*self.Hk.conj()+h*k*self.Hhk.conj()
        return right,left,weights,wall,Y,N,R,H,Hl,cauchy
    def jets(self):
        Cz=Jet(self.C0,self.A@self.C0,self.B@self.C0,(self.A@self.B+self.D)@self.C0)
        Cl=Jet(self.C0.conj().T,-self.C0.conj().T@self.A,-self.C0.conj().T@self.B,
               self.C0.conj().T@(self.B@self.A-self.D))
        bare_right=Jet(*(self.eval_modes(c) for c in Cz.slots()))
        bare_left=Jet(*(np.einsum('ina,pn->pia',c.reshape(4,5,18),self.Phi.conj()) for c in Cl.slots()))
        renorm=exp_linear_jet(np.ones(24),-.5*self.d1,-.5*self.d2,-.5*self.d12)
        right=einsum_jet('p,pai->pai',renorm,bare_right)
        left=einsum_jet('p,pia->pia',renorm,bare_left)
        weights=exp_linear_jet(self.w,self.d1+.13,self.d2-.09,self.d12+.04)
        wc=exp_linear_jet(self.w,self.d1,self.d2,self.d12)
        wall=Jet(self.b0,self.bh,self.bk,self.bhk)
        Y=Jet(self.Y,self.Y@self.YA,self.Y@self.YB,self.Y@self.YA@self.YB)
        N=exp_linear_jet(np.full(24,1.4),.17,-.11,.04)
        R=exp_linear_jet(np.full(24,2.3),-.09,.14,-.03)
        H=Jet(self.H0,self.Hh,self.Hk,self.Hhk)
        Hl=Jet(self.H0.conj(),self.Hh.conj(),self.Hk.conj(),self.Hhk.conj())
        return dict(left_packets=left,right_packets=right,weights=weights,wall_values=wall,harmonics=Y,
                    lapse=N,radius=R,base_vertices=self.vertices,pair_mean=constant(self.pair['mean'])),wc,H,Hl
    def direct(self,h,k):
        R,L,w,b,Y,N,rad,H,Hl,wc=self.primitives(h,k)
        gamma=np.broadcast_to(self.vertices,(24,)+self.vertices.shape).copy()
        gamma=gamma.astype(complex);gamma[:,2:]*=(N/rad)[:,None,None,None,None]
        # Independent finite Fock scalar-action evaluation of all current components.
        compressed=np.einsum('pia,pfcab,pbj->pfcij',L,gamma,R,optimize=True)
        current=np.empty((24,5,4),complex)
        for p,f,c in np.ndindex(24,5,4):
            operator=np.einsum('ij,ijab->ab',compressed[p,f,c],self.pair['B'])
            current[p,f,c]=np.trace(self.pair['rho']@operator)
        rows=np.zeros((4,5,4,10),complex)
        for p in range(24):
            rows+=w[p]*b[p,:,None,None,None]*current[p,None,:,:,None]*Y[p,None,None,None,:]
        P=np.outer(H,Hl)/(Hl@H)
        sigma=np.array([[[0,1],[1,0]],[[0,-1j],[1j,0]],[[1,0],[0,-1]]],complex)
        s=np.r_[-np.sqrt(2)*np.einsum('aij,ji->a',sigma,P),np.sqrt(10/3)]
        S=make_seed_inclusion(constant(s),self.coefficients).value
        return rows.ravel(),S.T@rows.ravel()


def first_difference(fn,step,axis):
    vals=[]
    for u in [-2,-1,1,2]:vals.append(fn(u*step,0) if axis==0 else fn(0,u*step))
    return (vals[0]-8*vals[1]+8*vals[2]-vals[3])/(12*step)


def mixed_difference(fn,step):
    shifts=[-2,-1,1,2];coef=[1,-8,8,-1]
    total=0
    for a,ca in zip(shifts,coef):
        for b,cb in zip(shifts,coef):total=total+ca*cb*fn(a*step,b*step)
    return total/(144*step**2)


def run(out):
    out=Path(out);out.mkdir(parents=True,exist_ok=False)
    tests={};tables={};a=even_multiplication(1);T=a['tensor']
    g24,w24,q24=quadrature24();g6,w6,q6=haar_rule(6);g8,w8,q8=haar_rule(8)
    def projected(g,w):return np.einsum('p,pt,ph,ps->hts',w,scalar_values(g,3).conj(),even_values(g),scalar_values(g,1),optimize=True)
    T24,T6,T8=(projected(g,w)for g,w in ((g24,w24),(g6,w6),(g8,w8)))
    err24=maxabs(T24-T);arg=np.unravel_index(np.argmax(abs(T24-T)),T.shape)
    tests['independent_harmonic_product_application']={'passed':max(maxabs(T6-T),maxabs(T8-T))<2e-12,
        'Gaunt_vs_Haar_degree6':maxabs(T6-T),'Gaunt_vs_Haar_degree8':maxabs(T8-T),
        'source_tensor_shape':list(T.shape),'nonzero_entries':int(np.count_nonzero(abs(T)>1e-14)),
        'input_scalar_bands':[0,1],'required_output_scalar_bands':[0,1,2,3]}
    tests['degree5_rule_rejected_for_new_source']={'passed':err24>.1,'max_error':err24,
        'witness':{'real_source_label':a['source_labels'][arg[0]],'output':a['output_labels'][arg[1]],'input':a['input_labels'][arg[2]]},
        'scope':'new degree-six matrix element; not an error in earlier degree-four Maxwell applications'}
    # Exact witness: z1=a, x=|a|^2; the Haar-balanced polynomial is x^2(3x-2).
    import sympy as sp
    x=sp.symbols('x',real=True)
    exact_haar=-2*sp.I*sp.sqrt(3)*sp.integrate((3*x-2)*x*x,(x,0,1))
    exact_small=sp.Rational(16,24)*sp.I*sp.sqrt(3)/2
    exact_defect=sp.simplify(exact_small-exact_haar)
    tests['exact_quadrature_alias_certificate']={'passed':sp.simplify(exact_defect-sp.I*sp.sqrt(3)/2)==0,
        'exact_Haar':str(exact_haar),'exact_24point':str(exact_small),'exact_difference':str(exact_defect),
        'witness_polynomial':'-2*i*sqrt(3)*(3*x-2)*(x^2-z1^4)'}
    G,alpha,vertices=retained_representation()
    tests['action_representation_and_Gauss_sign']={'passed':maxabs(vertices-vertices.conj().swapaxes(-1,-2))<1e-13,
        'Hermiticity':maxabs(vertices-vertices.conj().swapaxes(-1,-2)),
        'Ar_direct_intrinsic_vertex':maxabs(vertices[1]),'At_vertex_equation':'+i G_c; lapse cancels; not Hamiltonian -i G_c'}
    pair=original_pair_algebra()
    tests['exact_pair_not_quasifree']={'passed':maxabs(pair['mean']-np.diag([.5,.5,-.5,-.5]))<1e-15,
         'first_mean_diagonal':np.diag(pair['mean']).real.tolist(),
         'ordered_pair_product_tensor_shape':list(pair['second'].shape)}
    # Odd field components may have even bilinear currents: evaluate the exact angular map.
    old=np.concatenate((scalar_values(g8,1)[:,1:],scalar_values(g8,3)[:,14:]),axis=1)
    odd_overlap=np.einsum('p,ph,pk->hk',w8,even_values(g8),old)
    product_witness=np.einsum('p,ph,p,p->h',w8,even_values(g8),2*q8[:,0],2*q8[:,0])
    tests['odd_source_vs_even_bilinear_distinction']={'passed':maxabs(odd_overlap)<2e-12 and maxabs(product_witness[1:])>.1,
         'odd_single_field_overlap':maxabs(odd_overlap),'odd_times_odd_current_even_projection_max':maxabs(product_witness[1:])}
    C=mode_coefficients();mode_kernel=np.einsum('hai,hts->aits',C,T)
    tests['right_frame_source_reconstruction']={'passed':maxabs(np.einsum('ph,hai->pai',even_values(g24),C)-right_mode_values(q24))<2e-12,
         'reconstruction_error':maxabs(np.einsum('ph,hai->pai',even_values(g24),C)-right_mode_values(q24))}
    tail_ids=np.array([v[0]==3 for v in a['output_labels']]);output_tail=np.repeat(tail_ids,18)
    tails=[]
    for m in range(4):
        V=sum(np.kron(mode_kernel[m,j],vertices[j+2,3]) for j in range(3))
        tail=V[output_tail]
        tails.append({'mode':m,'matrix_shape':list(V.shape),'whole_norm':float(np.linalg.norm(V)),
                      'n3_tail_norm':float(np.linalg.norm(tail)),
                      'missing_two_insertion_return_frobenius':float(np.linalg.norm(tail.conj().T@tail))})
    tests['retained_n3_source_return']={'passed':tails[2]['n3_tail_norm']>1 and tails[3]['n3_tail_norm']>1,
                                      'hypercharge_vertex_coordinate_diagnostics':tails,
                                      'not_physical_charge_or_Pauli_numbers':True}
    control=ConstructedControl();args,wc,H,Hl=control.jets()
    load=wall_source_jet(**args)['value_load'];axis=higgs_charge_jet(H,Hl)
    seed=seed_pullback(make_seed_inclusion(axis,control.coefficients),load)
    direct=control.direct(0.,0.)
    tests['direct_full_Fock_scalar_action']={'passed':max(maxabs(load.value-direct[0]),maxabs(seed.value-direct[1]))<2e-12,
        'original_800_value_error':maxabs(load.value-direct[0]),'seed16_value_error':maxabs(seed.value-direct[1])}
    tests['complete_Cauchy_Gram_jet_control']=check_cauchy_jet(args['left_packets'],args['right_packets'],wc)
    tests['complete_Cauchy_Gram_jet_control']['passed']=tests['complete_Cauchy_Gram_jet_control']['passes_at_tested_scope']
    # Original zero wall traces and absent radial material pullback give exact sparse support.
    base_load=load.value.reshape(4,5,4,10)
    tests['wall_incidence_sparse_support']={'passed':maxabs(base_load[:3])<1e-14 and maxabs(base_load[:,1])<1e-14,
        'old_basis_wall_values':[0,0,0,1], 'potentially_nonzero_value_rows':160,
        'direct_connection_rate_rows':0,'scope':'direct intrinsic lepton action, fixed material wall; not all interface/native sources'}
    # Numerical derivatives use only the independently recomputed finite Fock action.
    fd_cache={}
    def fn(h,k):
        key=(float(h),float(k))
        if key not in fd_cache:fd_cache[key]=np.concatenate(control.direct(h,k))
        return fd_cache[key]
    exact_h=np.r_[load.h,seed.h];exact_k=np.r_[load.k,seed.k];exact_hk=np.r_[load.hk,seed.hk]
    steps=[.004,.002,.001]
    table=[]
    for step in steps:
        dh=first_difference(fn,step,0);dk=first_difference(fn,step,1);dm=mixed_difference(fn,step)
        table.append({'step':step,'first_h_error':maxabs(dh-exact_h),'first_k_error':maxabs(dk-exact_k),'mixed_hk_error':maxabs(dm-exact_hk)})
    tests['all_primitive_source_derivatives']={'passed':min(max(v['first_h_error'],v['first_k_error'])for v in table)<2e-10 and min(v['mixed_hk_error']for v in table)<2e-10,
        'table':table,'first_control_threshold':2e-10,'mixed_control_threshold':2e-10,
        'not_complete_physical_outgoing_derivative':True,
        'varied':['right packet','independent left packet','Cauchy normalization','source measure/clock','wall trace','angular test frame','lapse','radius','Higgs selected source inclusion']}
    # Omitting moving-test contact produces a finite, independently detectable error.
    omitted=dict(args);omitted['wall_values']=constant(args['wall_values'].value)
    bad=wall_source_jet(**omitted)['value_load']
    tests['missing_trace_derivative_detected']={'passed':maxabs(load.h-bad.h)>1e-5,'omitted_contact_error':maxabs(load.h-bad.h),
        'scope':'constructed control; not identification of the historical physical discrepancy'}
    # Constant lapse path alters spatial load but not temporal action load.
    only=dict(args)
    for key,val in only.items():
        if isinstance(val,Jet):only[key]=constant(val.value)
    only['lapse']=Jet(only['lapse'].value,np.ones(24),np.zeros(24),np.zeros(24))
    lapse_only=wall_source_jet(**only)['value_load'].h.reshape(4,5,4,10)
    tests['lapse_cancellation_not_double_counted']={'passed':maxabs(lapse_only[:,0])<1e-14 and maxabs(lapse_only[:,2:])>1e-5,
        'At_lapse_derivative':maxabs(lapse_only[:,0]),'spatial_lapse_derivative':maxabs(lapse_only[:,2:])}
    # Derivative admission must not follow from these control passes.
    missing=require_complete_physical_operands({})
    tests['physical_admission_not_invented']={'passed':not missing['complete_physical_source_application'],**missing}
    result={'source_revision':SOURCE_REVISION,'scope':'EVALUATED_EVEN_SOURCE_MULTIPLICATION_AND_DIRECT_LEPTON_WALL_CURRENT_JETS; NO_PHYSICAL_COLLIDER_ADMISSION',
            'tests':tests,'passed':all(v.get('passed',False)for v in tests.values()),
            'physical_packet_sections_evaluated':False,'complete_physical_outgoing_derivative':False,
            'coupled_corrections':0,'fresh_Maxwell_or_226_state':False,'a_mu':None,'g_mu':None,
            'old_Maxwell_arrays_recomputed_or_modified':False,'old_local_coefficient_refinement_performed':False,
            'actual_missing_physical_inputs':missing['unresolved']}
    # Save compact reusable numeric tensor arrays, deterministic uncompressed npy.
    for name,value in {'even_Gaunt10x30x5':T,'mode_coefficients10x4x3':C,'right_mode_source4x3x30x5':mode_kernel,
                       'action_vertex5x4x18x18':vertices,'pair_mean4x4':pair['mean'],'pair_ordered_second4x4x4x4':pair['second'],
                       'control_load800':load.value,'control_source_derivative_h800':load.h,'control_source_derivative_k800':load.k,
                       'control_source_mixed_hk800':load.hk}.items():
        np.save(out/(name+'.npy'),value,allow_pickle=False)
    (out/'result.json').write_text(json.dumps(result,indent=2,sort_keys=True,allow_nan=False)+'\n')
    print(json.dumps(result,indent=2))
    if not result['passed']:raise SystemExit('One or more scoped checks failed; retain evidence.')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('output');args=p.parse_args();run(args.output)
