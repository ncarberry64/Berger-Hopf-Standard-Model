# Integration boundary and reproduction

## Reproduce only the new source calculation

Use Python with NumPy, SciPy and SymPy. From this folder:

```powershell
$env:OPENBLAS_NUM_THREADS = '1'
$env:OMP_NUM_THREADS = '1'
& C:\Python314\python.exe .\evaluate.py .\local_replay_1
& C:\Python314\python.exe .\evaluate.py .\local_replay_2
```

The output directory must not already exist. Do not run an old Maxwell/radial
producer merely to reproduce these source maps. The test code uses explicitly
constructed finite sections; its replay is not physical collider admission.

## Reuse original owners instead of diverging representations

At the actual current BHSM revision, verify matrix/label equality against:

- `muon_intrinsic_scalar_discretization` scalar labels/transform/values;
- `muon_local_source_jet._gaunt` or its exact CG definition;
- `electromagnetic_carrier_original_maxwell.even_angular_space` and
  `electromagnetic_inclusion`;
- `muon_native_product_factor_graph.lepton_unit_trace_gauge_representation`;
- `muon_native_dirac_hamiltonian.lepton_current_hilbert_representation`;
- the exact pair Fock density and `bhsm_collider_incoming_field_current`.

The standalone formulas use the published conventions, but the repository's
original owner functions should remain authoritative when integrating. Verify
the scalar-major/full18-minor ordering rather than assuming a shape match.

## Next actual source operation

1. Apply the supplied exact even Gaunt/source kernels to the actual incoming
   coefficient sections, retaining every reached band; for input n<=1 the
   output includes n=3. The adopted Gaussian is not automatically band-limited.
2. Bind the complete physical Cauchy Gram and its jets. Do not insert free
   spinors, artificial normalized test coefficients, or an inherited vacuum.
3. Construct `wall_source_jet` inputs from actual left/right packet jets,
   original action weights and normalization, material wall traces, even
   harmonics, and the source-defined lapse/radius maps. For a more general
   coframe/domain derive the vertex map rather than reusing an invalid formula.
4. Compare the resulting primitive current with the original source consumer
   and its independent action derivative on the same state. No entry may be
   normalized with an arbitrary Maxwell embedding index or fitted coupling.
5. Compose the actual moving interface/native/reference source and domain
   derivatives. Only then add the new source load to the retained original
   Maxwell/geometry blocks and apply the compatible retarded solve.

The routine's zeros for direct Ar and gauge-rate vertices concern only that
intrinsic lepton term in its material chart. They do not zero other radial,
canonical, corner, native, inherited, or terminal contributions.

## What not to redo

The 24-point rule remains valid for the old applications at their proved
polynomial degree. The new demonstrated failure is for a degree-six source
matrix element. Exact CG multiplication or an appropriate rule resolves that
finite product; increasing the old radial orders is unrelated to this error.

Do not reuse the old odd eight-source return. Do not project reached n=3 back
into input n=0,1 before a two-insertion calculation. Do not call identity-weighted
V_tail^dagger V_tail the native heat return.

## Physical admission

These tests do not provide normalized physical packets, a stationary background,
the full graded operator, the inherited quantum state, a completed terminal
response, or a correction. The 2e-10 physical guard is unchanged. Validate the
complete outgoing derivative on the true physical path, then run fresh original
Maxwell and 226-row before/after tests. Do not promote the synthetic control
residuals or historical provisional values into those tests.

Preserve current work and review changes before committing. No remote write was
made in generating this package.
