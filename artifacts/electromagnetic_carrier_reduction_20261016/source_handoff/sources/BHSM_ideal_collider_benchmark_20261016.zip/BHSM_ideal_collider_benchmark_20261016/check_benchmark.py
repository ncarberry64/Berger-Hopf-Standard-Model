#!/usr/bin/env python3
"""Validate this preparation specification and reference kinematics only.

This script does NOT construct a BHSM spinor section, solve constraints,
compute a terminal return, or predict a magnetic moment. Standard library only.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
from pathlib import Path
from typing import Callable


def simpson(fun: Callable[[float], float], a: float, b: float, n: int) -> float:
    if n <= 0 or n % 2:
        raise ValueError("n must be a positive even integer")
    h = (b-a)/n
    terms = [fun(a), fun(b)]
    terms.extend((4.0 if i % 2 else 2.0)*fun(a+i*h) for i in range(1, n))
    return h*math.fsum(terms)/3.0


def evaluate(path: Path) -> dict:
    raw = path.read_bytes()
    data = json.loads(raw)
    cal = data['calibration_and_units']
    E = float(data['beam_energy']['central_total_energy_per_particle_MeV'])
    me = float(cal['electron_mass_energy_MeV']['value'])
    mmu = float(cal['muon_mass_energy_MeV']['value'])
    c = float(cal['c_m_per_s']['value'])
    h = float(cal['h_J_s']['value'])
    charge = float(cal['e_C']['value'])
    fm = float(cal['fm_m']['value'])
    width = float(data['packets']['reference_probability_rms_width_each_axis_fm'][0])
    d = float(data['frame_and_geometry']['initial_center_separation_fm'])
    if not all(math.isfinite(x) and x > 0 for x in (E,me,mmu,c,h,charge,fm,width,d)):
        raise ValueError('positive finite dimensional input required')
    if E <= me:
        raise ValueError('central incoming energy must exceed electron rest energy')
    hbar_c = (h/(2*math.pi))*c/(charge*1e6*fm)
    k0 = math.sqrt((E-me)*(E+me))
    sigma_k = hbar_c/(2*width)
    beta = k0/E
    nominal_encounter_s = d*fm/(2*beta*c)
    phi = lambda x: math.exp(-0.5*x*x)/math.sqrt(2*math.pi)
    norms = [simpson(phi, -12, 12, n) for n in (1200,2400)]
    moments = [simpson(lambda x: x*x*phi(x), -12, 12, n) for n in (1200,2400)]
    spin = [[float(x) for x in row] for row in data['spin_state']['rho_spin']]
    if len(spin) != 4 or any(len(row) != 4 for row in spin):
        raise ValueError('rho_spin must be 4x4')
    spin_trace = math.fsum(spin[i][i] for i in range(4))
    unpolarized_error = max(abs(spin[i][j]-(0.25 if i == j else 0.0)) for i in range(4) for j in range(4))
    centers = data['frame_and_geometry']['initial_packet_centers_fm']
    xe = [float(x) for x in centers['electron']]
    xp = [float(x) for x in centers['positron']]
    tests = {
        'above_reference_muon_pair_threshold': 2*E > 2*mmu,
        'on_shell_reference_energy': abs(math.hypot(k0,me)-E) < 1e-10,
        'centers_head_on_and_mirror_symmetric': all(abs(xe[i]+xp[i]) < 1e-12 for i in range(3)) and xe[:2] == [0,0],
        'declared_separation_agrees': abs((xp[2]-xe[2])-d) < 1e-10,
        'spin_density_trace_one': abs(spin_trace-1) < 1e-15,
        'spin_density_exact_unpolarized_mixture': unpolarized_error == 0,
        'scalar_reference_normalization': max(abs(x-1) for x in norms) < 1e-12,
        'scalar_reference_variance': max(abs(x-1) for x in moments) < 1e-12,
        'reference_minimum_uncertainty_identity': abs(width*sigma_k-hbar_c/2) < 1e-12,
        'physical_fields_not_claimed': data['execution_status']['physical_Cauchy_fields_evaluated'] is False,
        'no_final_prediction_claim': data['execution_status']['muon_prediction_complete'] is False,
        'inherited_sea_not_removed': data['incoming_environment']['shared_sea_removed'] is False,
    }
    if not all(tests.values()):
        raise ValueError('Reference control failed: '+', '.join(k for k,v in tests.items() if not v))
    return {
        'preparation_id': data['preparation_id'],
        'classification': 'SPECIFICATION_AND_LOCAL_FREE_GAUSSIAN_KINEMATIC_CONTROLS_ONLY',
        'input_sha256': hashlib.sha256(raw).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'reference_derived_values': {
            'hbar_c_MeV_fm': hbar_c,
            'central_k_pc_MeV': k0,
            'central_beta_e': beta,
            'central_pair_energy_MeV': 2*E,
            'reference_muon_pair_threshold_MeV': 2*mmu,
            'sigma_pc_MeV_each_axis': sigma_k,
            'longitudinal_relative_momentum_spread': sigma_k/k0,
            'nominal_free_encounter_delay_s': nominal_encounter_s,
            'initial_center_separation_in_widths': d/width,
            'single_packet_scalar_density_at_origin_over_peak': math.exp(-0.5*(d/(2*width))**2),
            'spin_trace': spin_trace,
            'spin_eigenvalues': [0.25]*4
        },
        'scalar_quadrature_controls': {'bounds_in_sigma': [-12,12], 'simpson_subintervals': [1200,2400], 'normalizations': norms, 'variances_in_sigma_squared': moments},
        'checks': tests,
        'scope_exclusions': [
            'This is not an action-evaluated BHSM packet, Cauchy field or spatial pole.',
            'Free Gaussian widths and uncertainty equality need not hold exactly after a curved-action positive-frequency projection; measure its discrepancy.',
            'No original Maxwell or 226 matching residual was recomputed.',
            'No magnetic-moment target or numerical result was used.',
            'No initial or terminal physical field solve was executed.'
        ],
        'physical_problem_solved': False
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('manifest', nargs='?', type=Path, default=Path(__file__).with_name('BHSM_IDEAL_COLLIDER_PREPARATION_V1.json'))
    parser.add_argument('--output', type=Path, default=Path(__file__).with_name('reference_checks.json'))
    args = parser.parse_args()
    try:
        result = evaluate(args.manifest)
        args.output.parent.mkdir(parents=True, exist_ok=True)
        text = json.dumps(result, indent=2, sort_keys=True, allow_nan=False)+'\n'
        temp = args.output.with_suffix(args.output.suffix+'.tmp')
        temp.write_text(text, encoding='utf-8')
        temp.replace(args.output)
    except (OSError,ValueError,KeyError,TypeError) as exc:
        parser.exit(2, f'Benchmark check failed: {exc}\n')
    print(f"{len(result['checks'])} reference/specification checks passed. No physical field solve performed.")
    print(args.output)

if __name__ == '__main__':
    main()
