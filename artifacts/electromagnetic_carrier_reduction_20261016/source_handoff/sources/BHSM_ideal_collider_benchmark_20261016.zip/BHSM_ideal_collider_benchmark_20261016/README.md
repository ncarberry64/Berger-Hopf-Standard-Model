# Authorized ideal collider preparation — BHSM muon

**Preparation ID:** `BHSM_EE_MUMU_IDEAL_PREPARATION_V1`  
**Date:** 16 October 2026  
**Status:** External benchmark choices and analytic reference envelopes specified.
Physical BHSM packet sections, initial fields, terminal response and magnetic
moment are **not** computed by this package.

## Selected design

| Item | Specification |
|---|---|
| Incoming hard state | One electron and one positron |
| Production channel of interest | e− e+ → μ− μ+, without deleting other coupled channels |
| Central total energy | 500 MeV each; nominal central pair energy 1 GeV |
| Centers and directions | Electron at X3 = −1000 fm moving +X3; positron at +1000 fm moving −X3 |
| Transverse impact parameter | Zero |
| Scalar packet reference width | 100 fm probability RMS in each spatial direction |
| Shape and coherence | Coherent Gaussian spectral envelope; zero added chirp |
| Spin | Exact independent unpolarized pair mixture I4/4 |
| Extra incoming radiation | None beyond the inherited reference and required dressing |
| Applied production field | No additional machine electric/magnetic field in the local interaction region |
| Magnetic measurement | Separate infinitesimal weak-field response of the formed muon |

These are theoretical design choices made under Norman's authorization.
They are not a measured accelerator beam configuration and were not chosen
by comparing with the measured muon anomaly. A packet width describes the
incoming probability envelope, not a particle's intrinsic size.

## Analytic packet specification

In the local reference momentum representation, use k = p c in MeV, with

    g_a(k) = (2 pi sigma_k^2)^(-3/4)
             exp[-|k-k_a|^2/(4 sigma_k^2)
                 - i k dot X_a/(hbar c)],
    sigma_k = hbar c/(2 sigma_x),
    sigma_x = 100 fm.

This scalar amplitude is normalized with d^3 k and specifies a coherent
packet envelope. The linear phase fixes the stated center. There is no
extra quadratic phase. In an invariant mass-shell normalization the measure
and coefficients must be converted consistently.

This does **not** assert that free plane waves or the scalar envelope are
physical BHSM spinor sections. Construct the particle/antiparticle sections
in the actual mode spaces, normalize in the physical Cauchy Gram, and report
any displacement of packet moments and the projection error. Enforce the
500 MeV central energy on the actual incoming dispersion. Do not delete
inherited connections to force a free mass shell. The exact Fock pair-spin
structure must be preserved together with the required gauge dressing.

Using CODATA reference masses only for kinematic checks gives:

    central p c = 499.9997388800042 MeV,
    sigma_(p c) = 0.9866349022965124 MeV per axis,
    relative longitudinal momentum spread = 0.0019732708351,
    nominal free center encounter time = 3.33564269399e-21 s,
    reference two-muon threshold = 211.316751 MeV.

The 1 GeV central value is not an exact invariant energy for every component
of a wave packet. Its energy distribution and actual collision time follow
from the constructed state and dynamics. The free encounter time is neither
a physical decay lifetime nor a BHSM birth/cutoff clock.

## What “no extra incoming radiation” means

Keep the existing inherited geometry, Higgs/background state and shared
sea. Add no independent incoming coherent radiation, thermal population or
squeezed population over that reference. Calculate the beam-associated fields,
constraint sources, momenta and their causal history. In particular,
no-extra-radiation does not set electric fields or longitudinal constraints
to zero and does not remove vacuum correlations or required charged-state
dressing. It does not turn a retarded response kernel into a solved initial
state. The inherited quantum reference must still be identified by its actual
same-action prescription and provenance.

The regular-cap coefficient c = q(0) is a central Gauss-flux constant in the
current binding. Its vanishing under the stated regularity assumptions does
not set sourced q(rho), exterior fields or a spectral cutoff to zero.

## Physical implementation

The existing source binding identifies these consumers:

- `construct_action_packet_sections`
- `validate_action_packet_Cauchy_Gram`
- `apply_incoming_packet_current`
- `original_material_Gauss_source`

in `audits/bhsm_collider_incoming_field_current.py`. Actual same-state Higgs,
stress, angular and interface sources, collision incidence and terminal
response still have to be evaluated. See `CODEX_CONTINUE.txt` for the focused
continuation. No existing GitHub or local Windows files were modified here.

A physical result requires the same-state pole/residue, charge and magnetic
normalization. The production amplitude at timelike s is not F2(0). Preserve
possible preparation dependence until an isolated-state limit is established.

## Checks actually executed

`check_benchmark.py` uses only the Python standard library. It checks the
specification, spin-mixture normalization, reference mass-shell/threshold,
Gaussian normalization/variance and width-momentum relation. Twelve
reference/specification checks pass. Two independent executions return
byte-identical JSON. These are input and reference-kinematics controls, not
field, radial-convergence, terminal, all-226-row or magnetic-moment checks.

Run after extraction:

```powershell
& C:\Python314\python.exe .\check_benchmark.py
```

The default manifest and output paths are relative to the script, not the
shell's current directory. Generated files are written atomically. Verify
`SHA256SUMS.txt` to check this package's files.

## Provenance

The inspected PR #465 head was
`823d070ac445989169a6bf63a2ef044035f2602f`; newer work must be preserved.
The JSON records the exact prior binding blob and inherited pair-state hashes.
This is not a claim that the referenced NPZ or the whole repository was replayed.

- BHSM preparation binding (source for existing conventions and consumers):
  https://github.com/ncarberry64/Berger-Hopf-Standard-Model/blob/823d070ac445989169a6bf63a2ef044035f2602f/docs/muon_collider_preparation_binding_20261016.md
- NIST CODATA 2022 (electron/muon mass-energy values and SI constants, used
  here only for reference kinematics):
  https://physics.nist.gov/cuu/Constants/Table/allascii.txt
- Hirai and Sugishita, *Dressed states from gauge invariance* (QED context
  for retaining gauge constraints/dressing, not a BHSM construction):
  https://arxiv.org/abs/1901.09935

Only the listed masses and SI conversion constants are copied into the
manifest. No measured magnetic anomaly or magnetic moment is included as an
input. No total physical uncertainty, native remainder, a_mu or g_mu was
computed by this package.
