# Reproduction

Run from this extracted folder with Python 3.10 or newer and installed `numpy`
and `sympy`:

```powershell
python .\check_carrier_reduction.py --output .\replay_1.json
python .\check_carrier_reduction.py --output .\replay_2.json
(Get-FileHash .\replay_1.json).Hash -eq (Get-FileHash .\replay_2.json).Hash
```

The script uses no network and changes no repository. Inputs used only for
finite controls are explicitly labeled and are not physical BHSM coefficients.

`DERIVATION.md` gives the assumptions, exact equations and remaining limits.
`run_1.json` and `run_2.json` are the executed result files supplied with this
package. `verification.json` records the byte comparison and package hashes.

The key distinction is an exact physical Maxwell mode construction on a fixed
round sphere versus an unproved interacting BHSM reduction. The full-field
normal equations and nonlinear coordinate contacts must not be dropped.

No physical muon prediction is included.
