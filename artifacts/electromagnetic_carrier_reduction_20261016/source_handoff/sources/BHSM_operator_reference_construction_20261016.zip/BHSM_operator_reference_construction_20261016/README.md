# Operator/domain/reference construction — partial resolution

This package contains new symbolic derivations, an explicit conditional
incoming-reference prescription, and independently executed finite controls.
It does **not** supply the full physical BHSM microscopic operator, actual
inherited sea, or muon magnetic moment.

Read `DERIVATION.md` for the domain theorem, scalar factor/remainder,
chirality-versus-statistics distinction, volume/complement reduction, reference
prescription and complete-background sensitivity formula. `results_run_1.json`
and `results_run_2.json` are byte-identical.

Reproduction (from this directory):

```text
python verify_constructions.py --output results_local.json
```

Dependencies: Python 3.10+, NumPy, SciPy and SymPy. Exact versions used are in
the results. Arithmetic roundoff can differ on other versions or platforms.
No internet, Git operations, API credentials, or BHSM worktree is needed to
run these explicitly constructed controls.

The finite matrices are synthetic algorithm controls. The scalar identities
use the retained symbolic density. The in-vacuum premise is a **proposed
additional physical boundary prescription**, not a recovered BHSM selection
rule. Nothing in this package sets the unresolved native remainder to zero,
closes Gate 7, changes the 2e-10 physical guard, or fits the measured anomaly.

Repository anchor: b6cb15f5ab6f6b44057f13895c5fd498ce928d83. Repository and
Windows worktree were not modified.
