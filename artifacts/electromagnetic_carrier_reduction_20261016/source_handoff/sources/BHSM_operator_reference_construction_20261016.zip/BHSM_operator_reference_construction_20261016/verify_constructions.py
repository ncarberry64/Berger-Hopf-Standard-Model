#!/usr/bin/env python3
"""Independent symbolic/finite checks, NOT a physical BHSM field/heat solve.

All finite matrices below are explicitly constructed controls. The scalar
identities use the polynomial density in the pinned BHSM action symbolically.
No measured magnetic moment, physical covariance or new action coefficient is
used or selected. Reproduce with Python 3.10+; numpy, scipy, sympy required.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import scipy
from scipy.linalg import eigh, expm, solve_sylvester
from scipy.integrate import solve_ivp
import sympy as sp

PIN = 'b6cb15f5ab6f6b44057f13895c5fd498ce928d83'


def require(condition: bool, explanation: str) -> None:
    if not condition:
        raise AssertionError(explanation)


def nrm(a: np.ndarray) -> float:
    return float(np.linalg.norm(a, ord='fro'))


def positive_projector_jet(h: np.ndarray, dh: np.ndarray,
                           gap_tolerance: float = 1e-10):
    """Positive-frequency projector and derivative for a finite gapped h.

    This implements a candidate reference boundary prescription, NOT a
    proof that an actual BHSM incoming Hamiltonian is static or gapped.
    """
    require(h.ndim == 2 and h.shape[0] == h.shape[1], 'square h required')
    require(h.shape == dh.shape, 'h and dh shapes must agree')
    require(nrm(h-h.conj().T) < 1e-12, 'Hermitian h required')
    require(nrm(dh-dh.conj().T) < 1e-12, 'Hermitian real-parameter dh required')
    ev, v = eigh(h)
    require(float(np.min(abs(ev))) > gap_tolerance,
            'zero/gap closing requires separate state specification')
    f = (ev > 0).astype(float)
    c = (v * f) @ v.conj().T
    divided = np.zeros((len(ev), len(ev)))
    for i in range(len(ev)):
        for j in range(len(ev)):
            if f[i] != f[j]:
                divided[i,j] = (f[i]-f[j])/(ev[i]-ev[j])
    dc = v @ (divided * (v.conj().T @ dh @ v)) @ v.conj().T
    return c, dc, float(np.min(abs(ev)))


def gram_sqrt_jet(g: np.ndarray, dg: np.ndarray):
    """Positive square-root and exact Sylvester derivative for a positive Gram."""
    ev, v = eigh(g)
    require(float(np.min(ev)) > 0, 'positive Gram required')
    s = (v * np.sqrt(ev)) @ v.conj().T
    ds = solve_sylvester(s, s, dg)
    return s, ds


def symbolic_checks():
    Z, b, g, s, A, G, q, du, v, dsigma, dv, t = sp.symbols(
        'Zchi Zsigma g sigma A0 G0 q du v dsigma dv t', real=True)
    a = Z*(1+g*s*s)
    V = A*s*s/2+G*s**4/4
    ap, app, Vpp = sp.diff(a,s), sp.diff(a,s,2), sp.diff(V,s,2)
    L_t = (a.subs(s,s+t*v)*(q+t*du)**2/2
           +b*(dsigma+t*dv)**2/2+V.subs(s,s+t*v))
    second = sp.diff(L_t,t,2).subs(t,0)
    expected = a*du**2+2*ap*v*q*du+b*dv**2+(app*q*q/2+Vpp)*v*v
    factor_plus_remainder = (a*(du+ap/a*v*q)**2+b*dv**2
                             +((app/2-ap**2/a)*q*q+Vpp)*v*v)
    require(sp.simplify(second-expected)==0, 'scalar second variation')
    require(sp.simplify(second-factor_plus_remainder)==0, 'first order factor + remainder')
    W = sp.factor((app/2-ap**2/a)*q*q+Vpp)
    W_expected = A+3*G*s*s+Z*g*(1-3*g*s*s)/(1+g*s*s)*q*q
    require(sp.simplify(W-W_expected)==0, 'remainder coefficient')
    curvature = -app/(2*a*b)+ap**2/(4*a*a*b)
    curvature_expected = -g/(b*(1+g*s*s)**2)
    require(sp.simplify(curvature-curvature_expected)==0, 'field-space curvature')

    x = sp.symbols('x',real=True)
    f = sp.Function('f')(x)
    logj = sp.Function('logJ')(x)
    u = sp.exp(-logj/2)*sp.sin(f)
    Au = sp.diff(u,x)+sp.diff(logj,x)*u/2-sp.diff(f,x)*sp.cot(f)*u
    require(sp.simplify(Au)==0, 'historical normal-mode identity')
    require(sp.simplify(sp.exp(logj)*u*u-sp.sin(f)**2)==0,'normal measure cancellation')

    eps = sp.symbols('eps',real=True)
    J = sp.diag(1,-1)
    N = sp.I*eps*sp.Matrix([[1,1],[-1,-1]])
    T = sp.eye(2)+N
    require(N*N == sp.zeros(2), 'isotropic nilpotence control')
    require(sp.simplify(T.conjugate().T*J*T-J)==sp.zeros(2),'Green-preserving graph')
    require(sp.simplify(T*(sp.eye(2)-N)-sp.eye(2))==sp.zeros(2),'exact graph inverse')
    dT = sp.diff(T,eps)
    require(sp.simplify(dT.conjugate().T*J*T+T.conjugate().T*J*dT)==sp.zeros(2),
            'moving graph Green identity')
    return {
        'classification':'EXACT_SYMBOLIC_IDENTITIES_FROM_STATED_DENSITY_AND_CONDITIONAL_GRAPH',
        'scalar_second_variation_identity':True,
        'factor_plus_remainder_identity':True,
        'scalar_remainder':'A0+3*G0*sigma^2+Zchi*g*(1-3*g*sigma^2)/(1+g*sigma^2)*|grad chi|^2',
        'field_space_Gaussian_curvature':'-g/(Zsigma*(1+g*sigma^2)^2)',
        'normal_mode_identity':True,
        'normal_mode_is_not_the_full_interacting_inclusion':True,
        'graph_nilpotence_inverse_Green_and_jet_identities':True,
        'local_factor_equals_microscopic_native_D_proved':False,
    }


def finite_operator_checks():
    # Deliberately constructed complex matrix: NOT a BHSM physical operator.
    d = np.array([[1.2,0.2+0.3j,-0.1j],[0.1,1.6,0.25],[0.05j,-0.2,2.1]],complex)
    p = d.conj().T @ d
    f = np.array([0.3-0.2j,0.5,0.4j])
    u = np.linalg.solve(np.eye(3)+p,f)
    weak = np.linalg.norm((np.eye(3)+p)@u-f)
    positive = float(np.min(eigh(p,eigvals_only=True)))
    require(positive>0 and weak<1e-13,'positive closed-form finite analogue')

    # Odd self-adjoint doubling: chirality supertrace cancels nonzero spectrum.
    upper = d.conj().T@d
    lower = d@d.conj().T
    heat_upper = np.trace(expm(-0.37*upper))
    heat_lower = np.trace(expm(-0.37*lower))
    index_trace = complex(heat_upper-heat_lower)
    ordinary = float((heat_upper+heat_lower).real)
    require(abs(index_trace)<1e-13 and ordinary>0,'chirality cancellation witness')

    # Whole carrier and subspace split; heat of compression is not compressed heat.
    a = p[:2,:2]
    coupling = p[:2,2:]
    c = p[2:,2:]
    spectral = -0.4+0.2j
    schur = a-spectral*np.eye(2)-coupling@np.linalg.solve(c-spectral*np.eye(1),coupling.conj().T)
    full_resolvent = np.linalg.solve(p-spectral*np.eye(3),np.eye(3))
    resolvent_error=nrm(full_resolvent[:2,:2]-np.linalg.solve(schur,np.eye(2)))
    heat_compression_error=nrm(expm(-0.37*p)[:2,:2]-expm(-0.37*a))
    require(resolvent_error<1e-13 and heat_compression_error>1e-5,'Schur vs naive heat compression')

    # Moving positive Gram: test noncommuting square-root derivative.
    gram=np.array([[2.0,0.3+0.1j],[0.3-0.1j,1.2]],complex)
    dgram=np.array([[0.2,0.07-0.03j],[0.07+0.03j,-0.1]],complex)
    root,droot=gram_sqrt_jet(gram,dgram)
    sylvester_error=nrm(root@droot+droot@root-dgram)
    step=1e-5
    rp,_=gram_sqrt_jet(gram+step*dgram,dgram)
    rm,_=gram_sqrt_jet(gram-step*dgram,dgram)
    root_jet_error=nrm((rp-rm)/(2*step)-droot)
    require(sylvester_error<1e-13 and root_jet_error<1e-9,'moving Gram derivative')

    return {'classification':'CONSTRUCTED_FINITE_CONTROLS_NOT_PHYSICAL_BHSM_OPERANDS',
            'positive_factor_min_eigenvalue':positive,
            'weak_resolvent_residual':float(weak),
            'chirality_heat_supertrace_abs':float(abs(index_trace)),
            'ungraded_doubled_heat_trace':ordinary,
            'compressed_resolvent_Schur_error':resolvent_error,
            'incorrect_heat_of_compression_error':heat_compression_error,
            'Gram_sqrt_Sylvester_error':sylvester_error,
            'Gram_sqrt_independent_derivative_error':root_jet_error}


def bdg_h(theta: float,t: float):
    """Two-mode self-dual, time-dependent finite Hamiltonian control."""
    a=np.array([[1.2,0.1],[0.1,2.0]],complex)
    skew=np.array([[0.0,1.0],[-1.0,0.0]],complex)
    beta=theta+0.35*np.exp(t)
    off=beta*skew
    h=np.block([[a,off],[off.conj().T,-a.T]])
    dh=np.block([[np.zeros((2,2)),skew],[skew.conj().T,np.zeros((2,2))]])
    return h,dh


def reference_control(theta: float,start: float):
    # Incoming asymptotic h_-; exp(t) vanishes in the past.
    hminus,dh=bdg_h(theta,-800.0)
    c,dc,gap=positive_projector_jet(hminus,dh)
    initial=np.concatenate([np.eye(4,dtype=complex).ravel(),np.zeros((4,4),complex).ravel()])
    def ode(t,y):
        U=y[:16].reshape(4,4); dU=y[16:].reshape(4,4)
        h,dht=bdg_h(theta,t)
        return np.concatenate([(-1j*h@U).ravel(),(-1j*(h@dU+dht@U)).ravel()])
    result=solve_ivp(ode,(start,0.0),initial,method='DOP853',rtol=2e-12,atol=2e-14)
    require(result.success,'unitary and source-jet control integration failed')
    U=result.y[:16,-1].reshape(4,4)
    dU=result.y[16:,-1].reshape(4,4)
    C=U@c@U.conj().T
    dC=dU@c@U.conj().T+U@dc@U.conj().T+U@c@dU.conj().T
    return C,dC,U,c,gap


def state_checks():
    theta=0.17
    swap=np.block([[np.zeros((2,2)),np.eye(2)],[np.eye(2),np.zeros((2,2))]])
    h,dh=bdg_h(theta,0.0)
    require(nrm(swap@h.conj()@swap+h)<1e-14,'self-dual Hamiltonian')
    C,dC,U,c,gap=reference_control(theta,-10.0)
    unitary_error=nrm(U.conj().T@U-np.eye(4))
    projector_error=nrm(C@C-C)
    car_error=nrm(C+swap@C.conj()@swap-np.eye(4))
    car_jet_error=nrm(dC+swap@dC.conj()@swap)
    require(max(unitary_error,projector_error,car_error,car_jet_error)<2e-10,
            'finite reference covariance algebra')
    steps=[2e-3,1e-3,5e-4]
    derivative_errors=[]
    for hstep in steps:
        Cp,*_=reference_control(theta+hstep,-10.0)
        Cm,*_=reference_control(theta-hstep,-10.0)
        derivative_errors.append(nrm((Cp-Cm)/(2*hstep)-dC))
    require(derivative_errors[-1]<derivative_errors[0]/8,'central-difference convergence')
    require(derivative_errors[-1]<1e-6,'independent reference derivative check')
    past=[]
    arrays=[]
    for start in [-6.,-8.,-10.,-12.]:
        cc,*_=reference_control(theta,start)
        arrays.append(cc)
        past.append({'start':start, 'analytic_operator_norm_tail_bound':float(0.7*np.exp(start))})
    for i in range(3):
        past[i]['difference_to_next_start']=nrm(arrays[i]-arrays[i+1])
    require(past[2]['difference_to_next_start']<past[0]['difference_to_next_start'],
            'incoming-limit diagnostic')

    # Different admissible sea with identical retarded evolution.
    c_alt=0.9*c+0.1*(np.eye(4)-c)
    C_alt=U@c_alt@U.conj().T
    initial_difference=float(np.linalg.norm(c_alt-c,ord=2))
    final_difference=float(np.linalg.norm(C_alt-C,ord=2))
    require(abs(final_difference-initial_difference)<1e-11,'unitarity does not erase reference data')
    return {'classification':'NEW_CONDITIONAL_IN_VACUUM_PRESCRIPTION_TESTED_ONLY_ON_CONSTRUCTED_FINITE_SYSTEM',
            'asymptotic_gap':gap,
            'unitarity_error':unitary_error,
            'purity_error':projector_error,
            'self_dual_CAR_error':car_error,
            'self_dual_CAR_jet_error':car_jet_error,
            'source_derivative_steps':steps,
            'independent_source_derivative_errors':derivative_errors,
            'past_limit_refinement':past,
            'two_references_initial_operator_norm_difference':initial_difference,
            'two_references_final_operator_norm_difference':final_difference,
            'both_references_have_identical_retarded_propagator':True,
            'actual_BHSM_past_asymptotic_hamiltonian_evaluated':False,
            'primordial_reference_selected_by_existing_BHSM_action_proved':False}


def observable_adjoint_control():
    # Exact finite example of differentiating the self-consistent background.
    J=np.array([[2.0,0.3],[-0.2,1.5]])
    RC=np.array([[0.2,-0.5,0.1],[0.1,0.3,0.4]])
    a=np.array([0.7,-0.4])
    direct=np.array([0.1,-0.3,0.5])
    direction=np.array([0.2,-0.1,0.6])
    lam=np.linalg.solve(J.T,a)
    full_sensitivity=direct-lam@RC
    explicit=float(direct@direction-a@np.linalg.solve(J,RC@direction))
    adjoint=float(full_sensitivity@direction)
    err=abs(explicit-adjoint)
    require(err<1e-14,'self-consistent state sensitivity')
    return {'classification':'FINITE_CHAIN_RULE_CONTROL_NOT_A_MUON_STATE_INDEPENDENCE_PROOF',
            'full_vs_adjoint_error':err,
            'direct_state_sensitivity':direct.tolist(),
            'self_consistent_state_sensitivity':full_sensitivity.tolist(),
            'background_feedback_changes_state_sensitivity':True}


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output',type=Path,default=Path('results.json'))
    args=ap.parse_args()
    results={
        'title':'BHSM operator/domain/reference construction checks',
        'pinned_repository_revision':PIN,
        'scope':'Exact derived identities plus explicitly synthetic finite controls; no physical BHSM operator/state solve',
        'symbolic':symbolic_checks(),
        'finite_operator':finite_operator_checks(),
        'finite_reference':state_checks(),
        'observable_sensitivity':observable_adjoint_control(),
        'environment':{'numpy':np.__version__,'scipy':scipy.__version__,'sympy':sp.__version__},
        'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'physical_flags':{
            'full_field_to_native_graded_operator_correspondence_derived':False,
            'actual_inherited_reference_instantiated':False,
            'Gate7_closed_by_this_work':False,
            'physical_packets_produced':False,
            'terminal_response_evaluated':False,
            'full_physical_derivative_guard_passed':False,
            'original_coupled_corrections_applied':0,
            'muon_anomaly_evaluated':False,
            'repository_modified':False,
            'new_reference_prescription_is_proposed_not_derived_from_old_axioms':True,
        }
    }
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(results,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print(json.dumps(results,indent=2,sort_keys=True))


if __name__=='__main__':
    main()
