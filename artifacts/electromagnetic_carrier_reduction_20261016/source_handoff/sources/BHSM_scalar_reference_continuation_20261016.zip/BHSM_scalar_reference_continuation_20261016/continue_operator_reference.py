"""BHSM mathematical continuation: inverse scalar map and state-sensitivity tests.

No matrices in this program are physical BHSM operator/state operands.  The
scalar tests are symbolic identities conditional on the stated trial carrier.
The finite CAR/Fock tests verify general algorithms and their limitations.
No repository or user-library writes are performed.

Run: python continue_operator_reference.py --output results.json
Requires Python 3.10+, numpy and sympy.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

import numpy as np
import sympy as sp


def hermitian(a: np.ndarray) -> np.ndarray:
    a = np.asarray(a, dtype=np.complex128)
    if a.ndim != 2 or a.shape[0] != a.shape[1] or not np.isfinite(a).all():
        raise ValueError("Expected a finite square matrix")
    return (a + a.conj().T) / 2


def conjugation(a: np.ndarray, j: np.ndarray) -> np.ndarray:
    """J a J for antiunitary J = j K, with J^2=I."""
    return j @ a.conj() @ j.conj().T


def car_odd_kernel(m: np.ndarray, j: np.ndarray) -> np.ndarray:
    """Orthogonal projection onto Hermitian self-dual-CAR variation kernels."""
    m = hermitian(m)
    j = np.asarray(j, dtype=np.complex128)
    if j.shape != m.shape or not np.isfinite(j).all():
        raise ValueError("Incompatible antiunitary matrix")
    eye = np.eye(m.shape[0])
    if np.linalg.norm(j @ j.conj().T - eye) > 1e-10:
        raise ValueError("The antiunitary's linear factor must be unitary")
    if np.linalg.norm(j @ j.conj() - eye) > 1e-10:
        raise ValueError("This construction assumes J squared equals I")
    return hermitian((m - conjugation(m, j)) / 2)


def affine_car_range(m: np.ndarray, j: np.ndarray) -> dict[str, Any]:
    """Exact finite-matrix range of Tr(m C) on 0<=C<=I, C+JCJ=I.

    Eigenvalue computation is floating point. This is not a certified continuum
    enclosure. Endpoint covariances are extremizers of this finite optimization,
    not a physical reference prescription. Zero modes use occupation 1/2.
    """
    m = hermitian(m)
    k = car_odd_kernel(m, j)
    values, vectors = np.linalg.eigh(k)
    scale = max(1.0, float(np.max(np.abs(values))))
    signs = np.where(np.abs(values) < 1e-12 * scale, 0.0, np.sign(values))
    sign_k = (vectors * signs) @ vectors.conj().T
    eye = np.eye(len(values))
    c_plus, c_minus = (eye + sign_k) / 2, (eye - sign_k) / 2
    center = float(np.trace(m).real / 2)
    radius = float(np.sum(np.abs(values)) / 2)
    return {"kernel": k, "center": center, "radius": radius,
            "minimum": center - radius, "maximum": center + radius,
            "c_plus": c_plus, "c_minus": c_minus}


def matrix_residual(m: sp.MatrixBase) -> sp.MatrixBase:
    return m.applyfunc(lambda x: sp.trigsimp(sp.simplify(x)))


def require_zero(expr: Any, label: str) -> None:
    if isinstance(expr, sp.MatrixBase):
        result = matrix_residual(expr)
        if result != sp.zeros(*result.shape):
            raise AssertionError(f"{label}: {result}")
    elif sp.trigsimp(sp.simplify(expr)) != 0:
        raise AssertionError(f"{label}: {sp.simplify(expr)}")


def scalar_symbolic_tests() -> dict[str, Any]:
    # h is the positive fixed-cutoff heat coefficient of the trial sector.
    sig, chi = sp.symbols("sigma chi", real=True)
    b, z, g, h, ell, nu = sp.symbols("b Zchi g h ell nu", positive=True)
    theta, u, v = sp.symbols("theta u v", real=True)
    t = b / (2*h)
    omega = sp.sqrt(z*g/b)
    f = sp.sqrt(t)*sp.Matrix([
        sig*sp.cos(omega*chi), sig*sp.sin(omega*chi),
        sp.cos(omega*chi)/sp.sqrt(g), sp.sin(omega*chi)/sp.sqrt(g)])
    fs, fc = f.diff(sig), f.diff(chi)
    expected_mass2 = t*(sig**2 + 1/g)
    require_zero((f.T*f)[0]-expected_mass2, "mass square")
    require_zero(h*(fs.T*fs)[0]-b/2, "sigma kinetic metric")
    require_zero(h*(fc.T*fc)[0]-z*(1+g*sig**2)/2, "chi kinetic metric")
    require_zero((fs.T*fc)[0], "mixed kinetic metric")
    metric_variation = (fs*v+fc*u).dot(fs*v+fc*u)*h
    require_zero(metric_variation-(b*v**2+z*(1+g*sig**2)*u**2)/2,
                 "arbitrary tangent kinetic identity")
    # Explicit complex Clifford(4) representation. This is a trial internal
    # representation, not an assignment to BHSM's physical gauge carrier.
    sx = sp.Matrix([[0, 1], [1, 0]])
    sy = sp.Matrix([[0, -sp.I], [sp.I, 0]])
    sz = sp.diag(1, -1)
    eye2, eye4 = sp.eye(2), sp.eye(4)
    gam = [sp.kronecker_product(sx,eye2), sp.kronecker_product(sy,eye2),
           sp.kronecker_product(sz,sx), sp.kronecker_product(sz,sy)]
    for i in range(4):
        for j in range(4):
            require_zero(gam[i]*gam[j]+gam[j]*gam[i]-(2*eye4 if i==j else sp.zeros(4)),
                         "Clifford relation")
    # Use independent theta first; its derivatives are contracted by omega.
    ftheta = sp.sqrt(t)*sp.Matrix([sig*sp.cos(theta),sig*sp.sin(theta),
                                   sp.cos(theta)/sp.sqrt(g),sp.sin(theta)/sp.sqrt(g)])
    phi = sp.zeros(4)
    for a in range(4):
        phi += ftheta[a]*gam[a]
    require_zero(phi.H-phi,"Hermitian trial endomorphism")
    require_zero(phi*phi-expected_mass2*eye4,"Clifford mass scalar")
    phis, phic = phi.diff(sig), omega*phi.diff(theta)
    require_zero(sp.trace(phis*phis)/4-t,"sigma Clifford trace")
    require_zero(sp.trace(phic*phic)/4-t*omega**2*(sig**2+1/g),"chi Clifford trace")
    require_zero(sp.trace(phis*phic),"cross Clifford trace")
    # Frozen ell, bulk a2/a4 test using native F6 and F4.
    h_native = nu/(8*(4*sp.pi)**4*ell**4)
    V = sp.expand(h*(expected_mass2**2-4*expected_mass2/(3*ell**2)))
    G_trial = sp.simplify(4*V.coeff(sig,4))
    A_trial = sp.simplify(2*V.coeff(sig,2))
    require_zero(G_trial-b**2/h,"quartic matching equation")
    require_zero(A_trial-(G_trial/g-4*b/(3*ell**2)),"quadratic matching equation")
    # E=-R/4-Phi^2 + derivative Clifford term.  The R Phi^2
    # coefficient in a4 is 1/4-1/6=1/12 before moment multiplication.
    R, mass2 = sp.symbols("R mass2",real=True)
    E_scalar = -R/4-mass2
    a4_scalar = sp.expand(E_scalar**2/2+R*E_scalar/6)
    require_zero(a4_scalar.coeff(R,1).coeff(mass2,1)-sp.Rational(1,12),
                 "heat curvature cross coefficient")
    extra_curvature = sp.expand(h*R*expected_mass2/6)
    require_zero(extra_curvature.coeff(sig,2)-b*R/12,"sigma2 R discrepancy")
    require_zero(sp.diff(extra_curvature,sig)-b*R*sig/6,"scalar curvature Euler discrepancy")
    # Variations at fixed ell: ordinary scalar target Euler equations follow
    # from equality of the kinetic densities, not Hessian squaring.
    return {
        "classification":"EXACT_LOCAL_INVERSE_CONSTRUCTION_NOT_NATIVE_BHSM_REALIZATION",
        "all_symbolic_checks_passed":True,
        "domain":"Zchi>0, Zsigma=b>0, g>0, ell>0; local Riemannian field chart",
        "trial_internal_dimension":4,
        "trial_spin_dimension_in_M8":16,
        "physical_statistics_multiplicity_selected":False,
        "h_native":str(h_native),
        "omega_squared":str(sp.simplify(omega**2)),
        "normalized_Phi_squared":str(expected_mass2),
        "G0_required":str(G_trial),
        "A0_required":str(A_trial),
        "additional_sigma_squared_R_coefficient":str(b/12),
        "additional_constant_R_coefficient":str(b/(12*g)),
        "total_branch_cutoff_jets_evaluated":False,
        "full_action_match":False,
    }


def car_tests() -> dict[str, Any]:
    rng = np.random.default_rng(20261016)
    n = 4
    swap = np.block([[np.zeros((n,n)),np.eye(n)],[np.eye(n),np.zeros((n,n))]])
    raw = rng.standard_normal((2*n,2*n))+1j*rng.standard_normal((2*n,2*n))
    m = hermitian(raw)
    result = affine_car_range(m,swap)
    k = result['kernel']
    cp,cm = result['c_plus'],result['c_minus']
    upper = float(np.trace(m@cp).real)
    lower = float(np.trace(m@cm).real)
    errors = {
        "odd_symmetry_residual":float(np.linalg.norm(k+conjugation(k,swap))),
        "upper_witness_CAR_residual":float(np.linalg.norm(cp+conjugation(cp,swap)-np.eye(2*n))),
        "lower_witness_CAR_residual":float(np.linalg.norm(cm+conjugation(cm,swap)-np.eye(2*n))),
        "sharp_upper_error":abs(upper-result['maximum']),
        "sharp_lower_error":abs(lower-result['minimum']),
    }
    worst_pairing=0.0
    sample_excursion=0.0
    for _ in range(100):
        raw = rng.standard_normal((2*n,2*n))+1j*rng.standard_normal((2*n,2*n))
        x=car_odd_kernel(raw,swap)
        x*=0.49/max(1.0,np.linalg.norm(x,2))
        c=np.eye(2*n)/2+x
        worst_pairing=max(worst_pairing,float(abs(np.trace((m-k)@x))))
        v=float(np.trace(m@c).real)
        sample_excursion=max(sample_excursion,v-result['maximum'],result['minimum']-v)
    errors['projection_pairing_error']=worst_pairing
    errors['max_sample_outside_interval']=sample_excursion
    assert max(errors.values())<1e-10,errors
    assert np.linalg.eigvalsh(cp).min()>-1e-10
    assert np.linalg.eigvalsh(cp).max()<1+1e-10
    # Pure-state stationarity does not bound changes of occupation.
    p=np.diag([1.]*n+[0.]*n)
    md=np.diag([1.,2.,3.,4.,-1.,-2.,-3.,-4.])
    off=p@md@(np.eye(2*n)-p)+(np.eye(2*n)-p)@md@p
    assert np.linalg.norm(off)==0
    full_width=np.sum(np.abs(np.linalg.eigvalsh(md)))
    return {
        "classification":"FINITE_ALGORITHM_CONTROL_NOT_PHYSICAL_STATE",
        "finite_dimension":2*n,
        "errors":errors,
        "affine_interval":[result['minimum'],result['maximum']],
        "affine_width":2*result['radius'],
        "pure_tangent_counterexample_offdiagonal_norm":float(np.linalg.norm(off)),
        "same_counterexample_full_CAR_width":float(full_width),
        "continuum_tail_certified":False,
        "physical_M_effective_evaluated":False,
    }


def annihilation(n: int, k: int) -> sp.Matrix:
    """Jordan-Wigner annihilator, exact finite Fock representation."""
    out=sp.zeros(2**n)
    for state in range(2**n):
        if (state>>k)&1:
            sign=(-1)**((state & ((1<<k)-1)).bit_count())
            out[state^(1<<k),state]=sign
    return out


def fock_tests() -> dict[str, Any]:
    n=4
    aa=[annihilation(n,k) for k in range(n)]
    rho_a=sp.zeros(16);rho_b=sp.zeros(16)
    # Both mixtures are supported in the same exact two-particle sector.
    # a: occupied sets {0,1} or {2,3}; b: {0,2} or {1,3}.
    for state in [3,12]:rho_a[state,state]=sp.Rational(1,2)
    for state in [5,10]:rho_b[state,state]=sp.Rational(1,2)
    number=sum((op.H*op for op in aa),sp.zeros(16))
    require_zero(number*rho_a-2*rho_a,"rho A exact particle number")
    require_zero(number*rho_b-2*rho_b,"rho B exact particle number")
    for i in range(n):
        for j in range(n):
            require_zero(sp.trace((rho_a-rho_b)*aa[i].H*aa[j]),"normal covariance equality")
            require_zero(sp.trace((rho_a-rho_b)*aa[i]*aa[j]),"anomalous covariance equality")
    n0,n1=aa[0].H*aa[0],aa[1].H*aa[1]
    k=n0*n1
    va,vb=sp.trace(rho_a*k),sp.trace(rho_b*k)
    require_zero(va-sp.Rational(1,2),"quartic readout A")
    require_zero(vb,"quartic readout B")
    return {
        "classification":"EXACT_FOCK_COUNTEREXAMPLE_NOT_BHSM_SEA",
        "complex_modes":4,"Fock_dimension":16,"exact_total_particle_number":2,
        "normal_covariances_identical":True,"anomalous_covariances_identical":True,
        "quartic_expectation_A":str(va),"quartic_expectation_B":str(vb),
        "conclusion":"Covariance-level insensitivity alone does not cover higher connected state dependence.",
    }


def nonlinear_remainder_tests() -> dict[str,Any]:
    y,beta=sp.symbols('y beta',real=True)
    J=1+3*y**2
    yp=beta/J
    ypp=-6*y*beta**2/J**3
    app=sp.factor(2*yp**2+2*y*ypp)
    require_zero(app-2*(1-3*y**2)*beta**2/J**3,"implicit total second derivative")
    # R=y+y^3-Tr(B C). At C0=I/2, y0=0, full M_eff=0.
    # At C1=diag(13/16,3/16), Tr(B C1)=5/8 and y1=1/2.
    y1=sp.Rational(1,2)
    beta1=sp.Rational(5,8)
    require_zero(y1+y1**3-beta1,"nonlinear endpoint exact equation")
    radius=beta1**2  # 1/2 sup|a''| <= beta^2 along 0<=s<=1
    assert y1**2<=radius
    return {
        "classification":"EXACT_NONLINEAR_REMAINDER_CONTROL_NOT_PHYSICAL_BACKGROUND",
        "total_second_derivative":str(app),
        "initial_full_first_derivative_zero":True,
        "finite_observable_change":str(y1**2),
        "rigorous_control_model_remainder_bound":str(radius),
        "conclusion":"Zero complete sensitivity at one point does not prove finite-family independence.",
    }


def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=Path('results.json'))
    args=parser.parse_args()
    result={
        "source_commit":"b6cb15f5ab6f6b44057f13895c5fd498ce928d83",
        "all_checks_passed":True,
        "scope":"NEW SYMBOLIC DERIVATIONS AND DELIBERATELY CONSTRUCTED ALGORITHM CONTROLS",
        "scalar":scalar_symbolic_tests(),"CAR":car_tests(),"Fock":fock_tests(),
        "nonlinear_remainder":nonlinear_remainder_tests(),
        "physical_status":{
            "native_operator_reproduces_full_action":False,
            "inherited_reference_selected":False,
            "ground_state_assumption_adopted":False,
            "physical_reference_sensitivity_evaluated":False,
            "physical_muon_vertex_evaluated":False,
            "a_mu_physical":None,"g_mu_physical":None,"physical_total_uncertainty":None,
            "Gate7_closed":False,"FULL_BHSM_COMPLETE":False,
        },
    }
    output=json.dumps(result,indent=2,sort_keys=True,allow_nan=False)+'\n'
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(output,encoding='utf-8')
    print(output,end='')


if __name__=='__main__':
    main()
