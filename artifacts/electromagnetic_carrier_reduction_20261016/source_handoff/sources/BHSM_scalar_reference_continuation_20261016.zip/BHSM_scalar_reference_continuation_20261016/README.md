# BHSM scalar/reference continuation — 16 October 2026

Start with `DERIVATION.md`. This extends the previous operator/reference package
without choosing the physical sea, operator carrier, cutoff, or coefficients.

New content:

1. Explicit scalar-dependent first-order trial operator; exact local kinetic
   correspondence; potential constraints and nonzero curvature/boundary terms.
2. Sharp finite-CAR effective-kernel projection and extremal bounds.
3. Full-density extension and a same-number exact Fock counterexample to a
   covariance-only treatment of higher current products.
4. Complete implicit second-derivative formula with an exact nonlinear control.

The script contains symbolic checks and constructed finite algorithm controls,
not a physical BHSM numerical producer. Numerical magnetic moments remain null.

## Reproduce

Requires Python 3.10 or later, NumPy and SymPy. No network or repository access
is required for the saved mathematical checks.

```powershell
Set-Location "C:\Users\carbe\Downloads\BHSM_scalar_reference_continuation_20261016"
& C:\Python314\python.exe .\continue_operator_reference.py --output .\results_local.json
```

The source script and report are outside the repository. The command assumes
the package has been extracted to that Downloads folder; no local user path was
accessed or created by this session.

Two existing runs are provided as `results_run_1.json` and `results_run_2.json`.
`SHA256SUMS.json` hashes all packaged files except itself.
`provenance.json` records the pinned source and previous artifact hashes.

No dependency on Codex. No repository mutation. No physical reference selection.
