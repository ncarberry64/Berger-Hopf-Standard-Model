"""Verify or restore the pinned 2023 benchmark source pack (Python stdlib).

No fit is performed. HST refetches require an exact HTTP206 Range response
and never fall back to downloading complete FLC images.
"""
import argparse
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import ssl
import sys
import tarfile
import urllib.request

_ARCHIVES = {}

def digest(data):
    return hashlib.sha256(data).hexdigest()

def local_path(root, relative):
    relative = PurePosixPath(relative)
    if relative.is_absolute() or not relative.parts or any(p in ("..", ".") for p in relative.parts):
        raise ValueError("Unsafe manifest path")
    root = root.resolve()
    target = root.joinpath(*relative.parts).resolve()
    if root not in target.parents:
        raise ValueError("Manifest path leaves source-pack directory")
    return target

def tls_context():
    try:
        import certifi
    except ImportError:
        return ssl.create_default_context()
    return ssl.create_default_context(cafile=certifi.where())

def request_bytes(url, count, *, byte_range=False):
    if not url.startswith("https://"):
        raise ValueError("Only HTTPS source URLs are allowed")
    headers = {"User-Agent": "BHSM-benchmark-source-verifier/1"}
    if byte_range:
        headers["Range"] = f"bytes=0-{count-1}"
    request = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(request, context=tls_context(), timeout=90) as response:
        if byte_range:
            if response.status != 206:
                raise ValueError(f"Refused HST response HTTP{response.status}; full-image fallback is prohibited")
            value = response.headers.get("Content-Range", "")
            if not re.match(rf"^bytes 0-{count-1}/[0-9]+$", value):
                raise ValueError(f"Unexpected HST Content-Range: {value}")
        elif response.status != 200:
            raise ValueError(f"Unexpected source HTTP{response.status}")
        body = response.read(count + 1)
    if len(body) != count:
        raise ValueError(f"Expected exactly {count} bytes; received {len(body)}")
    return body

def restore(entry):
    method = entry.get("refetch")
    if not method:
        raise ValueError("This frozen derived/provenance file is bundled-only; re-extract it from the pinned release archive")
    if method["kind"] == "https_bytes":
        body = request_bytes(method["url"], entry["bytes"])
    elif method["kind"] == "https_range":
        body = request_bytes(method["url"], entry["bytes"], byte_range=True)
    elif method["kind"] == "arxiv_tar_member":
        url = method["url"]
        if url not in _ARCHIVES:
            archive = request_bytes(url, method["archive_bytes"])
            if digest(archive) != method["archive_sha256"]:
                raise ValueError("Author archive SHA256 differs from pinned version")
            _ARCHIVES[url] = archive
        with tarfile.open(fileobj=io.BytesIO(_ARCHIVES[url]), mode="r:*") as tar:
            member = tar.getmember(method["member"])
            if not member.isfile() or member.size != entry["bytes"]:
                raise ValueError("Author member size/type differs")
            stream = tar.extractfile(member)
            body = stream.read(entry["bytes"] + 1)
    else:
        raise ValueError("Unknown manifest acquisition method")
    if len(body) != entry["bytes"] or digest(body) != entry["sha256"]:
        raise ValueError("Fetched bytes do not match frozen SHA256/size; no source update accepted")
    return body

def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--refetch-missing", action="store_true")
    parser.add_argument("--refetch", action="append", default=[], metavar="RELATIVE_PATH",
                        help="Restore this known missing file; refuses to overwrite an existing file")
    parser.add_argument("--report", type=Path)
    args = parser.parse_args(argv)
    root = args.root.resolve()
    manifest = json.loads((root / "ACQUISITION_MANIFEST.json").read_text(encoding="utf-8"))
    entries = manifest["files"]
    known = {e["path"] for e in entries}
    if set(args.refetch) - known:
        parser.error("Requested refetch path is not in the frozen manifest")
    checks = []
    for entry in entries:
        target = local_path(root, entry["path"])
        try:
            fetched = False
            if entry["path"] in args.refetch and target.exists():
                raise ValueError("Explicit refetch refuses an existing file; move that copy aside first")
            if not target.exists() and (args.refetch_missing or entry["path"] in args.refetch):
                data = restore(entry)
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(data)
                fetched = True
            if not target.exists():
                raise ValueError("File is missing")
            data = target.read_bytes()
            ok = len(data) == entry["bytes"] and digest(data) == entry["sha256"]
            checks.append({"path": entry["path"], "passed": ok, "bytes": len(data),
                           "sha256": digest(data), "refetched": fetched})
        except (OSError, ValueError, KeyError, tarfile.TarError) as error:
            checks.append({"path": entry["path"], "passed": False, "error": str(error)})
    report = {"schema": "bhsm.portable_2023_benchmark_verification/1",
              "manifest_sha256": digest((root / "ACQUISITION_MANIFEST.json").read_bytes()),
              "all_pass": all(c["passed"] for c in checks),
              "checked_files": len(checks), "checks": checks,
              "scope": "Source identity only; no inference, fit, physical acceptance or calibration claim"}
    if args.report:
        args.report.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps({"all_pass": report["all_pass"], "checked_files": len(checks),
                      "refetched": sum(c.get("refetched", False) for c in checks),
                      "failed": [c for c in checks if not c["passed"]]}, indent=2))
    return 0 if report["all_pass"] else 1

if __name__ == "__main__":
    sys.exit(main())
