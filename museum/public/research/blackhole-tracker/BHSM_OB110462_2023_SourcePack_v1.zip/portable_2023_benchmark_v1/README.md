# Portable 2023 known-system source pack, v1

This pack supplies the distinct corrected-OGLE / Lam–Lu2023 HST benchmark.
It does not contain the older 2022 61,585-point benchmark or the 100-event pilot,
and does not include or assume access to unreleased Keck observations.

All original source/table/header bytes are unchanged. There are 15,533 corrected
OGLE rows, 21 HST filter rows at 11 dated visits, and 82 bounded HST FITS prefixes.
The frozen mapping and header receipt retain historical Windows paths as
provenance. No local I/O needs those paths: the manifest/index use relative paths.
Use the portable v2 importer; the frozen v1 importer has a documented
WindowsPath-basename limitation and is preserved as historical code.

Run from any extracted location using Python 3 (standard library sufficient):

    python verify_or_refetch_2023_sources.py
    python verify_or_refetch_2023_sources.py --refetch-missing

Explicitly restore a known missing prefix:

    python verify_or_refetch_2023_sources.py --refetch MAST_header_prefixes/ibnc06f6q_flc.fits.prefix.bin

The helper refuses to overwrite existing files. Every restored file must match
the frozen byte count and SHA256. HST requests require HTTP 206 and the exact
Content-Range; there is no full-image fallback. Author tables can be recovered
from the hash-pinned arXiv source archive without extracting arbitrary paths.
Frozen derived receipts are bundled-only; recover a missing one by re-extracting
the pinned source pack. Server reprocessing/hash changes are failures, not
silent upgrades to this data version. certifi is used if available; normal TLS
verification remains enabled.

ACQUISITION_MANIFEST.json inventories every bundled file except itself.
PORTABLE_HEADER_INDEX.json connects all 82 prefixes to source URLs, hashes and
original receipt paths. Rights and citations are in CITATIONS_AND_RIGHTS.md.
The outer release archive hash pins the manifest itself.

Source verification is not scientific acceptance. HST combined-epoch weights
are not supplied; the mapping preserves full exposure windows and alternative
representative times. Reported errors are unchanged. Relative frame, clock,
noise, model adequacy and mass-identification limitations remain mandatory in
the separately versioned analysis protocol.
