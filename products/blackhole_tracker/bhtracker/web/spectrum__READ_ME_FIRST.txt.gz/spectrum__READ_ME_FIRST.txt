BHSM common-lens sky-track exploration v10

All original v9 point fields, labels, physical nulls and four figures are preserved. New common_lens_track_inputs is source-event context, not measured lens astrometry. The filter has 0 Track test supported / 1,808 Track data unavailable in this snapshot. Optional timescale and measured-geometry cuts default blank; unavailable values stay retained. No BH identification follows from short duration or source alignment.

Select a case and Add selected model to sequence. Catalog source markers and model event times are shown in six separate native-time groups, with no fitted/connecting lens line or clock conversion. Sequence starts empty; no targets are seeded. Native t0 definitions, source rows, hashes and missing coordinate epochs remain inspectable. The installed app provides /skytrack for a separate measured-angular-data analysis.

Displayed-view JSON exports include dataset identity, filters/thresholds, selected case/sequence IDs, displayed and sequence records. Displayed-view CSV is a quoted table with __record_kind and __view_state_json: one VIEW_STATE row plus unique POINT rows for displayed and hidden sequence cases. Replay validates exact dataset identity, filter-derived IDs, all values and selection state before applying it to the full frozen dataset. The complete spectrum_rows_v1.csv is an ordinary full metadata table, not this view-state format.

Source catalog/data terms and acknowledgements remain separate from the BHSM software license. Formal repository: https://github.com/ncarberry64/Berger-Hopf-Standard-Model
No model, predictor, likelihood or network query was called for this view.
